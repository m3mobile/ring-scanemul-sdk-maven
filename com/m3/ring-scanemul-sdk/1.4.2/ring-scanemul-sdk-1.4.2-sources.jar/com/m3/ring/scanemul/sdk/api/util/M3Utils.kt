package com.m3.ring.scanemul.sdk.api.util

import android.graphics.Bitmap
import com.m3.ring.scanemul.sdk.api.model.DeviceState
import com.m3.ring.scanemul.sdk.internal.common.util.Utils
import com.m3.ring.scanemul.sdk.internal.device.mapping.toInternalDeviceState
import java.nio.charset.Charset

object M3Utils {
    /**
     * Decodes the given [ByteArray] into a [String] using the specified [Charset] (default: UTF-8).
     */
    @JvmOverloads
    @JvmStatic
    fun toUtf8String(bytes: ByteArray, charset: Charset = Charsets.UTF_8): String =
        String(bytes, charset)

    /**
     * Checks whether the input matches the pattern "number,number" (e.g., "12,34"),
     * and that each part is a decimal number.
     */
    @JvmStatic
    fun isDecimalPair(value: String): Boolean {
        val regex = Regex("^\\s*\\d+\\s*,\\s*\\d+\\s*$")
        return regex.matches(value)
    }

    /**
     * Checks whether [value] is a valid hex byte-pair sequence.
     *
     * Accepted formats:
     * - An empty string (treated as “no data” and considered valid)
     * - A semicolon-separated list of up to 8 pairs in the form: `"hh,hh;hh,hh;..."`
     *
     * Rules:
     * - Each `hh` is 1–2 hexadecimal characters (`0–9`, `A–F`, `a–f`).
     * - Pairs are written as `leftByte,rightByte` (e.g. `"1A,2B"`).
     * - Pairs are separated by `';'` (e.g. `"1A,2B;0C,FF"`).
     * - Arbitrary whitespace is allowed around numbers, commas, and semicolons.
     *
     * Examples of valid input:
     * - `""`
     * - `"1A,2B"`
     * - `"0,FF; 10,20"`
     *
     * @param value The input string to validate.
     * @return `true` if [value] is empty or matches the expected pattern; `false` otherwise.
     */
    @JvmStatic
    fun isHexPairsSequenceAndMaxLength8(value: String): Boolean {
        if (value.isEmpty()) return true

        val regex = Regex(
            "^\\s*[0-9A-Fa-f]{1,2}\\s*,\\s*[0-9A-Fa-f]{1,2}(?:\\s*;\\s*[0-9A-Fa-f]{1,2}\\s*,\\s*[0-9A-Fa-f]{1,2}){0,7}\\s*$"
        )
        return regex.matches(value)
    }

    /**
     * Generates a QR code bitmap from the given [DeviceState].
     *
     * @param deviceState The device state to encode into a QR code.
     * @param size The desired QR code size in pixels (default: 512).
     * @return The generated QR bitmap, or null if generation fails (e.g., missing scannerId).
     */
    @JvmOverloads
    @JvmStatic
    fun generateQrBitmap(
        deviceState: DeviceState,
        size: Int = 512
    ): Bitmap? {
        return Utils.generateQrBitmap(deviceState.toInternalDeviceState(), size)
    }
}