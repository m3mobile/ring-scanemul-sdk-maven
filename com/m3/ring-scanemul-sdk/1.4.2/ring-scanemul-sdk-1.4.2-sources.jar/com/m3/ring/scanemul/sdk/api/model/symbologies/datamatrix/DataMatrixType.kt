package com.m3.ring.scanemul.sdk.api.model.symbologies.datamatrix

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object DataMatrixType {
    enum class InverseType : TypeValue {
        REGULAR_ONLY, INVERSE_ONLY, AUTO
    }

    enum class DecodeMirrorImagesType : TypeValue {
        NEVER, ALWAYS, AUTO
    }
}