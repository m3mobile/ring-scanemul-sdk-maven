package com.m3.ring.scanemul.sdk.api.model.symbologies.gs1128

data class Gs1128Vals(
    val enabled: Boolean? = null
)