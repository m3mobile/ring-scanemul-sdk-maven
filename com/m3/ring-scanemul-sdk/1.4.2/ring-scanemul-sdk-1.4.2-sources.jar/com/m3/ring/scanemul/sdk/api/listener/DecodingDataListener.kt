package com.m3.ring.scanemul.sdk.api.listener

interface DecodingDataListener {
    fun onReceive(decodingData: ByteArray)
}