package com.m3.ring.scanemul.sdk.internal.scan.data.filter

import android.Manifest
import android.bluetooth.BluetoothDevice
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.internal.common.consts.BtConst

/**
 * WR 디바이스 필터
 *
 * 블루투스 디바이스의 이름이 WR 디바이스 접두사로 시작하는지 확인합니다.
 */
internal object WRDeviceFilter {
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    fun matches(btDevice: BluetoothDevice): Boolean =
        btDevice.name?.startsWith(BtConst.DISCOVERY_FILTER_PREFIX, ignoreCase = true) == true
}