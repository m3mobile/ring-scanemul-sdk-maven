package com.m3.ring.scanemul.sdk.api.settings

import com.m3.ring.scanemul.sdk.internal.protocol.common.commands.InternalSettingCommand

class SettingCommand private constructor(
    internal val internalSettingCmd: InternalSettingCommand
) {
    companion object {
        internal fun fromInternal(cmd: InternalSettingCommand): SettingCommand =
            SettingCommand(cmd)
    }
}