package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.dotcode.DotCodeType
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
object DotCodeSymbology {
    /* Ids */
    enum class DotCodeIds(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("dotCodeEnable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0xF8.toByte(), 0x07.toByte(), 0x72.toByte()), totinfo = null),

        @BindField("dotCodeInverse")
        @BindValue(ValueType.ENUM, InverseVal::class)
        INVERSE(zebra = byteArrayOf(0xF8.toByte(), 0x07.toByte(), 0x73.toByte()), totinfo = null),

        @BindField("dotCodeMirror")
        @BindValue(ValueType.ENUM, MirrorVal::class)
        MIRROR(zebra = byteArrayOf(0xF8.toByte(), 0x07.toByte(), 0x74.toByte()), totinfo = null),

        @BindField("dotCodePrioritize")
        @BindValue(ValueType.ENUM, PrioritizeVal::class)
        PRIORITIZE(zebra = byteArrayOf(0xF8.toByte(), 0x07.toByte(), 0x91.toByte()), totinfo = null);

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = null),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = null)
    }

    @EnumNameMatch(external = DotCodeType.InverseType::class)
    enum class InverseVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = null),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = null),
        AUTODETECT(zebra = byteArrayOf(0x02), totinfo = null)
    }

    @EnumNameMatch(external = DotCodeType.MirrorType::class)
    enum class MirrorVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        REGULAR(zebra = byteArrayOf(0x00), totinfo = null),
        INVERSE_ONLY(zebra = byteArrayOf(0x01), totinfo = null),
        AUTODETECT(zebra = byteArrayOf(0x02), totinfo = null)
    }

    @EnableDisableEnum
    enum class PrioritizeVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = null),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = null)
    }
}
