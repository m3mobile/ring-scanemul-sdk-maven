package com.m3.ring.scanemul.sdk.api.model.symbologies.codabar

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object CodabarType {
    enum class SecurityType : TypeValue {
        LEVEL_0, LEVEL_1, LEVEL_2, LEVEL_3
    }
}