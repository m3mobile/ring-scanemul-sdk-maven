package com.m3.ring.scanemul.sdk.internal.common.util

internal object PacketUtils {
    /**
     * 10진수 값들이 구분자로 연결된 문자열을 byte 배열로 변환한다.
     * 예: "2,4" -> [0x02, 0x04], "10,15" -> [0x0A, 0x0F]
     *
     * @param input     10진수 값이 구분자(, 등)로 연결된 문자열 (예: "10,15")
     * @param delimiter 구분자. 기본값은 쉼표(',')
     * @return ByteArray로 변환된 값 배열 (각 값은 16진수 byte로 변환됨)
     *
     * 예시:
     * ```
     * val arr1 = decimalListToByteArray("2,4")      // [0x02, 0x04]
     * val arr2 = decimalListToByteArray("10,15")    // [0x0A, 0x0F]
     * val arr3 = decimalListToByteArray("8, 31, 127") // [0x08, 0x1F, 0x7F]
     * ```
     */
    fun decimalStringToByteArray(input: String, delimiter: Char = ','): ByteArray {
        return input
            .split(delimiter)
            .map { it.trim().toInt().toByte() }
            .toByteArray()
    }

    /**
     * 쉼표(,) 또는 세미콜론(;)으로 구분된 16진수 쌍 문자열을 바이트 배열로 변환합니다.
     * 각 16진수 쌍은 해당하는 바이트 값으로 변환됩니다.
     *
     * 예시:
     * "01,03;04,05" -> [1, 3, 4, 5]
     *
     * @param input 16진수 쌍이 포함된 입력 문자열
     * @return 입력 문자열의 바이트 배열 표현
     */
    fun hexPairsListToByteArray(input: String): ByteArray {
        return input
            .split(',', ';') // 콤마와 세미콜론 모두 split
            .map { it.trim().toInt(16).toByte() }
            .toByteArray()
    }
}