package com.m3.ring.scanemul.sdk.internal.scan.data.spp

import android.Manifest
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.error.catalog.DiscoveryScanErrorCatalog
import com.m3.ring.scanemul.sdk.api.listener.DiscoveryScanResultListener
import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.scan.data.filter.WRDeviceFilter
import com.m3.ring.scanemul.sdk.internal.scan.data.spp.dto.toModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

internal class SPPScanRepo(
    private val manager: SPPScanManager
) {
    private val workScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val callbackScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var scanJob: Job? = null
    private val isScanning = AtomicBoolean(false)

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun startDiscoveryScan(
        listener: DiscoveryScanResultListener,
    ) {
        val predicate = WRDeviceFilter::matches

        if (!isScanning.compareAndSet(false, true)) {
            val catalog = DiscoveryScanErrorCatalog.ALREADY_SCANNING
            workScope.launch { listener.onError(catalog.code, catalog.msg) }
            return
        }  // 중복 시작 방지

        scanJob?.cancel() // 기존 스캔 작업이 있으면 취소

        scanJob = workScope.launch {
            manager.startDiscoveryScan(
                onStarted = {
                    Logger.i(msg = "=========== ACTION_DISCOVERY_STARTED ===========")
                    callbackScope.launch {
                        runCatching { listener.onStarted() }
                            .onFailure { Logger.e(msg = "=========== Listener error in onStarted: ${it.message} ===========") }
                    }
                },
                onDeviceFound = { device ->
                    if (predicate(device.btDevice)) {
                        Logger.i(msg = "=========== ACTION_FOUND - Device Name : ${device.btDevice.name} ===========")
                        callbackScope.launch {
                            runCatching { listener.onDeviceFound(device.toModel()) }
                                .onFailure { Logger.e(msg = "=========== Listener error in onDeviceFound: ${it.message} ===========") }
                        }
                    }
                },
                onFinished = {
                    scanJob = null
                    Logger.i(msg = "=========== ACTION_DISCOVERY_FINISHED ===========")
                    isScanning.set(false)
                    callbackScope.launch {
                        runCatching { listener.onFinished() }
                            .onFailure { Logger.e(msg = "=========== Listener error in onFinished: ${it.message} ===========") }
                    }
                },
                onError = { errorCode, errorMsg ->
                    isScanning.set(false)
                    callbackScope.launch {
                        runCatching { listener.onError(errorCode, errorMsg) }
                            .onFailure { Logger.e(msg = "=========== Listener error in onFailure: ${it.message} ===========") }
                    }
                }
            )
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun stopDiscoveryScan() {
        if (!isScanning.compareAndSet(true, false)) return // 이미 중지된 경우 무시
        manager.stopDiscoveryScan()
        scanJob?.cancel()
        scanJob = null
    }
}
