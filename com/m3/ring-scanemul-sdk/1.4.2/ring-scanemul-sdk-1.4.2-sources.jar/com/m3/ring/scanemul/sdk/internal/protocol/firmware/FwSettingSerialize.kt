package com.m3.ring.scanemul.sdk.internal.protocol.firmware

import com.m3.ring.scanemul.sdk.internal.device.state.FwSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting.FwIds

object FwSettingSerialize {
    fun FwSettingInfo.toSerializeFwSettingPayload(): ByteArray =
        FwIds.entries.fold(ByteArray(0)) { acc, id ->
            val valueBytes = id.serializer(this)
            if (valueBytes == null || valueBytes.isEmpty()) {
                acc + byteArrayOf(id.idByte, 0x00)
            } else {
                acc + byteArrayOf(id.idByte, valueBytes.size.toByte()) + valueBytes
            }
        }
}