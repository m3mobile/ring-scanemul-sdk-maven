package com.m3.ring.scanemul.sdk.api.model.symbologies.chinese2of5

data class Chinese2Of5Vals(
    val enabled: Boolean? = null
)
