package com.m3.ring.scanemul.sdk.api.model.settings.basic

data class BasicFormat(
    val transmitCodeId: BasicFormatType.TransmitCodeIdType? = null,
    val endChar: BasicFormatType.EndCharType? = null,
    val substringFormation: String? = null,
    val removeFnc: Boolean? = null,
    val translateData: String? = null,
    val prefixPostfixAsAsciiHex: Boolean? = null,
    val prefix: String? = null,
    val postfix: String? = null
)
