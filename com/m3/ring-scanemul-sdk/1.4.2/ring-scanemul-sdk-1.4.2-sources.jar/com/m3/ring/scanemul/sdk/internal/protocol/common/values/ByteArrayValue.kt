package com.m3.ring.scanemul.sdk.internal.protocol.common.values

import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwValue

data class ByteArrayValue(override val value: ByteArray) : FwValue {
    override fun toByteArray(): ByteArray = value
}
