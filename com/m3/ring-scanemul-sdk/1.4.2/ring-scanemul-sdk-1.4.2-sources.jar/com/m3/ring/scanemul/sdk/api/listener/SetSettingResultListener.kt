package com.m3.ring.scanemul.sdk.api.listener

interface SetSettingResultListener {
    fun onSuccess()
    fun onFailure(errorCode: Int, errorMessage: String)
}