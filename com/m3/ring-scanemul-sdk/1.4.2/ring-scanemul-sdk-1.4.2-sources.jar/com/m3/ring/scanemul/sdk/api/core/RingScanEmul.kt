package com.m3.ring.scanemul.sdk.api.core

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.graphics.Bitmap
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.listener.ConnectResultListener
import com.m3.ring.scanemul.sdk.api.listener.DiscoveryScanResultListener
import com.m3.ring.scanemul.sdk.api.listener.S2PScanResultListener
import com.m3.ring.scanemul.sdk.api.model.scan.DiscoveryScanEvent
import com.m3.ring.scanemul.sdk.internal.core.RingScanEmulSdkImpl
import kotlinx.coroutines.flow.Flow

/**
 * Public facade (entry point) for the Ring ScanEmul SDK.
 *
 * All public APIs delegate to an internal implementation through the [RingScanEmulSdk] interface,
 * so internal details remain hidden and can be safely obfuscated.
 */
object RingScanEmul {
    private val impl: RingScanEmulSdk = RingScanEmulSdkImpl()

    /**
     * Initializes the SDK.
     *
     * Call this once before using any other API. Subsequent calls are no-ops.
     *
     * @param context Application or activity context
     * @param config SDK configuration (connection type, logging, etc.)
     * @return [RingScanEmul] for call chaining
     */
    @JvmStatic
    @Synchronized
    fun initialize(context: Context, config: RingScanEmulSdkConfig): RingScanEmul {
        impl.initialize(context, config)
        return this
    }

    /**
     * Returns the command string used for S2P communication.
     *
     * The command includes the SDK-managed unique key used by S2P devices.
     * Use this value to generate any barcode type on your UI/app.
     */
    @JvmStatic
    fun getCmdForS2P(): String = impl.getCmdForS2P()

    /**
     * Generates a GS1-128 barcode bitmap used to connect with S2P devices.
     *
     * @param width  Output bitmap width in pixels (default 260)
     * @param height Output bitmap height in pixels (default 50)
     * @return A generated barcode bitmap, or null if generation fails
     */
    @JvmStatic
    @JvmOverloads
    fun getBarcodeBitmapForS2P(width: Int = 260, height: Int = 50): Bitmap? =
        impl.getBarcodeBitmapForS2P(width, height)

    /**
     * Starts a BLE scan to discover S2P devices.
     *
     * Requires BLUETOOTH_SCAN and BLUETOOTH_CONNECT permissions.
     * Invokes [onDeviceFound] for each discovered device and [onScanFailed] on error.
     *
     * @param onDeviceFound Callback when a device is found
     * @param onScanFailed  Callback when scanning fails (provides error code and message)
     */
    @JvmStatic
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun startS2PScan(onDeviceFound: (BluetoothDevice) -> Unit, onScanFailed: (errorCode: Int, errorMsg: String) -> Unit) =
        impl.startS2PScan(onDeviceFound, onScanFailed)

    /**
     * Starts a BLE scan to discover S2P devices (Java-friendly overload).
     *
     * Requires BLUETOOTH_SCAN and BLUETOOTH_CONNECT permissions.
     *
     * @param listener Listener that receives scan callbacks
     */
    @JvmStatic
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun startS2PScan(listener: S2PScanResultListener) =
        impl.startS2PScan(listener)

    /**
     * Starts a BLE scan to discover S2P devices (suspend version).
     *
     * Suspends until a device is found or an error occurs.
     */
    @JvmSynthetic
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    suspend fun startS2PScan(): BluetoothDevice = impl.startS2PScan()

    /**
     * Attempts to connect to the given [BluetoothDevice].
     *
     * Requires BLUETOOTH_CONNECT permission.
     * On success, a session is created internally; on failure, an error message is returned.
     *
     * @param device     Target device to connect
     * @param onSuccess  Called when connected and ready
     * @param onFailure  Called with an error code and message when connection fails
     */
    @JvmStatic
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    fun connectToDevice(
        device: BluetoothDevice,
        onSuccess: () -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    ) = impl.connectToDevice(device, onSuccess, onFailure)

    /**
     * Attempts to connect to the given [BluetoothDevice] (Java-friendly overload).
     *
     * Requires BLUETOOTH_CONNECT permission.
     *
     * @param device   Target device to connect
     * @param listener Listener that receives connection callbacks
     */
    @JvmStatic
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    fun connectToDevice(device: BluetoothDevice, listener: ConnectResultListener) =
        impl.connectToDevice(device, listener)

    /**
     * Attempts to connect to the given [BluetoothDevice] (suspend version).
     *
     * Requires BLUETOOTH_CONNECT permission.
     * Suspends until connected or throws on failure.
     */
    @JvmSynthetic
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    suspend fun connectToDevice(device: BluetoothDevice) =
        impl.connectToDevice(device)

    /**
     * Returns the current [TransportSession] used for communication.
     *
     * Make sure the SDK is initialized and a connection has been established.
     */
    @JvmStatic
    fun getTransportSession(): TransportSession = impl.getTransportSession()

    /**
     * Indicates whether the [TransportSession] is initialized.
     *
     * True means the device is connected and settings have been fetched.
     */
    @JvmStatic
    fun isTransportSessionInitialized(): Boolean = impl.isTransportSessionInitialized()

    /**
     * Starts classic Bluetooth discovery and filters devices whose model name starts with "WR".
     *
     * Requires BLUETOOTH_SCAN and BLUETOOTH_CONNECT permissions.
     *
     * @param listener Listener that receives discovery scan callbacks
     */
    @JvmStatic
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun startDiscoveryScan(listener: DiscoveryScanResultListener) =
        impl.startDiscoveryScan(listener)


    /**
     * Starts classic Bluetooth discovery and filters devices whose model name starts with "WR" (Flow version).
     *
     * Requires BLUETOOTH_SCAN and BLUETOOTH_CONNECT permissions.
     *
     * @return A Flow emitting [DiscoveryScanEvent]s during the scan process.
     */
    @JvmSynthetic
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun discoveryScanFlow(): Flow<DiscoveryScanEvent> =
        impl.discoveryScanFlow()

    /**
     * Stops the ongoing classic Bluetooth discovery scan.
     */
    @JvmStatic
    fun stopDiscoveryScan() = impl.stopDiscoveryScan()

    /**
     * Stops the ongoing BLE S2P scan.
     *
     * Requires BLUETOOTH_SCAN permission.
     */
    @JvmStatic
    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun stopS2PScan() = impl.stopS2PScan()
}
