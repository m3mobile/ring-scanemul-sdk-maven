package com.m3.ring.scanemul.sdk.api.model.symbologies.upufics

data class UpuFicsPostalVals(
    val enabled: Boolean? = null
)