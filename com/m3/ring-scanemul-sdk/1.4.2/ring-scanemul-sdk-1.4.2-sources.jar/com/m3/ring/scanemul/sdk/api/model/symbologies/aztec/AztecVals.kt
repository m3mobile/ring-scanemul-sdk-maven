package com.m3.ring.scanemul.sdk.api.model.symbologies.aztec

data class AztecVals(
    val enabled: Boolean? = null
)
