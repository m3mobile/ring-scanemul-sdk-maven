package com.m3.ring.scanemul.sdk.api.error.exception

class ConnectToDeviceException(
    override val message: String?
) : Exception(message)