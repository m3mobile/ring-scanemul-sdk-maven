package com.m3.ring.scanemul.sdk.api.error.exception

class ScanException(
    override val message: String
) : Exception(message)