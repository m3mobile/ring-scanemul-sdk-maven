package com.m3.ring.scanemul.sdk.internal.connection.domain

import android.Manifest
import android.bluetooth.BluetoothDevice
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.core.TransportSession

interface ConnectionRepo {
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    fun connectAndFetchAllSettings(
        device: BluetoothDevice,
        onSuccess: (session: TransportSession) -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    )

    fun scopeCancel()
}
