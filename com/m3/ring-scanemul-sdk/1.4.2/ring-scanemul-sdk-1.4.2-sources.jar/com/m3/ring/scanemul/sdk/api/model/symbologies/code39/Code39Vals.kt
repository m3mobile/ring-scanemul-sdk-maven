package com.m3.ring.scanemul.sdk.api.model.symbologies.code39

data class Code39Vals(
    val enabled: Boolean? = null,
    val triopticCode39: Boolean? = null,
    val length1: Int? = null,
    val length2: Int? = null,
    val reducedQuietZone: Boolean? = null,
    val convertToCode32: Boolean? = null,
    val fullAscii: Boolean? = null,
    val reportCheckDigit: Boolean? = null,
    val reportCode32Prefix: Boolean? = null,
    val securityLevel: Code39Type.SecurityType? = null,
    val verifyCheckDigit: Boolean? = null
)