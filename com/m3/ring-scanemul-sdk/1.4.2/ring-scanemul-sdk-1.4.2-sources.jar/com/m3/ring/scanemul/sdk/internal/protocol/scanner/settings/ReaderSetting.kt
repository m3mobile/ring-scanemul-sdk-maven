package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings

import com.m3.ring.scanemul.sdk.api.model.settings.reader.ReaderType
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
object ReaderSetting {
    /* Ids */
    enum class ReaderIds(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("readerLaserOnTime")
        @BindValue(ValueType.INT_1BYTE)
        LASER_ON_TIME(zebra = byteArrayOf(0x88.toByte()), totinfo = byteArrayOf(0x88.toByte())),

        @BindField("readerInverse1D")
        @BindValue(ValueType.ENUM, Inverse1DVal::class)
        INVERSE_1D(zebra = byteArrayOf(0xF1.toByte(), 0x4A.toByte()), totinfo = byteArrayOf(0xF2.toByte(), 0x91.toByte())),

        @BindField("readerQuietZoneLevelFor1D")
        @BindValue(ValueType.ENUM, QuietZoneLevelFor1DVal::class)
        QUIET_ZONE_LEVEL_FOR_1D(zebra = byteArrayOf(0xF8.toByte(), 0x05.toByte(), 0x08.toByte())),

        @BindField("readerPoorQualityDecodeEffort")
        @BindValue(ValueType.ENUM, PoorQualityDecodeEffortVal::class)
        POOR_QUALITY_DECODE_EFFORT(zebra = byteArrayOf(0x4D), totinfo = byteArrayOf(0x4E));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnumNameMatch(external = ReaderType.Inverse1DType::class)
    enum class Inverse1DVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        REGULAR_ONLY(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00)),
        INVERSE_ONLY(zebra = byteArrayOf(0x01), totinfo = null),
        INVERSE_AUTODETECT(zebra = byteArrayOf(0x02), totinfo = byteArrayOf(0x01))
    }

    @EnumNameMatch(external = ReaderType.QuietZoneLevelType::class)
    enum class QuietZoneLevelFor1DVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        LEVEL_0(zebra = byteArrayOf(0x00)),
        LEVEL_1(zebra = byteArrayOf(0x01)),
        LEVEL_2(zebra = byteArrayOf(0x02)),
        LEVEL_3(zebra = byteArrayOf(0x03))
    }

    @EnumNameMatch(external = ReaderType.PoorQualityDecodeEffortType::class)
    enum class PoorQualityDecodeEffortVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        LEVEL_0(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x01)),
        LEVEL_1(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x02)),
        LEVEL_2(zebra = byteArrayOf(0x02), totinfo = byteArrayOf(0x03)),
        LEVEL_3(zebra = byteArrayOf(0x03), totinfo = byteArrayOf(0x04))
    }
}
