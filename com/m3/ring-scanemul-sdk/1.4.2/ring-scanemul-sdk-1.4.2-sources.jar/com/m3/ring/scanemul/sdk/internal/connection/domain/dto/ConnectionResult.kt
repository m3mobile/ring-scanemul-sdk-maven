package com.m3.ring.scanemul.sdk.internal.connection.domain.dto

import android.bluetooth.BluetoothDevice

interface ConnectionResult {
    val isSuccess: Boolean
    val errorMsg: String?
    val device: BluetoothDevice
}