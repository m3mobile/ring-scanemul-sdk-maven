package com.m3.ring.scanemul.sdk.api.model

import com.m3.ring.scanemul.sdk.api.model.device.BtModeType
import com.m3.ring.scanemul.sdk.api.model.device.ScannerIdType
import com.m3.ring.scanemul.sdk.api.model.device.VendorType

data class DeviceInfo(
    val name: String? = null,
    val macAddress: String? = null,
    val model: String? = null,
    val vendor: VendorType? = null,
    val serialNumber: String? = null,
    val fwVersion: String? = null,
    val releaseDate: String? = null,
    val batteryPercent: Int? = null,
    val scannerId: ScannerIdType? = null,
    val btMode: BtModeType? = null,
)
