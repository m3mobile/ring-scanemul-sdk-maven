package com.m3.ring.scanemul.sdk.api.model.symbologies.maxicode

data class MaxiCodeVals(
    val enabled: Boolean? = null
)