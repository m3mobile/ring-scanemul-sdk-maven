package com.m3.ring.scanemul.sdk.api.model.settings.general

data class GeneralSettings(
    val sound: SoundType? = null,
    val vibrateEnabled: Boolean? = null,
    val ledEnabled: Boolean? = null,
    val buttonEnabled: Boolean? = null,
    val aimEnabled: Boolean? = null,
    val illuminationEnabled: Boolean? = null,
)