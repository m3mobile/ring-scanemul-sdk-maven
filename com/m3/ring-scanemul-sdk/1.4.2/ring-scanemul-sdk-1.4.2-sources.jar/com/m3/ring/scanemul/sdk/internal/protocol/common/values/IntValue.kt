package com.m3.ring.scanemul.sdk.internal.protocol.common.values

import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting

data class IntValue(val value: Int) : SettingValue {
    override fun toByteArray(vendorType: FwSetting.Vendor): ByteArray = byteArrayOf(value.toByte())
}
