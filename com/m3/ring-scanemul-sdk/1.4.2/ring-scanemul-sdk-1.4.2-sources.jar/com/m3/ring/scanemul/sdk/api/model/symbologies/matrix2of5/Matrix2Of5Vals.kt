package com.m3.ring.scanemul.sdk.api.model.symbologies.matrix2of5

data class Matrix2Of5Vals(
    val enabled: Boolean? = null,
    val length1: Int? = null,
    val length2: Int? = null,
    val redundancy: Boolean? = null,
    val reportCheckDigit: Boolean? = null,
    val verifyCheckDigit: Boolean? = null
)