package com.m3.ring.scanemul.sdk.api.model.scan

sealed class DiscoveryScanEvent {
    data object Started : DiscoveryScanEvent()
    data class DeviceFound(val device: DiscoveryDeviceModel) : DiscoveryScanEvent()
    data object Finished : DiscoveryScanEvent()
    data class Error(val errorCode: Int, val errorMsg: String) : DiscoveryScanEvent()
}