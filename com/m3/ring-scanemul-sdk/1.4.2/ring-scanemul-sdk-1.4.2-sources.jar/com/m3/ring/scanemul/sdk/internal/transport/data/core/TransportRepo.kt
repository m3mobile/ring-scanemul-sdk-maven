package com.m3.ring.scanemul.sdk.internal.transport.data.core

import android.graphics.Bitmap
import com.m3.ring.scanemul.sdk.api.error.catalog.SetSettingErrorCatalog
import com.m3.ring.scanemul.sdk.api.listener.DecodingDataListener
import com.m3.ring.scanemul.sdk.api.listener.DisconnectListener
import com.m3.ring.scanemul.sdk.internal.common.ListenerRegistry
import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.common.util.CmdUtils
import com.m3.ring.scanemul.sdk.internal.common.util.Utils
import com.m3.ring.scanemul.sdk.internal.device.profile.ScannerProfile
import com.m3.ring.scanemul.sdk.internal.device.profile.VendorProfileRegistry
import com.m3.ring.scanemul.sdk.internal.device.state.DeviceStateStore
import com.m3.ring.scanemul.sdk.internal.device.state.InternalDeviceState
import com.m3.ring.scanemul.sdk.internal.protocol.common.commands.InternalSettingCommand
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.CommandSourceType
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwCmdPreset
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwParser
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting.FwIds
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSettingInfoAccessor
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.GetAllSettingsCommands
import com.m3.ring.scanemul.sdk.internal.transport.domain.TransportManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal class TransportRepo(
    private val transportManager: TransportManager,
    private val deviceStateStore: DeviceStateStore,
) {

    private val decodingDataListenerRegistry = ListenerRegistry<DecodingDataListener>()

    // 외부용
    private val disconnectListenerRegistry = ListenerRegistry<DisconnectListener>()

    // 내부용
    private var disconnectObserver: (() -> Unit)? = null
    private val workScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val callbackScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    init {
        observeBinaryCommand()
        observeBarcodeValue()
        observeDisconnect()
    }

    /**
     * 연결이 끊어졌을 때의 이벤트를 관찰합니다.
     * 연결이 끊어지면 [DisconnectListener]를 통해 알림을 보냅니다.
     */
    private fun observeDisconnect() {
        workScope.launch {
            transportManager.observeDisconnect().distinctUntilChanged().collect {
                notifyDisconnect()

                deviceStateStore.clearDeviceStateListeners()
                deviceStateStore.clearDeviceInfo()

                // 리스너 정리하지 않으면, 연결할 때 마다 리스너가 쌓여서 중복 호출될 수 있음
                decodingDataListenerRegistry.clear()
                disconnectListenerRegistry.clear()

                scopeCancel()
            }
        }
    }

    /**
     * 연결 끊김 이벤트 SharedFlow를 반환합니다. (Hot Stream)
     *
     * @return 연결 끊김 이벤트 SharedFlow
     */
    fun observeDisconnectWithFlow() = transportManager.observeDisconnect()

    /**
     * 바코드 데이터를 관찰합니다.
     * 바코드 데이터가 수신되면 [DecodingDataListener]를 통해 알림을 보냅니다.
     */
    private fun observeBarcodeValue() {
        workScope.launch {
            transportManager.observeBarcodeData().collect { value ->
                updateBarcodeData(value)
            }
        }
    }

    /**
     * 바코드 데이터 SharedFlow를 반환합니다. (Hot Stream)
     *
     * @return 바코드 데이터 SharedFlow
     */
    fun observeBarcodeValueWithFlow() = transportManager.observeBarcodeData()

    /**
     * 펌웨어 및 스캐너 설정 관련 바이너리 명령어를 관찰합니다.
     * 수신된 명령어의 소스 타입에 따라 스캐너 설정 또는 펌웨어 설정을 처리합니다.
     */
    private fun observeBinaryCommand() {
        workScope.launch {
            transportManager.observeBinaryCommandData().filter { CmdUtils.isBinaryCommand(it) }.collect {
                when (it[CmdUtils.SOURCE_TYPE_INDEX]) {
                    CommandSourceType.SCANNER.value -> handleScannerCommand(it)
                    CommandSourceType.FIRMWARE.value -> handleFirmwareCommand(it)
                }
            }
        }
    }


    /**
     * 연결된 블루투스 디바이스로부터 전달 받은 설정(Setting) 명령어를 처리합니다.
     * 명령어의 [CommandSourceType]이 SCANNER인 경우, 스캐너 설정 정보를 파싱하고
     * [DeviceStateStore]에 업데이트합니다.
     *
     * @param data 스캐너 설정값이 포함되어 있는 명령어
     */
    private fun handleScannerCommand(data: ByteArray) {
        val deviceInfo = deviceStateStore.getDeviceInfo()

        if (deviceInfo.fwSettingInfo.vendor == null) {
            throw IllegalArgumentException("ScannerType is null!")
        }

        val newScannerSettingInfo =
            CmdUtils.parseScannerSettings(data, deviceInfo, deviceInfo.fwSettingInfo.vendor)
        deviceStateStore.updateDeviceInfo(deviceInfo.copy(scannerSettingInfo = newScannerSettingInfo))
    }


    /**
     * 연결된 블루투스 디바이스로부터 전달 받은 설정 명령어를 처리합니다.
     * [DeviceStateStore]에 업데이트합니다.
     *
     * @param data 펌웨어 설정값이 포함되어 있는 명령어
     */
    private fun handleFirmwareCommand(data: ByteArray) {
        val deviceInfo = deviceStateStore.getDeviceInfo()

        when (data[CmdUtils.SUB_COMMAND_INDEX]) {
            FwIds.SET_ALL_FW_CMDS.idByte -> {
                val newFirmwareSettings = FwParser.parseFwAllSettings(data)
                deviceStateStore.updateDeviceInfo(deviceInfo.copy(fwSettingInfo = newFirmwareSettings))
            }

            else -> {
                val cmdId = data.getOrNull(CmdUtils.SUB_COMMAND_INDEX) ?: return
                val valueByte = data.sliceArray((CmdUtils.SUB_COMMAND_INDEX + 1) until (data.size - 2))
                val newFirmwareSetting = FwParser.parseFwSettings(
                    cmdId, valueByte, deviceInfo.fwSettingInfo
                )
                deviceStateStore.updateDeviceInfo(deviceInfo.copy(fwSettingInfo = newFirmwareSetting))
            }
        }
    }

    /**
     * 블루투스 디바이스에 데이터를 쓰기 요청합니다.
     *
     * @param data 쓰기 요청할 데이터
     */
    fun requestWrite(data: ByteArray) {
        transportManager.requestWrite(data)
    }

    /**
     * 블루투스 디바이스와 연결을 해제합니다.
     *
     * @param onSuccess 연결 해제 성공 콜백
     * @param onFailure 연결 해제 실패 콜백
     */
    fun disconnect(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit) {
        transportManager.disconnect(
            onSuccess = {
                callbackScope.launch { onSuccess() }
            },
            onFailure = { msg ->
                callbackScope.launch { onFailure(msg) }
            })
    }

    /**
     * 현재 설정되어 있는 모든 스캐너 용 설정값을 요청합니다.
     */
    fun requestGetScannerAllSettings(onResult: (Boolean) -> Unit) {
        val vendorType = deviceStateStore.getDeviceInfo().fwSettingInfo.vendor
            ?: throw IllegalArgumentException("Vendor Type is null!")

        workScope.launch {
            transportManager.requestGetScannerAllSettings(
                GetAllSettingsCommands.getAllSettings(vendorType),
                onResult = { result ->
                    callbackScope.launch { onResult(result) }
                }
            )
        }
    }

    /**
     * 현재 설정되어 있는 모든 펌웨어 용 설정값을 요청합니다.
     * 이 명령은 펌웨어 ID가 FIRMWARE_GET_ALL_CMDS로 설정된 경우에 사용됩니다.
     */
    fun requestGetFirmwareAllSettings() {
        workScope.launch {
            transportManager.requestWrite(CmdUtils.createFirmwareGetCommand(FwIds.SET_ALL_FW_CMDS.idByte))
        }
    }

    /**
     * 블루투스 디바이스에 새로운 설정을 요청합니다.
     *
     * @param setting 적용할 설정 정보
     * @param onSuccess 설정 성공 콜백
     * @param onFailure 설정 실패 콜백
     */
    fun setSetting(
        setting: InternalSettingCommand,
        onSuccess: () -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit,
    ) {
        fun fail(catalog: SetSettingErrorCatalog, msg: String = catalog.msg) {
            callbackScope.launch {
                onFailure(catalog.code, msg)
            }
        }

        val fwSettingInfo = deviceStateStore.getDeviceInfo().fwSettingInfo

        val vendorType = fwSettingInfo.vendor
            ?: throw IllegalArgumentException("Vendor Type is null!") // 연결될 때, VendorType이 null일 수 없기 때문에, 설정 적용 전, 반드시 VendorType이 존재해야 함

        val registry = VendorProfileRegistry.registry[vendorType]
            ?: run {
                callbackScope.launch {
                    Logger.e(msg = "=========== Vendor profile not found for $vendorType ===========")
                    fail(SetSettingErrorCatalog.SDK_ERROR)
                }
                return
            }

        val (cmd, valueByte) = when (setting) {
            is InternalSettingCommand.Error -> {
                fail(SetSettingErrorCatalog.INVALID_COMMAND, setting.message)
                return
            }

            is InternalSettingCommand.Valid.Scanner -> {
                createScannerCmd(setting, registry, vendorType)
                    ?: run {
                        fail(SetSettingErrorCatalog.SDK_ERROR)
                        return
                    }
            }

            is InternalSettingCommand.Valid.Firmware -> {
                if (!FwSettingInfoAccessor.hasValue(fwSettingInfo, setting.id)) {
                    fail(
                        SetSettingErrorCatalog.UNSUPPORTED_SETTING,
                        "${SetSettingErrorCatalog.UNSUPPORTED_SETTING.msg}: ${setting.id}"
                    )
                    return
                }

                createFwCmd(setting)
                    ?: run {
                        fail(SetSettingErrorCatalog.SDK_ERROR)
                        return
                    }
            }
        }

        val validSetting = setting as? InternalSettingCommand.Valid
            ?: error("InternalSettingCommand.Error must not reach handleSetSettingResult")

        workScope.launch {
            val success = try {
                transportManager.requestWriteWithAck(cmd).await()
            } catch (e: TimeoutCancellationException) {
                null
            }

            val deviceInfo = deviceStateStore.getDeviceInfo()

            callbackScope.launch {
                handleSetSettingResult(
                    success,
                    validSetting,
                    valueByte,
                    deviceInfo,
                    onSuccess,
                    onFailure
                )
            }
        }
    }

    /**
     * 디바이스의 모든 설정을 기본값으로 초기화합니다.
     * 이후, 스캐너와 펌웨어의 모든 설정을 다시 요청하여
     * 디바이스의 상태를 최신으로 유지합니다.
     */
    fun setDefaultSetting(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit) {
        workScope.launch {
            val cmd = FwCmdPreset.default
            transportManager.requestWrite(cmd)
            delay(2_000)
            requestGetFirmwareAllSettings()
            delay(500)
            requestGetScannerAllSettings() { isSuccess ->
                if (!isSuccess) {
                    onFailure("Failed to fetch scanner settings after reset.")
                    return@requestGetScannerAllSettings
                }
                onSuccess()
            }
        }
    }

    /**
     * 스캐너 설정 명령어를 생성합니다.
     * @param setting 설정 정보
     * @param registry 벤더 프로필 레지스트리
     * @param vendorType 벤더 타입
     *
     * @return 설정 명령어 바이트 배열과 설정 값 바이트 배열의 쌍, 생성 실패 시 null
     */
    private fun createScannerCmd(
        setting: InternalSettingCommand.Valid.Scanner,
        registry: ScannerProfile,
        vendorType: FwSetting.Vendor
    ): Pair<ByteArray, ByteArray>? {
        val idByte = setting.id.toByteArray(vendorType) ?: return null
        val valueByte = setting.value?.toByteArray(vendorType) ?: return null
        return Pair(registry.createSetCommand(idByte + valueByte), valueByte)
    }

    /**
     * 펌웨어 설정 명령어를 생성합니다.
     *
     * @param setting 설정 정보
     * @return 설정 명령어 바이트 배열과 설정 값 바이트 배열의 쌍, 생성 실패 시 null
     */
    private fun createFwCmd(
        setting: InternalSettingCommand.Valid.Firmware,
    ): Pair<ByteArray, ByteArray>? {
        val idByte = byteArrayOf(setting.id.idByte)
        val valueByte = setting.value?.toByteArray() ?: return null
        return Pair(CmdUtils.createFirmwareSetCommand(idByte + valueByte), valueByte)
    }

    /**
     * 설정 요청에 대한 결과를 처리합니다.
     *
     * @param success 설정 성공 여부
     * @param setting 설정 정보
     * @param valueByte 설정 값 바이트 배열
     * @param deviceInfo 디바이스 정보
     * @param onSuccess 설정 성공 콜백
     * @param onFailure 설정 실패 콜백
     */
    private fun handleSetSettingResult(
        success: Boolean?,
        setting: InternalSettingCommand.Valid,
        valueByte: ByteArray,
        deviceInfo: InternalDeviceState,
        onSuccess: () -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        when (success) {
            true -> {
                updateSettingInfoOnSuccess(setting, valueByte, deviceInfo)
                when (setting) {
                    is InternalSettingCommand.Valid.Scanner ->
                        Logger.i(msg = "=========== Set Success [SCANNER] id=${setting.id}, value=${setting.value} ===========")

                    is InternalSettingCommand.Valid.Firmware ->
                        Logger.i(msg = "=========== Set Success [FIRMWARE] id=${setting.id}, value=${setting.value} ===========")
                }
                onSuccess()
            }

            false -> {
                val errorCatalog = SetSettingErrorCatalog.SETTING_FAILED
                val errorMsg: String = when (setting) {
                    is InternalSettingCommand.Valid.Scanner ->
                        "${errorCatalog.msg} id=${setting.id}"

                    is InternalSettingCommand.Valid.Firmware ->
                        "${errorCatalog.msg} id=${setting.id}"
                }
                Logger.e(msg = errorMsg)
                onFailure(errorCatalog.code, errorMsg)
            }

            null -> {
                val errorCatalog = SetSettingErrorCatalog.REQUEST_TIMEOUT
                Logger.e(msg = errorCatalog.msg)
                onFailure(errorCatalog.code, errorCatalog.msg)
            }
        }
    }


    /**
     * 설정이 성공적으로 적용되었을 때, InternalDeviceState에 설정했던 값으로 업데이트합니다.
     */
    private fun updateSettingInfoOnSuccess(
        setting: InternalSettingCommand.Valid,
        valueByte: ByteArray,
        deviceInfo: InternalDeviceState
    ) {
        val vendorType = deviceInfo.fwSettingInfo.vendor
            ?: throw IllegalArgumentException("Vendor Type is null!")

        when (setting) {
            is InternalSettingCommand.Valid.Scanner -> {
                val newScanner = setting.id.updateScannerSettingInfo(vendorType, valueByte, deviceInfo.scannerSettingInfo)
                deviceStateStore.updateDeviceInfo(deviceInfo.copy(scannerSettingInfo = newScanner))
            }

            is InternalSettingCommand.Valid.Firmware -> {
                val newFw = FwParser.getFwSettingInfo(
                    setting.id, valueByte, deviceInfo.fwSettingInfo
                )
                deviceStateStore.updateDeviceInfo(deviceInfo.copy(fwSettingInfo = newFw))
            }
        }
    }

    /**
     * 모든 설정을 담은 QR 코드를 생성합니다.
     *
     * @param btMode QR 코드에 포함할 블루투스 모드 설정
     * @return QR 코드 이미지
     */
    fun generateQrBitmap(btMode: FwSetting.BtModeSetting?): Bitmap? {
        val curDeviceInfo = deviceStateStore.getDeviceInfo()
        val targetDeviceInfo = curDeviceInfo.copy(fwSettingInfo = curDeviceInfo.fwSettingInfo.copy(mode = btMode))
        return Utils.generateQrBitmap(targetDeviceInfo)
    }

    /**
     * TransportRepo에서 관리 중인 모든 코루틴 작업(scope)을 종료합니다.
     *
     * 연결 해제(Disconnect) 시점 등에서 호출하여
     * 백그라운드 작업/리소스가 남지 않도록 정리합니다.
     */
    private fun scopeCancel() {
        callbackScope.cancel() // 모든 callback 작업 종료
        workScope.cancel()  // 모든 job 종료
    }

    /* =============== About listeners ================ */
    /* Barcode */
    fun addDecodingDataListener(barCodeDataListener: DecodingDataListener) {
        decodingDataListenerRegistry.add(barCodeDataListener)
    }

    fun removeDecodingDataListener(barCodeDataListener: DecodingDataListener) {
        decodingDataListenerRegistry.remove(barCodeDataListener)
    }

    private fun updateBarcodeData(data: ByteArray) {
        callbackScope.launch {
            decodingDataListenerRegistry.notifyAll {
                runCatching { it.onReceive(data) }
                    .onFailure { Logger.e(msg = "=========== Listener error in onReceive: ${it.message} ===========") }
            }
        }
    }

    /* Disconnect */
    fun addDisconnectListener(disconnectListener: DisconnectListener) {
        disconnectListenerRegistry.add(disconnectListener)
    }

    fun removeDisconnectListener(disconnectListener: DisconnectListener) {
        disconnectListenerRegistry.remove(disconnectListener)
    }

    // Internal use only
    fun addOnDisconnected(observer: () -> Unit) {
        disconnectObserver = observer
    }

    private suspend fun notifyDisconnect() {
        withContext(Dispatchers.Main.immediate + NonCancellable) { // 반드시 실행되어야 함
            disconnectObserver?.invoke()
            disconnectListenerRegistry.notifyAll {
                runCatching { it.onDisconnect() }
                    .onFailure { Logger.e(msg = "=========== Listener error in onDisconnect: ${it.message} ===========") }
            }
        }
    }
}
