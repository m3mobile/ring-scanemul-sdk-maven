package com.m3.ring.scanemul.sdk.api.model.settings.dev

data class DevSettings(
    val batteryCallback: Boolean? = null
)