package com.m3.ring.scanemul.sdk.api.model.device

import com.m3.ring.scanemul.sdk.api.model.TypeValue

enum class VendorType : TypeValue {
    ZEBRA, TOTINFO
}