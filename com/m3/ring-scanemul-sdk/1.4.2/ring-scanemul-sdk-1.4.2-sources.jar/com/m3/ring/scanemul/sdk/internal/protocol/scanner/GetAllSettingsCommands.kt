package com.m3.ring.scanemul.sdk.internal.protocol.scanner

import com.m3.ring.scanemul.sdk.internal.common.util.CmdUtils
import com.m3.ring.scanemul.sdk.internal.device.profile.VendorProfileRegistry
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting


object GetAllSettingsCommands {
    /**
     * 모든 스캐너 용 설정 ID를 가져옵니다.
     * 이 함수는 스캐너 타입에 따라 해당하는 모든 설정 ID를 바이트 배열로 반환합니다.
     *
     * @param scannerType 스캐너의 종류를 나타내는 [FwSetting.ScannerId]입니다.
     * @return 모든 스캐너 설정 ID를 포함하는 바이트 배열을 반환합니다
     */
    private fun getAllScannerIds(vendorType: FwSetting.Vendor): ByteArray {
        return ScannerSettingInfoRegistryGenerated.allIds
            .mapNotNull { it.toByteArray(vendorType)?.toList() }
            .flatten()
            .toByteArray()
    }

    /**
     * 현재 블루투스 디바이스에 적용되어 있는 스캐너 설정을 가져옵니다.
     * 이 함수는 스캐너 타입과 설정 ID를 기반으로 Get용 명령어 패킷을 생성합니다.
     *
     * @param paramIds 가져오고자 하는 스캐너 설정 ID를 포함하는 바이트 배열입니다.
     * @param scannerType 스캐너의 종류를 나타내는 [FwSetting.ScannerId]입니다.
     * @return 스캐너 설정을 가져오기 위한 명령어 패킷을 포함하는 바이트 배열을 반환합니다.
     */
    private fun getSettings(paramIds: ByteArray, vendorType: FwSetting.Vendor): ByteArray {
        val registry = VendorProfileRegistry.registry[vendorType]
            ?: throw IllegalArgumentException("Unknown scanner type: $vendorType")

        return registry.createGetCommand(paramIds)
    }

    /**
     * 스캐너의 모든 설정을 가져옵니다.
     * 이 함수는 스캐너 타입에 따라 모든 설정을 120바이트씩 분할하여 가져옵니다.
     * 그리고 분할된 바이트 배열들을 Get 명령어를 생성하여 리스트로 반환합니다.
     *
     * @param scannerType 스캐너의 종류를 나타내는 [FwSetting.ScannerId]입니다.
     * @return Get 명령어를 반환
     */
    fun getAllSettings(vendorType: FwSetting.Vendor): List<ByteArray> {
        return getAllSettingsSpiltBy120Bytes(vendorType).map { payload ->
            getSettings(payload, vendorType)
        }
    }

    /**
     * 스캐너 타입에 따라 모든 설정을 120바이트씩 분할하여 가져옵니다.
     * 이 함수는 스캐너 타입에 맞게 설정을 분할하여 반환합니다.
     *
     * @param scannerType 스캐너의 종류를 나타내는 [FwSetting.ScannerId]입니다.
     * @return 120바이트씩 분할된 스캐너 id를 리스트로 반환합니다.
     */
    private fun getAllSettingsSpiltBy120Bytes(vendorType: FwSetting.Vendor): List<ByteArray> {
        val allSettings = getAllScannerIds(vendorType)
        return CmdUtils.splitPayloadByScannerType(allSettings, 120, vendorType)
    }
}
