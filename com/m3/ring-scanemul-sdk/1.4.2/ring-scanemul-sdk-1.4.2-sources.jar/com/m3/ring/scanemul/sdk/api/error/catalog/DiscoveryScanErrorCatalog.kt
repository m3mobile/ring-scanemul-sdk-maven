package com.m3.ring.scanemul.sdk.api.error.catalog

enum class DiscoveryScanErrorCatalog(val code: Int, val msg: String) {
    ALREADY_SCANNING(4001, "Discovery scan is already running."),
    START_FAILED(4002, "Failed to start discovery scan."),
    UNKNOWN(4100, "Unknown discovery scan error.");
}
