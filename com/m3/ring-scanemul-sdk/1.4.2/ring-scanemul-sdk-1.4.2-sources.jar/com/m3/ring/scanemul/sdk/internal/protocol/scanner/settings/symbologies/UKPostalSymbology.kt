package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
object UKPostalSymbology {
    /* Ids */
    enum class UKPostalIds(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("ukPostalEnable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0x5B)),

        @BindField("ukPostalReportCheckDigit")
        @BindValue(ValueType.ENUM, ReportCheckDigitVal::class)
        REPORT_CHECK_DIGIT(zebra = byteArrayOf(0x60));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class ReportCheckDigitVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00))
    }
}
