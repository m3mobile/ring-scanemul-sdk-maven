package com.m3.ring.scanemul.sdk.api.model.symbologies.netherland

data class NetherlandsKixVals(
    val enabled: Boolean? = null
)