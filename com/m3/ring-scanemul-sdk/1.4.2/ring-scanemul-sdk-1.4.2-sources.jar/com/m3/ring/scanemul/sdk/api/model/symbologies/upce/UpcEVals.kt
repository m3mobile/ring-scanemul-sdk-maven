package com.m3.ring.scanemul.sdk.api.model.symbologies.upce

data class UpcEVals(
    val enabled: Boolean? = null,
    val convertToUpcA: Boolean? = null,
    val preamble: UpcEType.PreambleType? = null,
    val reportCheckDigit: Boolean? = null,
    val upcE2BitsSupplementals: Boolean? = null,
    val upcE5BitsSupplementals: Boolean? = null
)