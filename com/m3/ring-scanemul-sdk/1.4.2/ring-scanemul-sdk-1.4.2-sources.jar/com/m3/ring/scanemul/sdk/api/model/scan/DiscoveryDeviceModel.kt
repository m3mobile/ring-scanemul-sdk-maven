package com.m3.ring.scanemul.sdk.api.model.scan

import android.bluetooth.BluetoothDevice

data class DiscoveryDeviceModel(
    val btDevice: BluetoothDevice,
    val rssi: Int?,
)