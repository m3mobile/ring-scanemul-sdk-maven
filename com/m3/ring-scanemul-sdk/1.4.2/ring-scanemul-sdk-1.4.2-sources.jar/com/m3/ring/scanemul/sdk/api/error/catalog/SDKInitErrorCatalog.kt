package com.m3.ring.scanemul.sdk.api.error.catalog

enum class SDKInitErrorCatalog(val code: Int, val message: String) {
    NOT_INITIALIZED(1000, "SDK not initialized. Call init() first."),
    UNKNOWN_ERROR(1100, "An unknown error has occurred."),
}