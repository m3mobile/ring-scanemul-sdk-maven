package com.m3.ring.scanemul.sdk.api.model.settings.general

import com.m3.ring.scanemul.sdk.api.model.TypeValue

enum class SoundType : TypeValue {
    ON, OFF, MUTE_ON_FAILED_SCAN
}