package com.m3.ring.scanemul.sdk.api.core

enum class ConnectionType {
    SPP, // Serial Port Profile
    BLE  // Bluetooth Low Energy
}