package com.m3.ring.scanemul.sdk.api.model.symbologies.upcean

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object UpcEanType {
    enum class SupplementalModeType : TypeValue {
        IGNORE_SUPPLEMENTALS,
        DECODE_WITH_SUPPLEMENTALS,
        AUTODISCRIMINATE_SUPPLEMENTALS,
        SMART_SUPPLEMENTAL_MODE,
        ENABLE_378_379,
        ENABLE_978_979,
        ENABLE_414_419_434_439,
        ENABLE_977,
        ENABLE_491,
        USER_PROGRAMMABLE_TYPE1,
        USER_PROGRAMMABLE_TYPE1_2,
        SMART_PLUS_USER_PROGRAMMABLE1,
        SMART_PLUS_USER_PROGRAMMABLE1_2
    }

    enum class SupplementalAimIdFormatType : TypeValue {
        SEPARATE, COMBINED, SEPARATE_TRANSMISSION
    }

    enum class CouponReportType : TypeValue {
        OLD_FORMAT, NEW_FORMAT, AUTODISCRIMINATE
    }

    enum class BooklandFormatType : TypeValue {
        ISBN10, ISBN13
    }
}
