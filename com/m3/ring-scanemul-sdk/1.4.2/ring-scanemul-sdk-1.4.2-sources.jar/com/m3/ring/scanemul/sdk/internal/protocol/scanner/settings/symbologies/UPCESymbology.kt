package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.upce.UpcEType
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
object UPCESymbology {
    /* Ids */
    enum class UPCEIds(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("upceEnable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0x02), totinfo = byteArrayOf(0x02)),

        @BindField("upceConvertToUpcA")
        @BindValue(ValueType.ENUM, ConvertToUpcAVal::class)
        CONVERT_TO_UPC_A(zebra = byteArrayOf(0x25), totinfo = byteArrayOf(0x25)),

        @BindField("upcePreamble")
        @BindValue(ValueType.ENUM, PreambleVal::class)
        PREAMBLE(zebra = byteArrayOf(0x23), totinfo = byteArrayOf(0x23)),

        @BindField("upceReportCheckDigit")
        @BindValue(ValueType.ENUM, ReportCheckDigitVal::class)
        REPORT_CHECK_DIGIT(zebra = byteArrayOf(0x29), totinfo = byteArrayOf(0x29)),

        @BindField("upce2BitsSupplementals")
        @BindValue(ValueType.ENUM, Upce2BitsSupplementalsVal::class)
        UPCE_2BITS_SUPPLEMENTALS(zebra = null, totinfo = byteArrayOf(0xF2.toByte(), 0x3D.toByte())),

        @BindField("upce5BitsSupplementals")
        @BindValue(ValueType.ENUM, Upce5BitsSupplementalsVal::class)
        UPCE_5BITS_SUPPLEMENTALS(zebra = null, totinfo = byteArrayOf(0xF2.toByte(), 0x3E.toByte()));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class ConvertToUpcAVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnumNameMatch(external = UpcEType.PreambleType::class)
    enum class PreambleVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        NONE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00)),
        SYS_CHAR(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        COUNTRY_SYS_CHAR(zebra = byteArrayOf(0x02), totinfo = byteArrayOf(0x02))
    }

    @EnableDisableEnum
    enum class ReportCheckDigitVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class Upce2BitsSupplementalsVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = null, totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = null, totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class Upce5BitsSupplementalsVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = null, totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = null, totinfo = byteArrayOf(0x00))
    }
}
