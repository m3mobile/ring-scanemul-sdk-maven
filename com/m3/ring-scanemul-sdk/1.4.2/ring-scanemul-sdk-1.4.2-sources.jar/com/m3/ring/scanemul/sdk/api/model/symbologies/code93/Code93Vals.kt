package com.m3.ring.scanemul.sdk.api.model.symbologies.code93

data class Code93Vals(
    val enabled: Boolean? = null,
    val length1: Int? = null,
    val length2: Int? = null
)