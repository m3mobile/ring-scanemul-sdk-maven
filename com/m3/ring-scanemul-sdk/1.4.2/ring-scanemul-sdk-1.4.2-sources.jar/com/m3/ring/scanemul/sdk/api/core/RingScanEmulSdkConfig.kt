package com.m3.ring.scanemul.sdk.api.core

/**
 * Configuration for M3 Ring ScanEmul SDK.
 *
 * @property connectionType The type of connection to use (SPP or BLE). Default is SPP.
 * @property isLogEnabled Flag to enable or disable logging. Default is false.
 */
data class RingScanEmulSdkConfig(
    val connectionType: ConnectionType = ConnectionType.SPP,
    val isLogEnabled: Boolean = false,
) {
    class Builder {
        private var connectionType: ConnectionType = ConnectionType.SPP
        private var isLogEnabled: Boolean = false

        fun connectionType(value: ConnectionType) = apply { connectionType = value }
        fun enableLog(value: Boolean = true) = apply { isLogEnabled = value }

        fun build() = RingScanEmulSdkConfig(connectionType, isLogEnabled)
    }

    companion object {
        @JvmStatic
        fun builder() = Builder()
    }
}