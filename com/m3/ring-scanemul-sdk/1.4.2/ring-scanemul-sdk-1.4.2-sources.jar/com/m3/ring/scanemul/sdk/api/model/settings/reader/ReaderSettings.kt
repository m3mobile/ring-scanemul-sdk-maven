package com.m3.ring.scanemul.sdk.api.model.settings.reader

data class ReaderSettings(
    val readMode: ReaderType.ReadModeType? = null,
    val laserOnTime: Int? = null,
    val inverse1D: ReaderType.Inverse1DType? = null,
    val quietZoneLevelFor1D: ReaderType.QuietZoneLevelType? = null,
    val poorQualityDecodeEffort: ReaderType.PoorQualityDecodeEffortType? = null,
)