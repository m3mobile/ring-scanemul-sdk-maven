package com.m3.ring.scanemul.sdk.api.model.symbologies.ean8

data class Ean8Vals(
    val enabled: Boolean? = null
)