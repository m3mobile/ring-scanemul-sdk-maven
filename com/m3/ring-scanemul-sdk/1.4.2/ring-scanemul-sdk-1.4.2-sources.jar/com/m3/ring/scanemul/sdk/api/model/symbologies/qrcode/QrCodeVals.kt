package com.m3.ring.scanemul.sdk.api.model.symbologies.qrcode

data class QrCodeVals(
    val enabled: Boolean? = null
)