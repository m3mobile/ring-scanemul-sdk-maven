package com.m3.ring.scanemul.sdk.internal.device.state

import com.m3.ring.scanemul.sdk.internal.protocol.common.values.IntValue
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.BasicFormatSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.GeneralSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.ReaderSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.AustralianPostalSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.AztecSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Chinese2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.CodabarSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code11Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code128Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code39Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code93Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.CompositeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.DataMatrixSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Discrete2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.DotCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Ean13Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Ean8Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1128Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DataBar14Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DataBarLimitedSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DatabarExpandedSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.HanXinSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Interleaved2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Isbt128Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.JapanesePostalSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Korean3Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Matrix2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MaxiCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MicroPdf417Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MicroQrCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MsiSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.NetherlandsKixSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Pdf417Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.QrCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UKPostalSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCASymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCE1Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCESymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCEanSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.USPlanetSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.USPostnetSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UpuFicsPostalSymbology

data class ScannerSettingInfo(

    // Australian Postal
    val australianPostalEnable: AustralianPostalSymbology.EnableVal? = null,

    // Aztec
    val aztecEnable: AztecSymbology.EnableVal? = null,

    // Chinese 2 of 5
    val chinese2Of5Enable: Chinese2Of5Symbology.EnableVal? = null,

    // Codabar
    val codabarEnable: CodabarSymbology.EnableVal? = null,
    val codabarLength1: IntValue? = null,
    val codabarLength2: IntValue? = null,
    val codabarCLSIEditing: CodabarSymbology.ClsiEditingVal? = null,
    val codabarNOTISEditing: CodabarSymbology.NotisEditingVal? = null,
    val codabarSecurityLevel: CodabarSymbology.SecurityLevelVal? = null,

    // Code 11
    val code11Enable: Code11Symbology.EnableVal? = null,
    val code11Length1: IntValue? = null,
    val code11Length2: IntValue? = null,
    val code11ReportCheckDigit: Code11Symbology.ReportCheckDigitVal? = null,
    val code11VerifyCheckDigit: Code11Symbology.VerifyCheckDigitVal? = null,

    // Code39
    val code39Enable: Code39Symbology.EnableVal? = null,
    val code39TriopticCode39: Code39Symbology.TriopticCode39Val? = null,
    val code39Length1: IntValue? = null,
    val code39Length2: IntValue? = null,
    val code39ReducedQuietZone: Code39Symbology.ReducedQuietZoneVal? = null,
    val code39ConvertToCode32: Code39Symbology.ConvertToCode32Val? = null,
    val code39FullAscii: Code39Symbology.FullAsciiVal? = null,
    val code39ReportCheckDigit: Code39Symbology.ReportCheckDigitVal? = null,
    val code39ReportCode32Prefix: Code39Symbology.ReportCode32PrefixVal? = null,
    val code39SecurityLevel: Code39Symbology.SecurityLevelVal? = null,
    val code39VerifyCheckDigit: Code39Symbology.VerifyCheckDigitVal? = null,

    // Code93
    val code93Enable: Code93Symbology.EnableVal? = null,
    val code93Length1: IntValue? = null,
    val code93Length2: IntValue? = null,

    // Code128
    val code128Enable: Code128Symbology.EnableVal? = null,
    val code128Length1: IntValue? = null,
    val code128Length2: IntValue? = null,
    val code128ReducedQuietZone: Code128Symbology.ReducedQuietZoneVal? = null,
    val code128IgnoreFNC4: Code128Symbology.IgnoreFNC4Val? = null,
    val code128CheckISBTTable: Code128Symbology.CheckISBTTableVal? = null,
    val code128ISBT128ConcatMode: Code128Symbology.ISBT128ConcatModeVal? = null,
    val code128SecurityLevel: Code128Symbology.SecurityLevelVal? = null,
    val code128EmulationMode: Code128Symbology.EmulationModeVal? = null,

    // Composite
    val compositeEnable: CompositeSymbology.EnableVal? = null, // Totinfo 전용
    val compositeAbEnable: CompositeSymbology.AbEnableVal? = null, // Zebra 전용
    val compositeCEnable: CompositeSymbology.CEnableVal? = null, // Zebra 전용
    val compositeTLC39Enable: CompositeSymbology.Tlc39EnableVal? = null,
    val compositeUPCCompositeMode: CompositeSymbology.UpcCompositeModeVal? = null,

    // DataMatrix
    val dataMatrixEnable: DataMatrixSymbology.EnableVal? = null,
    val dataMatrixInverse: DataMatrixSymbology.InverseVal? = null,
    val dataMatrixDecodeMirrorImages: DataMatrixSymbology.DecodeMirrorImagesVal? = null,
    val dataMatrixGS1DataMatrix: DataMatrixSymbology.Gs1DataMatrixVal? = null,

    // Discrete 2 of 5
    val discrete2Of5Enable: Discrete2Of5Symbology.EnableVal? = null,
    val discrete2Of5Length1: IntValue? = null,
    val discrete2Of5Length2: IntValue? = null,

    // DotCode
    val dotCodeEnable: DotCodeSymbology.EnableVal? = null,
    val dotCodeInverse: DotCodeSymbology.InverseVal? = null,
    val dotCodeMirror: DotCodeSymbology.MirrorVal? = null,
    val dotCodePrioritize: DotCodeSymbology.PrioritizeVal? = null,

    // EAN-8
    val ean8Enable: Ean8Symbology.EnableVal? = null,

    // EAN-13
    val ean13Enable: Ean13Symbology.EnableVal? = null,

    // GS1 DataBar 14
    val gs1Databar14Enable: Gs1DataBar14Symbology.EnableVal? = null,

    // GS1 DataBarExpanded
    val gs1DatabarExpandedEnable: Gs1DatabarExpandedSymbology.EnableVal? = null,

    // GS1 DataBarLimited
    val gs1DataBarLimitedEnable: Gs1DataBarLimitedSymbology.EnableVal? = null,
    val gs1DataBarLimitedSecurityLevel: Gs1DataBarLimitedSymbology.LimitedSecurityLevelVal? = null,

    //GS1-128
    val gs1128Enable: Gs1128Symbology.EnableVal? = null,

    // HanXin
    val hanXinEnable: HanXinSymbology.EnableVal? = null,
    val hanXinInverse: HanXinSymbology.InverseVal? = null,

    // Interleaved 2 of 5
    val interleaved2Of5Enable: Interleaved2Of5Symbology.EnableVal? = null,
    val interleaved2Of5Length1: IntValue? = null,
    val interleaved2Of5Length2: IntValue? = null,
    val interleaved2Of5CheckDigit: Interleaved2Of5Symbology.CheckDigitVal? = null,
    val interleaved2Of5ReportCheckDigit: Interleaved2Of5Symbology.ReportCheckDigitVal? = null,
    val interleaved2Of5SecurityLevel: Interleaved2Of5Symbology.SecurityLevelVal? = null,
    val interleaved2Of5ConvertITF14ToEAN13: Interleaved2Of5Symbology.ConvertITF14ToEAN13Val? = null,
    val interleaved2Of5ReducedQuietZone: Interleaved2Of5Symbology.ReducedQuietZoneVal? = null,

    //Isbt-128
    val isbt128Enable: Isbt128Symbology.EnableVal? = null,

    // Japanese Postal
    val japanesePostalEnable: JapanesePostalSymbology.EnableVal? = null,

    // Korean 3 of 5
    val korean3Of5Enable: Korean3Of5Symbology.EnableVal? = null,

    // Matrix 2 of 5
    val matrix2Of5Enable: Matrix2Of5Symbology.EnableVal? = null,
    val matrix2Of5Length1: IntValue? = null,
    val matrix2Of5Length2: IntValue? = null,
    val matrix2Of5Redundancy: Matrix2Of5Symbology.RedundancyVal? = null,
    val matrix2Of5ReportCheckDigit: Matrix2Of5Symbology.ReportCheckDigitVal? = null,
    val matrix2Of5VerifyCheckDigit: Matrix2Of5Symbology.VerifyCheckDigitVal? = null,

    // Maxicode
    val maxicodeEnable: MaxiCodeSymbology.EnableVal? = null,

    // Micro PDF417
    val microPdf417Enable: MicroPdf417Symbology.EnableVal? = null,

    // Micro QR Code
    val microQrCodeEnable: MicroQrCodeSymbology.EnableVal? = null,

    // MSI
    val msiEnable: MsiSymbology.EnableVal? = null,
    val msiLength1: IntValue? = null,
    val msiLength2: IntValue? = null,
    val msiCheckDigit: MsiSymbology.CheckDigitVal? = null,
    val msiCheckDigitScheme: MsiSymbology.CheckDigitSchemeVal? = null,
    val msiReportCheckDigit: MsiSymbology.ReportCheckDigitVal? = null,

    // Netherlands KIX
    val netherlandsKixEnable: NetherlandsKixSymbology.EnableVal? = null,

    /* 1차 릴리즈에서는 OCR, MICR 기능 제외, Jira: https://m3-mobile.atlassian.net/browse/DEVWR15-26 */
    // OCR-A
//    val ocrAEnable: OcrAValues.Enable? = null,
    // OCR-B
//    val ocrBEnable: OcrBValues.Enable? = null,
    // Micr E13B
//    val micrE13bEnable: MicrE13bValues.Enable? = null,

    // PDF417
    val pdf417Enable: Pdf417Symbology.EnableVal? = null,

    // QR Code
    val qrCodeEnable: QrCodeSymbology.EnableVal? = null,

    // UK Postal
    val ukPostalEnable: UKPostalSymbology.EnableVal? = null,
    val ukPostalReportCheckDigit: UKPostalSymbology.ReportCheckDigitVal? = null,

    // UPC-A
    val upcaEnable: UPCASymbology.EnableVal? = null,
    val upcaReportCheckDigit: UPCASymbology.ReportCheckDigitVal? = null,
    val upcaPreamble: UPCASymbology.PreambleVal? = null,
    val upca2BitsSupplementals: UPCASymbology.Upca2BitsSupplementalsVal? = null,
    val upca5BitsSupplementals: UPCASymbology.Upca5BitsSupplementalsVal? = null,

    // UPC-E1
    val upcE1Enable: UPCE1Symbology.EnableVal? = null,
    val upcE1ConvertToUpcA: UPCE1Symbology.ConvertToUpcAVal? = null,
    val upcE1Preamble: UPCE1Symbology.PreambleVal? = null,
    val upcE1ReportCheckDigit: UPCE1Symbology.ReportCheckDigitVal? = null,

    // UPC-EAN
    val upcEanReportEan8CheckDigit: UPCEanSymbology.ReportEan8CheckDigitVal? = null,
    val upcEanReportEan13CheckDigit: UPCEanSymbology.ReportEan13CheckDigitVal? = null,
    val upcEanSupplementalMode: UPCEanSymbology.SupplementalModeVal? = null,
    val upcEanSupplementalAimIdFormat: UPCEanSymbology.SupplementalAimIdFormatVal? = null,
    val upcEanReducedQuietZone: UPCEanSymbology.ReducedQuietZoneVal? = null,
    val upcEanBooklandEnable: UPCEanSymbology.BooklandEnableVal? = null,
    val upcEanBooklandFormat: UPCEanSymbology.BooklandFormatVal? = null,
    val upcEanUccCouponExtend: UPCEanSymbology.UccCouponExtendVal? = null,
    val upcEanCouponReport: UPCEanSymbology.CouponReportVal? = null,
    val upcEanIssnEan: UPCEanSymbology.IssnEanVal? = null,
    val upcEanSupplementalRedundancy: IntValue? = null,
    val upcEanSupplemental2: UPCEanSymbology.Supplemental2Val? = null,
    val upcEanSupplemental5: UPCEanSymbology.Supplemental5Val? = null,

    val upcEan8ReadSupplements: UPCEanSymbology.Ean8ReadSupplementsVal? = null,
    val upcEan13ReadSupplements: UPCEanSymbology.Ean13ReadSupplementsVal? = null,
    val upcEan8Supplemental2: UPCEanSymbology.Ean8Supplemental2Val? = null,
    val upcEan13Supplemental2: UPCEanSymbology.Ean13Supplemental2Val? = null,
    val upcEan8Supplemental5: UPCEanSymbology.Ean8Supplemental5Val? = null,
    val upcEan13Supplemental5: UPCEanSymbology.Ean13Supplemental5Val? = null,


    // UPC-E
    val upceEnable: UPCESymbology.EnableVal? = null,
    val upceConvertToUpcA: UPCESymbology.ConvertToUpcAVal? = null,
    val upcePreamble: UPCESymbology.PreambleVal? = null,
    val upceReportCheckDigit: UPCESymbology.ReportCheckDigitVal? = null,
    val upce2BitsSupplementals: UPCESymbology.Upce2BitsSupplementalsVal? = null,
    val upce5BitsSupplementals: UPCESymbology.Upce5BitsSupplementalsVal? = null,

    // UPU FICS Postal
    val upuFicsPostalEnable: UpuFicsPostalSymbology.EnableVal? = null,

    // US Planet
    val usPlanetEnable: USPlanetSymbology.EnableVal? = null,
    val usPlanetReportCheckDigit: USPlanetSymbology.ReportCheckDigitVal? = null,

    // US Postnet
    val usPostnetEnable: USPostnetSymbology.EnableVal? = null,

    // Reader Setting
    val readerLaserOnTime: IntValue? = null,
    val readerInverse1D: ReaderSetting.Inverse1DVal? = null,
    val readerQuietZoneLevelFor1D: ReaderSetting.QuietZoneLevelFor1DVal? = null,
    val readerPoorQualityDecodeEffort: ReaderSetting.PoorQualityDecodeEffortVal? = null,

    // General Settings
    val aim: GeneralSetting.AimVal? = null,
    val illumination: GeneralSetting.IlluminationVal? = null,

    // Basic Format Settings
    val transmitCodeId: BasicFormatSetting.TransmitCodeIdVal? = null
)
