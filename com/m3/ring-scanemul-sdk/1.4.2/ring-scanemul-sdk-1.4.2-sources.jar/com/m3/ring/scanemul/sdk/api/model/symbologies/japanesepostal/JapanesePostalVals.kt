package com.m3.ring.scanemul.sdk.api.model.symbologies.japanesepostal

data class JapanesePostalVals(
    val enabled: Boolean? = null
)