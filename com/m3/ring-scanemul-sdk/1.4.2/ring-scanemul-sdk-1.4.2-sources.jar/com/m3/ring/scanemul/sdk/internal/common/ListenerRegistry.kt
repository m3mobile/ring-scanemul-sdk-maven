package com.m3.ring.scanemul.sdk.internal.common

/**
 * 리스너를 등록하고 관리하는 클래스입니다.
 * @param T 리스너 타입
 */
class ListenerRegistry<T> {
    private val listeners = mutableSetOf<T>()
    fun add(listener: T) {
        listeners += listener
    }

    fun remove(listener: T) {
        listeners -= listener
    }

    fun notifyAll(action: (T) -> Unit) {
        listeners.forEach { action(it) }
    }

    fun clear() {
        listeners.clear()
    }
}