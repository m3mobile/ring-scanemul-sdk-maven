package com.m3.ring.scanemul.sdk.internal.connection.data

import android.Manifest
import android.bluetooth.BluetoothDevice
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.core.ConnectionType
import com.m3.ring.scanemul.sdk.api.core.TransportSession
import com.m3.ring.scanemul.sdk.api.error.catalog.ConnectErrorCatalog
import com.m3.ring.scanemul.sdk.api.listener.DisconnectListener
import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.connection.data.ble.dto.BLEConnectionResult
import com.m3.ring.scanemul.sdk.internal.connection.data.spp.dto.SPPConnectionResult
import com.m3.ring.scanemul.sdk.internal.connection.domain.ConnectionManager
import com.m3.ring.scanemul.sdk.internal.connection.domain.ConnectionRepo
import com.m3.ring.scanemul.sdk.internal.device.state.DeviceStateStore
import com.m3.ring.scanemul.sdk.internal.transport.data.core.TransportRepo
import com.m3.ring.scanemul.sdk.internal.transport.data.core.TransportSessionFactory
import com.m3.ring.scanemul.sdk.internal.transport.data.core.TransportSessionImpl
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

internal class ConnectionRepoImpl(
    private val connectionType: ConnectionType,
    private val connectionManager: ConnectionManager,
    private val deviceStateStore: DeviceStateStore
) : ConnectionRepo {
    private lateinit var workScope: CoroutineScope
    private lateinit var callbackScope: CoroutineScope
    private var session: TransportSession? = null
    private val isConnecting = AtomicBoolean(false)

    /**
     * 디바이스와 연결을 요청하고 성공하면 전체 설정을 가져옵니다.
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    override fun connectAndFetchAllSettings(
        device: BluetoothDevice,
        onSuccess: (session: TransportSession) -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        // 연결 요청 마다 새로운 코루틴 스코프 생성
        workScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        callbackScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

        if (!isConnecting.compareAndSet(false, true)) {
            callbackScope.launch {
                val catalog = ConnectErrorCatalog.ALREADY_CONNECTING
                runCatching { onFailure(catalog.code, catalog.msg) }
                    .onFailure { Logger.e(msg = "=========== Listener error in onFailure: ${it.message} ===========") }
            }
            return
        }

        connectToDevice(
            device = device,
            onSuccess = { transportRepo ->
                fetchAllScannerSettings(device, transportRepo) { isSuccess ->
                    if (isSuccess) {
                        val s = TransportSessionImpl(transportRepo, deviceStateStore)
                        session = s
                        callbackScope.launch {
                            isConnecting.set(false)
                            runCatching { onSuccess(s) }
                                .onFailure { Logger.e(msg = "=========== Listener error in onSuccess: ${it.message} ===========") }
                        }
                    } else {
                        callbackScope.launch {
                            isConnecting.set(false)
                            runCatching {
                                val catalog = ConnectErrorCatalog.DEVICE_SETTINGS_LOAD_FAILED
                                onFailure(catalog.code, catalog.msg)
                            }
                                .onFailure { Logger.e(msg = "=========== Listener error in onFailure ===========") }
                        }

                        scopeCancel()
                    }
                }
            },

            onFailure = { errorCode, errorMsg ->
                callbackScope.launch {
                    isConnecting.set(false)
                    runCatching {
                        onFailure(errorCode, errorMsg)
                    }.onFailure { Logger.e(msg = "=========== Listener error in onFailure ===========") }

                    scopeCancel()
                }
            }
        )
    }

    /**
     * 디바이스와 연결을 요청합니다.
     *
     * @param device 연결 요청할 디바이스
     * @param onSuccess 연결 성공 시 호출되는 콜백
     * @param onFailure 연결 실패 시 호출되는 콜백
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private fun connectToDevice(
        device: BluetoothDevice,
        onSuccess: (repo: TransportRepo) -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        var transportRepo: TransportRepo

        workScope.launch {
            val result = connectionManager.connect(device)

            if (result.isSuccess) {
                // TransportSessionFactory로 TransportRepo 생성
                transportRepo = when (connectionType) {
                    ConnectionType.SPP -> {
                        val socket = requireNotNull((result as? SPPConnectionResult)?.socket) {
                            "Expected SPP socket when connectionType=SPP"
                        }
                        TransportSessionFactory.create(
                            socket = socket,
                            scope = workScope,
                            deviceStateStore = deviceStateStore
                        )
                    }

                    ConnectionType.BLE -> {
                        val gatt = requireNotNull((result as? BLEConnectionResult)?.gatt) {
                            "Expected BLE gatt when connectionType=BLE"
                        }

                        TransportSessionFactory.create(
                            gatt = gatt,
                            scope = workScope,
                            deviceStateStore = deviceStateStore
                        )
                    }
                }

                transportRepo.addDisconnectListener(object : DisconnectListener {
                    override fun onDisconnect() {
                        // 연결 해제 시 모든 코루틴 작업 종료
                        scopeCancel()
                        session = null
                    }
                })

                runCatching { onSuccess(transportRepo) }
                    .onFailure { Logger.e(msg = "=========== Listener error in onSuccess: ${it.message} ===========") }

            } else {
                val catalog = ConnectErrorCatalog.CONNECTION_FAILED
                val errorMsg = result.errorMsg ?: catalog.msg
                runCatching { onFailure(catalog.code, errorMsg) }
                    .onFailure { Logger.e(msg = "=========== Listener error in onFailure: ${it.message} ===========") }
            }
        }
    }

    /**
     * 스캐너의 모든 설정을 가져옵니다.
     *
     * @param device 연결된 디바이스
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private fun fetchAllScannerSettings(device: BluetoothDevice, repo: TransportRepo, onResult: (Boolean) -> Unit) {
        workScope.launch {
            deviceStateStore.updateDeviceInfo(deviceStateStore.getDeviceInfo().copy(name = device.name, macAddress = device.address))
            repo.requestGetFirmwareAllSettings()
            delay(500) // 펌웨어 설정 요청 후 약간의 지연
            repo.requestGetScannerAllSettings { isSuccess ->
                runCatching { onResult(isSuccess) }
                    .onFailure { Logger.e(msg = "=========== Listener error in onResult: ${it.message} ===========") }
            }
        }
    }

    /**
     * ConnectionRepo에서 관리 중인 모든 코루틴 작업(scope)을 종료합니다.
     *
     * 연결 해제(Disconnect) 시점 등에서 호출하여
     * 백그라운드 작업/리소스가 남지 않도록 정리합니다.
     */
    override fun scopeCancel() {
        workScope.cancel()  // 모든 job 종료
        callbackScope.cancel() // all callback jobs 종료
    }
}
