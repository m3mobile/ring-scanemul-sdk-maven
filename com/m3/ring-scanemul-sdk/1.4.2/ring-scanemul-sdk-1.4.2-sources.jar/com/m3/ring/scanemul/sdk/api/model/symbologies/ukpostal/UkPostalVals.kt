package com.m3.ring.scanemul.sdk.api.model.symbologies.ukpostal

data class UkPostalVals(
    val enabled: Boolean? = null,
    val reportCheckDigit: Boolean? = null
)