package com.m3.ring.scanemul.sdk.api.model.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.australian.AustralianVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.aztec.AztecVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.chinese2of5.Chinese2Of5Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.codabar.CodabarVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.code11.Code11Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.code128.Code128Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.code39.Code39Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.code93.Code93Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.composite.CompositeVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.datamatrix.DataMatrixVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.discrete2of5.Discrete2Of5Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.dotcode.DotCodeVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.ean13.Ean13Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.ean8.Ean8Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.gs1128.Gs1128Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.gs1databar14.Gs1DataBar14Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.gs1expanded.Gs1DataBarExpandedVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.gs1limited.Gs1DataBarLimitedVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.hanxin.HanXinVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.interleaved2of5.Interleaved2Of5Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.isbt128.Isbt128Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.japanesepostal.JapanesePostalVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.korean3of5.Korean3Of5Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.matrix2of5.Matrix2Of5Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.maxicode.MaxiCodeVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.micropdf417.MicroPdf417Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.microqr.MicroQrCodeVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.msi.MsiVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.netherland.NetherlandsKixVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.pdf417.Pdf417Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.qrcode.QrCodeVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.ukpostal.UkPostalVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.upca.UpcAVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.upce.UpcEVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.upce1.UpcE1Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.upcean.UpcEanVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.upufics.UpuFicsPostalVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.usplanet.UsPlanetVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.uspostnet.UsPostnetVals

data class Symbologies(
    val australianPostalVals: AustralianVals = AustralianVals(),
    val aztecVals: AztecVals = AztecVals(),
    val chinese2Of5Vals: Chinese2Of5Vals = Chinese2Of5Vals(),
    val codabarVals: CodabarVals = CodabarVals(),
    val code11Vals: Code11Vals = Code11Vals(),
    val code39Vals: Code39Vals = Code39Vals(),
    val code93Vals: Code93Vals = Code93Vals(),
    val code128Vals: Code128Vals = Code128Vals(),
    val compositeVals: CompositeVals = CompositeVals(),
    val dataMatrixVals: DataMatrixVals = DataMatrixVals(),
    val discrete2Of5Vals: Discrete2Of5Vals = Discrete2Of5Vals(),
    val dotCodeVals: DotCodeVals = DotCodeVals(),
    val ean8Vals: Ean8Vals = Ean8Vals(),
    val ean13Vals: Ean13Vals = Ean13Vals(),
    val gs1DataBar14Vals: Gs1DataBar14Vals = Gs1DataBar14Vals(),
    val gs1DataBarExpandedVals: Gs1DataBarExpandedVals = Gs1DataBarExpandedVals(),
    val gs1DataBarLimitedVals: Gs1DataBarLimitedVals = Gs1DataBarLimitedVals(),
    val gs1128Vals: Gs1128Vals = Gs1128Vals(),
    val hanXinVals: HanXinVals = HanXinVals(),
    val interleaved2Of5Vals: Interleaved2Of5Vals = Interleaved2Of5Vals(),
    val isbt128Vals: Isbt128Vals = Isbt128Vals(),
    val japanesePostalVals: JapanesePostalVals = JapanesePostalVals(),
    val korean3Of5Vals: Korean3Of5Vals = Korean3Of5Vals(),
    val matrix2Of5Vals: Matrix2Of5Vals = Matrix2Of5Vals(),
    val maxiCodeVals: MaxiCodeVals = MaxiCodeVals(),
    val microPdf417Vals: MicroPdf417Vals = MicroPdf417Vals(),
    val microQrCodeVals: MicroQrCodeVals = MicroQrCodeVals(),
    val msiVals: MsiVals = MsiVals(),
    val netherlandsKixVals: NetherlandsKixVals = NetherlandsKixVals(),
    val pdf417Vals: Pdf417Vals = Pdf417Vals(),
    val qrCodeVals: QrCodeVals = QrCodeVals(),
    val ukPostalVals: UkPostalVals = UkPostalVals(),
    val upcAVals: UpcAVals = UpcAVals(),
    val upcE1Vals: UpcE1Vals = UpcE1Vals(),
    val upcEanVals: UpcEanVals = UpcEanVals(),
    val upcEVals: UpcEVals = UpcEVals(),
    val upuFicsPostalVals: UpuFicsPostalVals = UpuFicsPostalVals(),
    val usPlanetVals: UsPlanetVals = UsPlanetVals(),
    val usPostnetVals: UsPostnetVals = UsPostnetVals(),
)