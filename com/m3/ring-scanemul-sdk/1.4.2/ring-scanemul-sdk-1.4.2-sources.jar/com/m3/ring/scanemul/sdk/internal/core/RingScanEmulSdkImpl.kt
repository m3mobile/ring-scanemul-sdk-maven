package com.m3.ring.scanemul.sdk.internal.core

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.graphics.Bitmap
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.BuildConfig
import com.m3.ring.scanemul.sdk.api.core.ConnectionType
import com.m3.ring.scanemul.sdk.api.core.RingScanEmul
import com.m3.ring.scanemul.sdk.api.core.RingScanEmulSdkConfig
import com.m3.ring.scanemul.sdk.api.core.TransportSession
import com.m3.ring.scanemul.sdk.api.core.RingScanEmulSdk
import com.m3.ring.scanemul.sdk.api.error.catalog.ConnectErrorCatalog
import com.m3.ring.scanemul.sdk.api.error.catalog.SDKInitErrorCatalog
import com.m3.ring.scanemul.sdk.api.error.exception.ConnectToDeviceException
import com.m3.ring.scanemul.sdk.api.error.exception.ScanException
import com.m3.ring.scanemul.sdk.api.listener.ConnectResultListener
import com.m3.ring.scanemul.sdk.api.listener.DiscoveryScanResultListener
import com.m3.ring.scanemul.sdk.api.listener.S2PScanResultListener
import com.m3.ring.scanemul.sdk.api.model.scan.DiscoveryDeviceModel
import com.m3.ring.scanemul.sdk.api.model.scan.DiscoveryScanEvent
import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.common.consts.BtConst
import com.m3.ring.scanemul.sdk.internal.common.storage.PrefManager
import com.m3.ring.scanemul.sdk.internal.common.util.Utils
import com.m3.ring.scanemul.sdk.internal.connection.data.ConnectionRepoImpl
import com.m3.ring.scanemul.sdk.internal.connection.data.ble.BLEConnectionManager
import com.m3.ring.scanemul.sdk.internal.connection.data.spp.SPPConnectionManager
import com.m3.ring.scanemul.sdk.internal.connection.domain.ConnectionRepo
import com.m3.ring.scanemul.sdk.internal.device.state.DeviceStateStore
import com.m3.ring.scanemul.sdk.internal.transport.service.TransportClient
import com.m3.ring.scanemul.sdk.internal.transport.service.TransportServiceConnector
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * SDK의 내부 구현체입니다.
 *
 * - 외부에는 [RingScanEmul] (파사드/퍼블릭 엔트리포인트)만 노출되고,
 *   실제 동작은 이 클래스가 담당합니다.
 * - 모듈을 난독화(ProGuard/R8)할 때 이 구현체와 내부 패키지는 자유롭게 난독화해도
 *   퍼블릭 API에는 영향이 없습니다(인터페이스 [RingScanEmulSdk]를 통해 접근하므로).
 */
internal class RingScanEmulSdkImpl : RingScanEmulSdk {
    private data class PendingClientRequest(
        val onReady: (TransportClient) -> Unit,
        val onError: (errorCode: Int, errorMsg: String) -> Unit
    )

    /** SDK 버전 문자열(로그 용도) */
    private val version: String = BuildConfig.SDK_VERSION

    /** SDK 초기화 여부 */
    private var isInitialized = false

    /** TransportService 바인딩 여부 플래그 */
    private var isBounded = false

    /** 현재 유효한 통신 세션(연결된 경우) */
    private var session: TransportSession? = null

    /** 블루투스 장비를 스캔 및 연결 */
    private var client: TransportClient? = null

    /** TransportService를 실행 및 관리하는 커넥터 **/
    private lateinit var connector: TransportServiceConnector

    /** SharedPreferences 접근 매니저 */
    private lateinit var prefManager: PrefManager

    /** Connect repo 팩토리 */
    private lateinit var connectionRepo: ConnectionRepo

    /** 블루투스 디바이스 장치 설정값 관리하는 클래스 */
    private lateinit var deviceStateStore: DeviceStateStore

    /** SDK 구성(연결 타입/로그 여부 등) */
    private lateinit var config: RingScanEmulSdkConfig

    /** 바인딩 완료를 기다리는 클라이언트 요청 큐 */
    private val pendingClientRequests = mutableListOf<PendingClientRequest>()

    /**
     * SDK를 초기화합니다. 한 번만 호출되어야 하며, 재호출 시 무시됩니다.
     *
     * @param context 애플리케이션 컨텍스트 권장
     * @param config 연결 타입/로그 여부 등 SDK 구성
     *
     * @throws IllegalArgumentException 현재 버전에서는 BLE 연결 타입을 지원하지 않습니다.
     */
    @Synchronized
    override fun initialize(context: Context, config: RingScanEmulSdkConfig) {
        if (isInitialized) return
        this.config = config

        if (this.config.connectionType == ConnectionType.BLE) {
            throw IllegalArgumentException("BLE connection type is not supported in v$version version.")
        }

        // 로거 초기화(로그 온/오프)
        Logger.init(this.config.isLogEnabled)

        // 프리퍼런스 준비 및 S2P 통신용 유니크 키 보장
        prefManager = PrefManager(context.getSharedPreferences(PrefManager.PREF_NAME, MODE_PRIVATE))
        if (!isExistsUniqueKey()) generateAndSaveUniqueKey()

        deviceStateStore = DeviceStateStore()
        connectionRepo = createConnectionRepoWithConnectionType(this.config.connectionType, context.applicationContext)

        // TransportService 바인딩 및 세션/클라이언트 획득
        connector = TransportServiceConnector(context.applicationContext, connectionRepo, deviceStateStore)

        // 초기화 완료 플래그 설정 및 로그 출력
        isInitialized = true
        Logger.i(msg = "=========== M3RingScanEmul initialized successfully (Version: $version) ===========")
    }


    /**
     * S2P 디바이스와 통신하기 위한 명령 문자열을 반환합니다.
     *
     * @return "헤더 + 유니크키" 형태의 명령 문자열
     * @throws IllegalStateException SDK가 아직 초기화되지 않은 경우
     */
    override fun getCmdForS2P(): String {
        check(::prefManager.isInitialized) { "SDK not initialized. Call init() first." }
        return "${BtConst.S2P_HEADER}${prefManager.getString(PrefManager.UNIQUE_KEY)}"
    }


    /**
     * S2P 연결용 GS1-128 바코드 비트맵을 생성합니다.
     *
     * @param width  비트맵 가로(px)
     * @param height 비트맵 세로(px)
     * @return 생성된 바코드 비트맵, 실패 시 null
     */
    override fun getBarcodeBitmapForS2P(width: Int, height: Int): Bitmap? {
        val cmd = getCmdForS2P()
        return Utils.generateBarcodeForS2P(width = width, height = height, content = cmd)
    }


    /**
     * BLE를 사용해 S2P 디바이스 스캔을 시작합니다(코틀린용 람다 버전).
     *
     * 필요 권한: [Manifest.permission.BLUETOOTH_SCAN], [Manifest.permission.BLUETOOTH_CONNECT]
     *
     * @param onDeviceFound 디바이스 발견 시 호출
     * @param onScanFailed  스캔 실패 시 에러 코드와 메시지와 함께 호출
     */
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    override fun startS2PScan(
        onDeviceFound: (BluetoothDevice) -> Unit,
        onScanFailed: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        withClient(
            onReady = { client ->
                client.startS2PScan(
                    onDeviceFound = onDeviceFound,
                    onScanFailed = onScanFailed
                )
            },
            onError = onScanFailed
        )
    }


    /**
     * BLE를 사용해 S2P 디바이스 스캔을 시작합니다(자바 호환 리스너 버전).
     *
     * 필요 권한: [Manifest.permission.BLUETOOTH_SCAN], [Manifest.permission.BLUETOOTH_CONNECT]
     *
     * @param listener 스캔 콜백 리스너
     */
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    override fun startS2PScan(listener: S2PScanResultListener) {
        withClient(
            onReady = { client -> client.startS2PScan(listener::onDeviceFound, listener::onScanFailed) },
            onError = { code, msg -> listener.onScanFailed(code, msg) }
        )
    }

    /**
     * BLE를 사용해 S2P 디바이스 스캔을 시작합니다(코틀린 코루틴 버전).
     */
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    override suspend fun startS2PScan(): BluetoothDevice = suspendCancellableCoroutine { cont ->
        startS2PScan(
            onDeviceFound = { device ->
                if (cont.isActive) cont.resume(device)
            },
            onScanFailed = { _, msg ->
                if (cont.isActive) cont.resumeWithException(ScanException(msg))
            }
        )

        cont.invokeOnCancellation { runCatching { stopS2PScan() } }
    }


    /**
     * 지정한 블루투스 디바이스에 연결을 시도합니다(코틀린 콜백 버전).
     *
     * 필요 권한: [Manifest.permission.BLUETOOTH_CONNECT]
     *
     * @param device    연결할 디바이스
     * @param onSuccess 연결 성공 시 콜백
     * @param onFailure 연결 실패 시 오류 코드와 메시지로 콜백
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    override fun connectToDevice(
        device: BluetoothDevice,
        onSuccess: () -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        withClient(
            onReady = { client ->
                client.connectToDevice(
                    config.connectionType,
                    device,
                    { session ->
                        this.session = session
                        onSuccess()
                    },
                    onFailure
                )
            },
            onError = onFailure
        )
    }


    /**
     * 지정한 블루투스 디바이스에 연결을 시도합니다(자바 호환 리스너 버전).
     *
     * 필요 권한: [Manifest.permission.BLUETOOTH_CONNECT]
     *
     * @param device   연결할 디바이스
     * @param listener 연결 결과 콜백 리스너
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    override fun connectToDevice(device: BluetoothDevice, listener: ConnectResultListener) {
        withClient(
            onReady = { client ->
                client.connectToDevice(
                    config.connectionType, device, onSuccess = { session ->
                        this.session = session
                        listener.onSuccess()
                    },
                    onFailure = listener::onFailure
                )
            },
            onError = { code, msg -> listener.onFailure(code, msg) }
        )
    }

    /**
     * 지정한 블루투스 디바이스에 연결을 시도합니다(코틀린 코루틴 버전).
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    override suspend fun connectToDevice(device: BluetoothDevice) = suspendCancellableCoroutine<Unit> { cont ->
        connectToDevice(
            device,
            onSuccess = { if (cont.isActive) cont.resume(Unit) },
            onFailure = { code, msg ->
                if (cont.isActive) cont.resumeWithException(ConnectToDeviceException(msg))
            }
        )
    }


    /**
     * 현재 유효한 통신 세션을 반환합니다.
     *
     * @return [TransportSession] 인스턴스
     * @throws IllegalStateException SDK가 아직 초기화되지 않은 경우
     */
    override fun getTransportSession(): TransportSession {
        check(session != null) {
            Logger.e(msg = "=========== getTransportSession: session is NULL (not connected) ===========")
            "Transport session is not initialized. Call connect() before using TransportSession APIs."
        }
        return session!!
    }


    /**
     * 통신 세션이 초기화되었는지 여부를 반환합니다.
     *
     * @return 세션이 준비되었으면 true
     */
    override fun isTransportSessionInitialized(): Boolean {
        return session != null
    }


    /**
     * 클래식 블루투스 디스커버리를 시작하고, 모델명이 "WR"로 시작하는 디바이스만 필터링합니다.
     *
     * 필요 권한: [Manifest.permission.BLUETOOTH_SCAN], [Manifest.permission.BLUETOOTH_CONNECT]
     *
     * @param listener 스캔 결과 콜백 리스너
     */
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    override fun startDiscoveryScan(listener: DiscoveryScanResultListener) {
        withClient(
            onReady = { client -> client.startDiscoveryScan(listener) },
            onError = { code, msg -> listener.onError(code, msg) }
        )
    }

    /**
     * BLE 디바이스 스캔을 Flow로 제공합니다.
     *
     * - collect가 시작되면 내부적으로 DiscoveryScanResultListener를 등록하여 스캔을 시작합니다.
     * - onStarted → DiscoveryScanEvent.Started
     * - onDeviceFound → DiscoveryScanEvent.DeviceFound(device)
     * - onFinished → DiscoveryScanEvent.Finished 후 Flow complete
     * - onError → DiscoveryScanEvent.Error 후 예외와 함께 Flow 종료
     */
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    override fun discoveryScanFlow(): Flow<DiscoveryScanEvent> = callbackFlow {
        val listener = object : DiscoveryScanResultListener {
            override fun onStarted() {
                trySend(DiscoveryScanEvent.Started)
            }

            override fun onDeviceFound(device: DiscoveryDeviceModel) {
                trySend(DiscoveryScanEvent.DeviceFound(device))
            }

            override fun onFinished() {
                trySend(DiscoveryScanEvent.Finished)
                // 정상 종료이므로 Flow를 닫는다.
                close()
            }

            override fun onError(errorCode: Int, errorMsg: String) {
                trySend(DiscoveryScanEvent.Error(errorCode, errorMsg))
                // 에러와 함께 Flow 종료
                close()
            }
        }

        withClient(
            onReady = { client ->
                client.startDiscoveryScan(listener)
            },
            onError = { code, msg ->
                // 서비스 클라이언트 준비 단계에서 실패한 경우
                trySend(DiscoveryScanEvent.Error(code, msg))
                close()
            }
        )

        awaitClose {
            stopDiscoveryScan()
        }
    }


    /**
     * 진행 중인 클래식 블루투스 디스커버리 스캔을 중지합니다.
     */
    override fun stopDiscoveryScan() {
        client?.stopDiscoveryScan() ?: return
    }


    /**
     * 진행 중인 BLE 스캔을 중지합니다.
     *
     * 필요 권한: [Manifest.permission.BLUETOOTH_SCAN]
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    override fun stopS2PScan() {
        client?.stopS2PScan() ?: return
    }


    /**
     * S2P 통신에 사용할 유니크 키를 생성 후 SharedPreferences에 저장합니다.
     */
    private fun generateAndSaveUniqueKey() {
        prefManager.saveString(PrefManager.UNIQUE_KEY, Utils.generateUniqueKey())
    }


    /**
     * SharedPreferences에 유니크 키가 존재하는지 확인합니다.
     */
    private fun isExistsUniqueKey(): Boolean {
        val uniqueKey = prefManager.getString(PrefManager.UNIQUE_KEY)
        return uniqueKey.isNotEmpty()
    }


    /**
     * TransportClient 가 준비된 상태에서만 작업을 수행하기 위한 헬퍼입니다.
     *
     * 동작 방식:
     * - client 가 이미 생성/바인딩된 상태라면 즉시 [onReady] 를 호출합니다.
     * - client 가 null 인 경우, 현재 요청(onReady/onError)을 [pendingClientRequests] 에 큐잉한 뒤
     *   [TransportService] 바인딩을 요청합니다.
     * - 서비스 바인딩이 완료되면 [flushPendingClientRequests] 를 통해 큐에 쌓여 있던
     *   모든 요청의 [onReady] 가 한 번에 호출됩니다.
     * - 바인딩 실패나 서비스 연결 해제 시에는 [onError] 가 호출됩니다.
     *
     * 이 함수는 “TransportService 바인딩 상태 + TransportClient 생성 시점”을 호출자에게서 숨기고,
     * connect / scan 처럼 TransportClient 가 반드시 필요한 API에서
     * 안전하게 재사용하기 위한 공통 진입점입니다.
     *
     */
    private fun withClient(
        onReady: (TransportClient) -> Unit,
        onError: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        if (!isInitialized) {
            val catalog = SDKInitErrorCatalog.NOT_INITIALIZED
            onError(catalog.code, catalog.message)
            return
        }

        val cached = client
        if (cached != null) {
            onReady(cached); return
        }
        pendingClientRequests.add(PendingClientRequest(onReady, onError))
        Logger.i(msg = "=========== TransportService creating... ===========")
        connector.bindTransportService(
            onBound = { binder ->
                val client = binder.client()
                this.client = client
                flushPendingClientRequests(null)
                Logger.i(msg = "=========== TransportService created successfully ===========")
            },
            onLost = { catalog ->
                isBounded = false
                session = null
                client = null
                flushPendingClientRequests(catalog)
                Logger.e(msg = "=========== TransportService connection lost: ${catalog.msg} (code=${catalog.code}) ===========")
            }
        )
    }

    /**
     * 대기 중인 모든 클라이언트 요청을 플러시합니다.
     * - [error] 가 null 이면 정상적으로 바인딩/생성된 상태이므로
     *   모든 요청의 [onReady] 를 호출합니다.
     * - [error] 가 null 이 아니면 바인딩/생성에 실패한 상태이므로
     *   모든 요청의 [onError] 를 호출합니다.
     *
     *   @param error 바인딩/생성 실패 시 에러 코드와 메시지 쌍, 정상 시 null
     */
    private fun flushPendingClientRequests(error: ConnectErrorCatalog?) {
        if (pendingClientRequests.isEmpty()) return
        val pending = pendingClientRequests.toList()
        pendingClientRequests.clear()

        if (error == null) {
            val client = client ?: return
            pending.forEach { req -> runCatching { req.onReady(client) } }
        } else {
            pending.forEach { req -> runCatching { req.onError(error.code, error.msg) } }
        }
    }

    /**
     * 지정한 연결 타입에 맞는 [ConnectionRepo] 구현체를 생성합니다.
     *
     * @param connectionType 연결 타입
     * @param context 애플리케이션 컨텍스트
     * @return 생성된 [ConnectionRepo] 인스턴스
     */
    private fun createConnectionRepoWithConnectionType(connectionType: ConnectionType, context: Context): ConnectionRepo {
        return when (connectionType) {
            ConnectionType.SPP -> ConnectionRepoImpl(
                this.config.connectionType,
                SPPConnectionManager(),
                deviceStateStore
            )

            ConnectionType.BLE -> ConnectionRepoImpl(
                this.config.connectionType,
                BLEConnectionManager(context),
                deviceStateStore
            )
        }
    }
}
