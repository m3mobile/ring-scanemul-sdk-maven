package com.m3.ring.scanemul.sdk.api.model.symbologies.datamatrix

data class DataMatrixVals(
    val enabled: Boolean? = null,
    val inverse: DataMatrixType.InverseType? = null,
    val decodeMirrorImages: DataMatrixType.DecodeMirrorImagesType? = null,
    val gs1DataMatrix: Boolean? = null
)