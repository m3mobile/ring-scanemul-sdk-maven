package com.m3.ring.scanemul.sdk.api.model.symbologies.upca

data class UpcAVals(
    val enabled: Boolean? = null,
    val reportCheckDigit: Boolean? = null,
    val preamble: UpcAType.PreambleType? = null,
    val upcA2BitsSupplementals: Boolean? = null,
    val upcA5BitsSupplementals: Boolean? = null
)