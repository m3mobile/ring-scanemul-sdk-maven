package com.m3.ring.scanemul.sdk.internal.common.consts

internal object BtConst {
    const val BLUETOOTH_SERVICE_UUID = "00001101-0000-1000-8000-00805F9B34FB"
    const val S2P_HEADER = "{M3_S2P}BLE"
    const val DISCOVERY_FILTER_PREFIX = "WR"
}