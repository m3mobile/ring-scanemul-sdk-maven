package com.m3.ring.scanemul.sdk.internal.device.state

import com.m3.ring.scanemul.sdk.api.listener.DeviceStateListener
import com.m3.ring.scanemul.sdk.internal.common.ListenerRegistry
import com.m3.ring.scanemul.sdk.internal.device.mapping.toApiDeviceState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * DeviceInfoManager는 링 스캐너의 정보를 관리하는 클래스입니다.
 * 이 클래스는 디바이스 정보의 상태를 저장하고, 변경 사항을 리스너에게 알립니다.
 */
internal class DeviceStateStore {
    //링 스캐너의 모든 정보를 저장할 데이터 클래스
    private val _deviceState = MutableStateFlow(InternalDeviceState())
    val deviceState: StateFlow<InternalDeviceState> = _deviceState.asStateFlow()

    // 리스너 레지스트리
    private val deviceStateListenerRegistry = ListenerRegistry<DeviceStateListener>()

    fun getDeviceInfo(): InternalDeviceState = _deviceState.value

    fun addDeviceStateListener(listener: DeviceStateListener) {
        deviceStateListenerRegistry.add(listener)

        if (_deviceState.value != InternalDeviceState()) {
            // 현재 연결된 디바이스 정보가 있다면 즉시 전달
            listener.onDeviceStateChanged(_deviceState.value.toApiDeviceState())
        }
    }

    fun removeDeviceStateListener(listener: DeviceStateListener) {
        deviceStateListenerRegistry.remove(listener)
    }

    fun clearDeviceStateListeners() {
        deviceStateListenerRegistry.clear()
    }

    fun updateDeviceInfo(info: InternalDeviceState) {
        _deviceState.update { info }
        deviceStateListenerRegistry.notifyAll { it.onDeviceStateChanged(info.toApiDeviceState()) }
    }

    fun clearDeviceInfo() {
        _deviceState.value = InternalDeviceState()
    }
}