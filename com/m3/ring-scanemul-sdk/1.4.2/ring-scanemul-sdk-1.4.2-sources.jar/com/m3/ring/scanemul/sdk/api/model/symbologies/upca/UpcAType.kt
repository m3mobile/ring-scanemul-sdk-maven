package com.m3.ring.scanemul.sdk.api.model.symbologies.upca

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object UpcAType {
    enum class PreambleType : TypeValue {
        NONE, SYS_CHAR, COUNTRY_SYS_CHAR
    }
}