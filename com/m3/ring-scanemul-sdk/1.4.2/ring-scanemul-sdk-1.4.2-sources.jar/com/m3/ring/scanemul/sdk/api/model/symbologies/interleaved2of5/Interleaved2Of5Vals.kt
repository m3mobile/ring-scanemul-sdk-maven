package com.m3.ring.scanemul.sdk.api.model.symbologies.interleaved2of5

data class Interleaved2Of5Vals(
    val enabled: Boolean? = null,
    val length1: Int? = null,
    val length2: Int? = null,
    val checkDigit: Interleaved2Of5Type.CheckDigitType? = null,
    val reportCheckDigit: Boolean? = null,
    val securityLevel: Interleaved2Of5Type.SecurityType? = null,
    val convertItf14ToEan13: Boolean? = null,
    val reducedQuietZone: Boolean? = null
)