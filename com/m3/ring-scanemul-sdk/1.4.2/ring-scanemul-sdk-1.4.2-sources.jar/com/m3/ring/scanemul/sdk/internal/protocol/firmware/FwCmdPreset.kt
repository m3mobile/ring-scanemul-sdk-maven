package com.m3.ring.scanemul.sdk.internal.protocol.firmware

import com.m3.ring.scanemul.sdk.internal.common.util.CmdUtils
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting.FwIds

object FwCmdPreset {
    val default = CmdUtils.createFirmwareSetCommand(byteArrayOf(FwIds.SET_DEFAULT.idByte) + FwSetting.Default.ENABLE.value)
}
