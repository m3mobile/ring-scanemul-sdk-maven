package com.m3.ring.scanemul.sdk.api.model.symbologies.upce1

data class UpcE1Vals(
    val enabled: Boolean? = null,
    val convertToUpcA: Boolean? = null,
    val preamble: UpcE1Type.PreambleType? = null,
    val reportCheckDigit: Boolean? = null
)