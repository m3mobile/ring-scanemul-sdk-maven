package com.m3.ring.scanemul.sdk.internal.scan.data.spp.dto

import android.bluetooth.BluetoothDevice
import com.m3.ring.scanemul.sdk.api.model.scan.DiscoveryDeviceModel

data class DiscoveryDeviceDto(
    val btDevice: BluetoothDevice,
    val rssi: Int?,
)

fun DiscoveryDeviceDto.toModel() = DiscoveryDeviceModel(
    btDevice = btDevice,
    rssi = rssi
)