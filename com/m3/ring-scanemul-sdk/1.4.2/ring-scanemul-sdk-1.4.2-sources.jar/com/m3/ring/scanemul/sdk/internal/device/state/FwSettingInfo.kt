package com.m3.ring.scanemul.sdk.internal.device.state

import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting


data class FwSettingInfo(
    val sound: FwSetting.SoundSetting? = null,
    val vibrate: FwSetting.VibrateSetting? = null,
    val button: FwSetting.ButtonSetting? = null,
    val endChar: FwSetting.EndCharSetting? = null,
    val prefix: String? = null,
    val postfix: String? = null,
    val mode: FwSetting.BtModeSetting? = null,
    val vendor: FwSetting.Vendor? = null,
    val battery: Int? = null,
    val serialNumber: String? = null,
    val fwVersion: String? = null,
    val model: String? = null,
    val releaseDate: String? = null,
    val substring: String? = null,
    val translateData: String? = null,
    val removeFNC: FwSetting.RemoveFnc? = null,
    val prePostHex: FwSetting.PrePostHex? = null,
    val upcaToEan13: FwSetting.UPCAToEAN13? = null,
    val readMode: FwSetting.ReadMode? = null,
    val led: FwSetting.LedSetting? = null,
    val scannerId: FwSetting.ScannerId? = null,
    val batteryCallback: FwSetting.BatteryCallback? = null
)
