package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings

import com.m3.ring.scanemul.sdk.api.model.settings.basic.BasicFormatType
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
object BasicFormatSetting {
    /* Ids */
    enum class BasicFormatIds(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindValue(ValueType.ENUM, TransmitCodeIdVal::class)
        TRANSMIT_CODE_ID(zebra = byteArrayOf(0x2D.toByte()), totinfo = byteArrayOf(0x2D.toByte()));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnumNameMatch(external = BasicFormatType.TransmitCodeIdType::class)
    enum class TransmitCodeIdVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        NONE(zebra = byteArrayOf(0x00.toByte()), totinfo = byteArrayOf(0x00.toByte())),
        AIM(zebra = byteArrayOf(0x01.toByte()), totinfo = byteArrayOf(0x01.toByte())),
        SYMBOL(zebra = byteArrayOf(0x02.toByte()), totinfo = byteArrayOf(0x02.toByte()))
    }
}