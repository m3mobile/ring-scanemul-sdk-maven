package com.m3.ring.scanemul.sdk.internal.device.profile

import com.m3.ring.scanemul.sdk.internal.common.util.CmdUtils
import com.m3.ring.scanemul.sdk.internal.common.util.CmdUtils.tCreateSSIPayloadData
import com.m3.ring.scanemul.sdk.internal.common.util.CmdUtils.zCreateSSIPayloadData
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.AccessorCommandType
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.CommandSourceType
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.format.TScannerCmdFormatIds.T_FIXED_GET_COMMAND_PREFIX
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.format.TScannerCmdFormatIds.T_FIXED_SET_COMMAND_PREFIX
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.format.TScannerCmdFormatIds.totinfoIdLengthMap
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.format.ZScannerCmdFormatIds.Z_FIXED_GET_COMMAND_PREFIX
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.format.ZScannerCmdFormatIds.Z_FIXED_SET_COMMAND_PREFIX
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.format.ZScannerCmdFormatIds.zebraIdLengthMap

/**
 * 스캐너 종류에 따라 설정 프로필을 정의하는 객체입니다.
 * 각 스캐너의 SSI ID 길이와 설정 명령을 생성하는 함수를 포함합니다.
 */
object VendorProfileRegistry {
    val registry: Map<FwSetting.Vendor, ScannerProfile> = mapOf(
        // Zebra Scanner
        FwSetting.Vendor.ZEBRA to ScannerProfile(
            getIdLength = { byte -> zebraIdLengthMap[byte] ?: 1 },
            createSetCommand = { ssiIds ->
                CmdUtils.createScannerSetCommand(
                    AccessorCommandType.SET.value,
                    CommandSourceType.SCANNER.value,
                    Z_FIXED_SET_COMMAND_PREFIX,
                    ::zCreateSSIPayloadData,
                    ssiIds
                )
            },
            createGetCommand = { data ->
                CmdUtils.createScannerGetCommand(
                    AccessorCommandType.GET.value,
                    CommandSourceType.SCANNER.value,
                    Z_FIXED_GET_COMMAND_PREFIX,
                    ::zCreateSSIPayloadData,
                    data
                )
            }
        ),

        // Totinfo Scanner
        FwSetting.Vendor.TOTINFO to ScannerProfile(
            getIdLength = { byte -> totinfoIdLengthMap[byte] ?: 1 },
            createSetCommand = { ssiIds ->
                CmdUtils.createScannerSetCommand(
                    AccessorCommandType.SET.value,
                    CommandSourceType.SCANNER.value,
                    T_FIXED_SET_COMMAND_PREFIX,
                    ::tCreateSSIPayloadData,
                    ssiIds
                )
            },
            createGetCommand = { data ->
                CmdUtils.createScannerGetCommand(
                    AccessorCommandType.GET.value,
                    CommandSourceType.SCANNER.value,
                    T_FIXED_GET_COMMAND_PREFIX,
                    ::tCreateSSIPayloadData,
                    data
                )
            }
        )
    )
}

