package com.m3.ring.scanemul.sdk.internal.connection.data.ble

import android.bluetooth.BluetoothDevice
import android.content.Context
import com.m3.ring.scanemul.sdk.internal.connection.domain.ConnectionManager
import com.m3.ring.scanemul.sdk.internal.connection.domain.dto.ConnectionResult

/**
 * BLE 연결을 관리하는 클래스입니다.
 * BLE 장치와의 연결을 처리합니다.
 *
 * @param context Android Context
 */
class BLEConnectionManager(context: Context) : ConnectionManager {
    override suspend fun connect(device: BluetoothDevice): ConnectionResult {
        TODO("Not yet implemented")
    }
}