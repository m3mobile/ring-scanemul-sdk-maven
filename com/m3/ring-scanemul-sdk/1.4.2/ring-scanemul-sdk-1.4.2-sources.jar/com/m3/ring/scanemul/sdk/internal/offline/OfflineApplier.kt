package com.m3.ring.scanemul.sdk.internal.offline

import com.m3.ring.scanemul.sdk.internal.device.state.InternalDeviceState
import com.m3.ring.scanemul.sdk.internal.protocol.common.commands.InternalSettingCommand
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.updateFromBytes
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoValueApplierGenerated

internal object InternalOfflineApplier {
    fun apply(state: InternalDeviceState, cmd: InternalSettingCommand): InternalDeviceState =
        when (cmd) {
            is InternalSettingCommand.Valid.Scanner -> {
                val newScannerSettingInfo = ScannerSettingInfoValueApplierGenerated.apply(cmd.id, cmd.value, state.scannerSettingInfo)
                state.copy(scannerSettingInfo = newScannerSettingInfo)
            }

            is InternalSettingCommand.Valid.Firmware -> {
                state.copy(fwSettingInfo = cmd.id.updateFromBytes(state.fwSettingInfo, cmd.value?.value))
            }

            is InternalSettingCommand.Error -> state
        }
}