package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
object Code93Symbology {
    /* Ids */
    enum class Code93Ids(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("code93Enable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0x09), totinfo = byteArrayOf(0x09)),

        @BindField("code93Length1")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH1(zebra = byteArrayOf(0x1A), totinfo = byteArrayOf(0x1A)),

        @BindField("code93Length2")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH2(zebra = byteArrayOf(0x1B), totinfo = byteArrayOf(0x1B));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }
}
