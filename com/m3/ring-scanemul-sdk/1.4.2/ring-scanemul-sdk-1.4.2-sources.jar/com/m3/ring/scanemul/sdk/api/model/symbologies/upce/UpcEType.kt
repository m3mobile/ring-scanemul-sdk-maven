package com.m3.ring.scanemul.sdk.api.model.symbologies.upce

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object UpcEType {
    enum class PreambleType : TypeValue {
        NONE, SYS_CHAR, COUNTRY_SYS_CHAR
    }
}