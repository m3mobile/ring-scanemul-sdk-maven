package com.m3.ring.scanemul.sdk.api.model.symbologies.composite

data class CompositeVals(
    val enabled: Boolean? = null, // only for Totinfo
    val compositeABEnabled: Boolean? = null, // only for Zebra
    val compositeCEnabled: Boolean? = null, // only for Zebra
    val tlc39Enable: Boolean? = null,      // only for Zebra
    val upcCompositeMode: CompositeType.UPCCompositeModeType? = null // only for Zebra
)