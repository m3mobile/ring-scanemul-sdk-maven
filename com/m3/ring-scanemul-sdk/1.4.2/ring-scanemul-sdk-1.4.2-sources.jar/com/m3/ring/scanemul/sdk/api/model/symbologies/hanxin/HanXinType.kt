package com.m3.ring.scanemul.sdk.api.model.symbologies.hanxin

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object HanXinType {
    enum class InverseType : TypeValue {
        REGULAR_ONLY, INVERSE_ONLY, AUTO
    }
}