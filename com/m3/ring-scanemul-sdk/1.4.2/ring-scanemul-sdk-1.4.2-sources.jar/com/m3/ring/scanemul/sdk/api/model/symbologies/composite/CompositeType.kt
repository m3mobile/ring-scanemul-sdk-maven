package com.m3.ring.scanemul.sdk.api.model.symbologies.composite

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object CompositeType {
    enum class UPCCompositeModeType : TypeValue {
        NEVER_LINKED, ALWAYS_LINKED, AUTO_DISCRIMINATE
    }
}