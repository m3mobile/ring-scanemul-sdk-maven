package com.m3.ring.scanemul.sdk.internal.protocol.scanner

import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting

fun ScannerSettingInfo.toSerializePayload(vendorType: FwSetting.Vendor): ByteArray {
    return toSerializeScannerSettingPayloadGenerated(vendorType)
}