package com.m3.ring.scanemul.sdk.internal.transport.data.core

import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothSocket
import com.m3.ring.scanemul.sdk.internal.device.state.DeviceStateStore
import com.m3.ring.scanemul.sdk.internal.transport.data.ble.BLETransportManager
import com.m3.ring.scanemul.sdk.internal.transport.data.spp.SPPTransportManager
import kotlinx.coroutines.CoroutineScope

internal object TransportSessionFactory {
    fun create(
        socket: BluetoothSocket,
        scope: CoroutineScope,
        deviceStateStore: DeviceStateStore
    ): TransportRepo {
        return TransportRepo(SPPTransportManager(socket, scope), deviceStateStore)
    }

    fun create(
        gatt: BluetoothGatt,
        scope: CoroutineScope,
        deviceStateStore: DeviceStateStore
    ): TransportRepo {
        return TransportRepo(BLETransportManager(gatt, scope), deviceStateStore)
    }
}