package com.m3.ring.scanemul.sdk.internal.common

internal object Logger {
    private const val TAG = "M3RingScanEmul"
    private var isLogEnabled = false

    fun init(isLogEnabled: Boolean) {
        this.isLogEnabled = isLogEnabled
    }

    fun d(tag: String = TAG, msg: String) {
        if (isLogEnabled) {
            android.util.Log.d(tag, msg)
        }
    }

    fun i(tag: String = TAG, msg: String) {
        if (isLogEnabled) {
            android.util.Log.i(tag, msg)
        }
    }

    fun e(tag: String = TAG, msg: String) {
        if (isLogEnabled) {
            android.util.Log.e(tag, msg)
        }
    }
}