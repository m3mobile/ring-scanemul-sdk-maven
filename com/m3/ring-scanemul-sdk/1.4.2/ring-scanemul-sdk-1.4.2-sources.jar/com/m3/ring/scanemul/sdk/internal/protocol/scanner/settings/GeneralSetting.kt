package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings

import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
object GeneralSetting {
    /* Ids */
    enum class GeneralIds(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("aim")
        @BindValue(ValueType.ENUM, AimVal::class)
        AIM(zebra = byteArrayOf(0xF0.toByte(), 0x32.toByte()), totinfo = byteArrayOf(0xF2.toByte(), 0x03.toByte())),

        @BindField("illumination")
        @BindValue(ValueType.ENUM, IlluminationVal::class)
        ILLUMINATION(zebra = byteArrayOf(0xF0.toByte(), 0x2A.toByte()), totinfo = byteArrayOf(0xF2.toByte(), 0x02.toByte()));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class AimVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x02.toByte()), totinfo = byteArrayOf(0x00.toByte())),
        DISABLE(zebra = byteArrayOf(0x00.toByte()), totinfo = byteArrayOf(0x02.toByte()))
    }

    @EnableDisableEnum
    enum class IlluminationVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01.toByte()), totinfo = byteArrayOf(0x00.toByte())),
        DISABLE(zebra = byteArrayOf(0x00.toByte()), totinfo = byteArrayOf(0x02.toByte()))
    }
}
