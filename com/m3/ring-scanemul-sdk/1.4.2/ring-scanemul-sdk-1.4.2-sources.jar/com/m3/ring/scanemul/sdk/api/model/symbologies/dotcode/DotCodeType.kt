package com.m3.ring.scanemul.sdk.api.model.symbologies.dotcode

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object DotCodeType {
    enum class InverseType : TypeValue { ENABLE, DISABLE, AUTODETECT }
    enum class MirrorType : TypeValue { REGULAR, INVERSE_ONLY, AUTODETECT }
}
