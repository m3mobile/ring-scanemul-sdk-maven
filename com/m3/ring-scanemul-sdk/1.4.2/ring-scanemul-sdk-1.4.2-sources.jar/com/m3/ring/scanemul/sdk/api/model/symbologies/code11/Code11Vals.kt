package com.m3.ring.scanemul.sdk.api.model.symbologies.code11

data class Code11Vals(
    val enabled: Boolean? = null,
    val length1: Int? = null,
    val length2: Int? = null,
    val reportCheckDigit: Boolean? = null,
    val verifyCheckDigit: Code11Type.VerifyCheckDigitType? = null
)