package com.m3.ring.scanemul.sdk.api.listener

interface ConnectResultListener {
    fun onSuccess()
    fun onFailure(errorCode: Int, errorMsg: String)
}
