package com.m3.ring.scanemul.sdk.api.listener

import com.m3.ring.scanemul.sdk.api.model.DeviceState

interface DeviceStateListener {
    fun onDeviceStateChanged(state: DeviceState)
}