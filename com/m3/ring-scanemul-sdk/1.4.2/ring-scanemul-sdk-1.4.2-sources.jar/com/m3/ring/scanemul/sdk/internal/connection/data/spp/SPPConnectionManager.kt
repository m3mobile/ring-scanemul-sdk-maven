package com.m3.ring.scanemul.sdk.internal.connection.data.spp

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.common.consts.BtConst
import com.m3.ring.scanemul.sdk.internal.connection.data.spp.dto.SPPConnectionResult
import com.m3.ring.scanemul.sdk.internal.connection.domain.ConnectionManager
import com.m3.ring.scanemul.sdk.internal.connection.domain.dto.ConnectionResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

class SPPConnectionManager : ConnectionManager {
    private val sppUuid: UUID = UUID.fromString(BtConst.BLUETOOTH_SERVICE_UUID)
    private var socket: BluetoothSocket? = null

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    override suspend fun connect(device: BluetoothDevice): ConnectionResult {
        return withContext(Dispatchers.IO) {
            try {
                socket = device.createRfcommSocketToServiceRecord(sppUuid)

                if (socket?.isConnected == true) { // 소켓이 연결되어 있지 않은 경우(연결이 되어 있지 않아야지 연결 요청을 하기 때문.)
                    Logger.i(msg = "=========== Socket already connected: ${device.name} - ${device.address} ===========")
                    return@withContext SPPConnectionResult(
                        isSuccess = false,
                        errorMsg = "Socket already connected",
                        device = device
                    )
                }

                socket?.connect()
                Logger.i(msg = "=========== Successfully connected to socket: ${device.name} - ${device.address} ===========")

                SPPConnectionResult(
                    isSuccess = true,
                    socket = socket,
                    device = device
                )
            } catch (e: Exception) {
                socket?.close()
                socket = null
                Logger.e(msg = "=========== Connect failed: ${e.message} ===========")
                SPPConnectionResult(
                    isSuccess = false,
                    errorMsg = e.message,
                    device = device
                )
            }
        }
    }
}