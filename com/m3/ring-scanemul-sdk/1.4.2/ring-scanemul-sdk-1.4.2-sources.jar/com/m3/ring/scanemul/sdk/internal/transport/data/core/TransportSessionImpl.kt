package com.m3.ring.scanemul.sdk.internal.transport.data.core

import android.graphics.Bitmap
import com.m3.ring.scanemul.sdk.api.core.TransportSession
import com.m3.ring.scanemul.sdk.api.error.catalog.SetSettingErrorCatalog
import com.m3.ring.scanemul.sdk.api.error.exception.TransportSessionException
import com.m3.ring.scanemul.sdk.api.listener.DecodingDataListener
import com.m3.ring.scanemul.sdk.api.listener.DeviceStateListener
import com.m3.ring.scanemul.sdk.api.listener.DisconnectListener
import com.m3.ring.scanemul.sdk.api.listener.DisconnectResultListener
import com.m3.ring.scanemul.sdk.api.listener.SetDefaultResultSettings
import com.m3.ring.scanemul.sdk.api.listener.SetSettingResultListener
import com.m3.ring.scanemul.sdk.api.model.DeviceState
import com.m3.ring.scanemul.sdk.api.model.device.BtModeType
import com.m3.ring.scanemul.sdk.api.settings.SettingCommand
import com.m3.ring.scanemul.sdk.internal.device.mapping.toApiDeviceState
import com.m3.ring.scanemul.sdk.internal.device.mapping.toEnumInternal
import com.m3.ring.scanemul.sdk.internal.device.state.DeviceStateStore
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * 연결 이후 통신 관련 세션을 관리하는 클래스입니다.
 */
class TransportSessionImpl internal constructor(
    private val transportRepo: TransportRepo,
    private val deviceStateStore: DeviceStateStore
) : TransportSession {

    // 연결 상태
    private val isConnected = MutableStateFlow(true)

    // 연결 끊김 메시지
    private val disconnectedMsg = "Transport session is disconnected. Please connect again."

    init {
        transportRepo.addOnDisconnected { isConnected.value = false }
    }

    override fun setSetting(setting: SettingCommand, onSuccess: () -> Unit, onFailure: (errorCode: Int, errorMsg: String) -> Unit) {
        if (!isConnected.value) {
            onFailure(SetSettingErrorCatalog.SDK_ERROR.code, disconnectedMsg)
            return
        }
        transportRepo.setSetting(setting.internalSettingCmd, onSuccess, onFailure)
    }

    override fun setSetting(setting: SettingCommand, listener: SetSettingResultListener) {
        if (!isConnected.value) {
            listener.onFailure(SetSettingErrorCatalog.SDK_ERROR.code, disconnectedMsg)
            return
        }
        transportRepo.setSetting(setting.internalSettingCmd, listener::onSuccess, listener::onFailure)
    }

    override suspend fun setSetting(setting: SettingCommand): Unit =
        suspendCancellableCoroutine { cont ->
            if (!isConnected.value && cont.isActive) {
                cont.resumeWithException(Exception(disconnectedMsg))
                return@suspendCancellableCoroutine
            }

            transportRepo.setSetting(
                setting.internalSettingCmd,
                onSuccess = {
                    if (cont.isActive) {
                        cont.resume(Unit)
                    }
                },
                onFailure = { _, errorMsg ->
                    if (cont.isActive) {
                        cont.resumeWithException(TransportSessionException(errorMsg))
                    }
                }
            )
        }

    override fun setDefaultSettings(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit) {
        if (!isConnected.value) {
            onFailure(disconnectedMsg)
            return
        }
        transportRepo.setDefaultSetting(onSuccess, onFailure)
    }

    override fun setDefaultSettings(listener: SetDefaultResultSettings) {
        if (!isConnected.value) {
            listener.onFailure(disconnectedMsg)
            return
        }
        transportRepo.setDefaultSetting(listener::onSuccess, listener::onFailure)
    }

    override suspend fun setDefaultSettings(): Unit = suspendCancellableCoroutine { cont ->
        if (!isConnected.value && cont.isActive) {
            cont.resumeWithException(Exception(disconnectedMsg))
            return@suspendCancellableCoroutine
        }
        transportRepo.setDefaultSetting(
            onSuccess = {
                if (cont.isActive) {
                    cont.resume(Unit)
                }
            },
            onFailure = { errorMsg ->
                if (cont.isActive) {
                    cont.resumeWithException(TransportSessionException(errorMsg))
                }
            }
        )
    }

    override fun requestWrite(data: ByteArray) {
        if (!isConnected.value) throw IllegalStateException(disconnectedMsg)
        transportRepo.requestWrite(data)
    }

    override fun disconnect(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit) {
        if (!isConnected.value) {
            onFailure(disconnectedMsg)
            return
        }
        transportRepo.disconnect(onSuccess, onFailure)
    }

    override fun disconnect(listener: DisconnectResultListener) {
        if (!isConnected.value) {
            listener.onFailure(disconnectedMsg)
            return
        }
        transportRepo.disconnect(listener::onSuccess, listener::onFailure)
    }

    override suspend fun disconnect(): Unit = suspendCancellableCoroutine { cont ->
        if (!isConnected.value && cont.isActive) {
            cont.resumeWithException(Exception(disconnectedMsg))
            return@suspendCancellableCoroutine
        }
        transportRepo.disconnect(
            onSuccess = {
                if (cont.isActive) {
                    cont.resume(Unit)
                }
            },
            onFailure = { errorMsg ->
                if (cont.isActive) {
                    cont.resumeWithException(TransportSessionException(errorMsg))
                }
            }
        )
    }

    override fun addDecodingDataListener(barCodeDataListener: DecodingDataListener) {
        if (!isConnected.value) throw IllegalStateException(disconnectedMsg)
        transportRepo.addDecodingDataListener(barCodeDataListener)
    }

    override fun removeDecodingDataListener(barCodeDataListener: DecodingDataListener) {
        if (!isConnected.value) throw IllegalStateException(disconnectedMsg)
        transportRepo.removeDecodingDataListener(barCodeDataListener)
    }

    override fun addDisconnectListener(disconnectListener: DisconnectListener) {
        if (!isConnected.value) throw IllegalStateException(disconnectedMsg)
        transportRepo.addDisconnectListener(disconnectListener)
    }

    override fun removeDisconnectListener(disconnectListener: DisconnectListener) {
        if (!isConnected.value) throw IllegalStateException(disconnectedMsg)
        transportRepo.removeDisconnectListener(disconnectListener)
    }

    override fun getQrCodeForSetterCommand(btMode: BtModeType): Bitmap? {
        if (!isConnected.value) throw IllegalStateException(disconnectedMsg)
        return transportRepo.generateQrBitmap(btMode.toEnumInternal<FwSetting.BtModeSetting>())
    }

    override fun addDeviceStateListener(listener: DeviceStateListener) {
        if (!isConnected.value) throw IllegalStateException(disconnectedMsg)
        deviceStateStore.addDeviceStateListener(listener)
    }

    override fun removeDeviceStateListener(listener: DeviceStateListener) {
        if (!isConnected.value) throw IllegalStateException(disconnectedMsg)
        deviceStateStore.removeDeviceStateListener(listener)
    }


    /**
     * 바코드 디코딩 데이터를 Flow로 제공합니다.
     */
    override fun decodingDataFlow(): Flow<ByteArray> = transportRepo.observeBarcodeValueWithFlow()

    /**
     * 디스커넥트 이벤트를 Flow로 제공합니다.
     *
     */
    override fun disconnectFlow(): Flow<Unit> = transportRepo.observeDisconnectWithFlow()

    /**
     * DeviceStateListener를 Flow로 래핑한 API입니다.
     */
    override fun deviceStateFlow(): Flow<DeviceState> = deviceStateStore.deviceState.map { it.toApiDeviceState() }
}