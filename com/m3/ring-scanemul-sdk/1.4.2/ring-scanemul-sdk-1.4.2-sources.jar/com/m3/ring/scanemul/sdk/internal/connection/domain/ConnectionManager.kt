package com.m3.ring.scanemul.sdk.internal.connection.domain

import android.bluetooth.BluetoothDevice
import com.m3.ring.scanemul.sdk.internal.connection.domain.dto.ConnectionResult

interface ConnectionManager {
    /**
     * 블루투스 디바이스와 연결을 시도합니다.
     */
    suspend fun connect(device: BluetoothDevice): ConnectionResult
}