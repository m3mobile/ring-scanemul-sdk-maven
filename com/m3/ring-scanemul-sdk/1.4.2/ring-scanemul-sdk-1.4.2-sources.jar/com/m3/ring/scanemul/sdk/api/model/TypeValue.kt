package com.m3.ring.scanemul.sdk.api.model

interface TypeValue {
}