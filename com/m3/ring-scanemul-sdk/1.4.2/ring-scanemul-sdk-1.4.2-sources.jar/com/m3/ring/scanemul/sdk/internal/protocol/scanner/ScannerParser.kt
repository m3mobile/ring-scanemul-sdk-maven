package com.m3.ring.scanemul.sdk.internal.protocol.scanner

import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting

/**
 * 스캐너 설정 정보를 Byte로부터 파싱하기 위한 객체입니다.
 */
object ScannerParser {
//    private val settingTypeIdList = ScannerSettingRegistry.groups.map { it.companion }

    /**
     * 스캐너 설정 정보를 파싱합니다.
     * 이 함수는 스캐너의 ID와 Value을 바이트 배열로 받아, 해당 ID에 맞는 설정 정보를 찾아 업데이트합니다.
     *
     * @param idByte 스캐너 설정 ID를 나타내는 바이트 배열입니다.
     * @param valueByte 스캐너 설정 값을 나타내는 바이트 배열입니다.
     * @param scannerType 스캐너의 종류를 나타내는 [FwSetting.ScannerId]입니다.
     * @param scannerSettingInfo 현재 장치 정보 상태를 나타내는 [ScannerSettingInfo]입니다.
     * @return 업데이트된 [ScannerSettingInfo] 객체를 반환합니다.
     */
//    fun parseForScannerSetting(
//        idByte: ByteArray, valueByte: ByteArray, vendorType: FwSetting.Vendor, scannerSettingInfo: ScannerSettingInfo
//    ): ScannerSettingInfo {
//        // scannerIdList를 순회해서, 알맞는 Id가 있는지 찾는다
//        for (companion in settingTypeIdList) {
//            // 알맞는 SettingId(enum 멤버) 찾기
//            val id = companion.fromByteArray(vendorType, idByte)
//
//            if (id != null) {
//                // 파싱 성공: 해당 id의 updater로 값 갱신해서 리턴
//                return updateScannerSettingInfo(id, valueByte, vendorType, scannerSettingInfo)
//            }
//        }
//        // 못 찾으면 기존 값 리턴
//        return scannerSettingInfo
//    }

    /**
     * 스캐너 설정 정보를 업데이트합니다.
     *
     * @param id 스캐너 설정 ID를 나타내는 [ScannerIds]입니다.
     * @param valueByte 스캐너 설정 값을 나타내는 바이트 배열입니다.
     * @param vendorType 스캐너의 종류를 나타내는 [FwSetting.Vendor]입니다.
     * @param scannerSettingInfo 현재 장치 정보 상태를 나타내는 [ScannerSettingInfo]입니다.
     * @return 업데이트된 [ScannerSettingInfo] 객체를 반환합니다.
     */
    fun parseForScannerSetting(
        idByte: ByteArray,
        valueByte: ByteArray,
        vendorType: FwSetting.Vendor,
        scannerSettingInfo: ScannerSettingInfo
    ): ScannerSettingInfo {
        return ScannerSettingInfoParserGenerated.parseForScannerSetting(
            idBytes = idByte,
            valueBytes = valueByte,
            vendorType = vendorType,
            info = scannerSettingInfo
        )
    }

//    /**
//     * 스캐너 설정 정보를 업데이트합니다.
//     *
//     * @param id 스캐너 설정 ID를 나타내는 [ScannerIds]입니다.
//     * @param valueByte 스캐너 설정 값을 나타내는 바이트 배열입니다.
//     * @param vendorType 스캐너의 종류를 나타내는 [FwSetting.Vendor]입니다.
//     * @param scannerSettingInfo 현재 장치 정보 상태를 나타내는 [ScannerSettingInfo]입니다.
//     * @return 업데이트된 [ScannerSettingInfo] 객체를 반환합니다.
//     */
//    private fun updateScannerSettingInfo(id: ScannerIds, valueByte: ByteArray, vendorType: FwSetting.Vendor, scannerSettingInfo: ScannerSettingInfo) =
//        id.updateScannerSettingInfo(vendorType, valueByte, scannerSettingInfo)
}
