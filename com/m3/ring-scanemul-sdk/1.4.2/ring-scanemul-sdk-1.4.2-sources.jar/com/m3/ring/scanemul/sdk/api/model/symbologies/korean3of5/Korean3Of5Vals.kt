package com.m3.ring.scanemul.sdk.api.model.symbologies.korean3of5

data class Korean3Of5Vals(
    val enabled: Boolean? = null
)