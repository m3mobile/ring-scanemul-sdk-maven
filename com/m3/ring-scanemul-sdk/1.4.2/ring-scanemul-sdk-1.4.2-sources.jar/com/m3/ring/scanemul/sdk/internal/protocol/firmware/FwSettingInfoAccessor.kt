package com.m3.ring.scanemul.sdk.internal.protocol.firmware

import com.m3.ring.scanemul.sdk.internal.device.state.FwSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting.FwIds

/**
 * FwSettingInfo의 필드에 접근하는 유틸리티 객체
 *
 * 추후, SDK에서는 지원하지만, 링 스캐너의 펌웨어 버전이 낮아 지원하지 않는 설정을 요청할 때,
 * 예외 처리를 일원화하기 위해 hasValue() 메소드를 사용합니다.
 *
 * ex) 처음 연결 될 때 모든 펌웨어의 설정을 링 스캐너로부터 받아오지만, 만약 받아온 값이 null이라면, 해당 링 스캐너에서는
 * 지원하지 않는다는 반증이므로 SDK와 링 스캐너 펌웨어의 버전이 서로 맞지 않는다는 것을 의미합니다.
 */
internal object FwSettingInfoAccessor {
    // 특정 ID에 해당하는 현재 값을 FwSettingInfo에서 찾아서 반환합니다.
    fun get(info: FwSettingInfo, id: FwIds): Any? = id.extract(info)

    // 값이 존재하는지 여부를 반환합니다. set전용 ID는 현재의 값 없이도 허용합니다.
    fun hasValue(info: FwSettingInfo, id: FwIds): Boolean =
        !id.requiresExistingValue || get(info, id) != null
}
