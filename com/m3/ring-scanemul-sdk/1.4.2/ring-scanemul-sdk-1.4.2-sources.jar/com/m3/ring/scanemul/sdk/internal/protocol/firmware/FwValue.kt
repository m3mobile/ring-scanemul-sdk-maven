package com.m3.ring.scanemul.sdk.internal.protocol.firmware

import com.m3.ring.scanemul.sdk.internal.protocol.common.values.Value

interface FwValue : Value {
    val value: ByteArray

    fun toByteArray(): ByteArray {
        return value
    }
}