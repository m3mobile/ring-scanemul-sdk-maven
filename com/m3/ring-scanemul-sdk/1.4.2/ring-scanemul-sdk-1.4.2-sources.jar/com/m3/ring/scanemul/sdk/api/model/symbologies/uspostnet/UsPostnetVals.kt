package com.m3.ring.scanemul.sdk.api.model.symbologies.uspostnet

data class UsPostnetVals(
    val enabled: Boolean? = null
)