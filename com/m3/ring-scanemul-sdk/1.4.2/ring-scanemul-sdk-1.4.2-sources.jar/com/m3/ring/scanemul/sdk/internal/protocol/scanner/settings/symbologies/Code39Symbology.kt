package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.code39.Code39Type
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
object Code39Symbology {
    /* Ids */
    enum class Code39Ids(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("code39Enable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00)),

        @BindField("code39TriopticCode39")
        @BindValue(ValueType.ENUM, TriopticCode39Val::class)
        TRIOPTIC_CODE39(zebra = byteArrayOf(0x0D)),

        @BindField("code39Length1")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH1(zebra = byteArrayOf(0x12), totinfo = byteArrayOf(0x12)),

        @BindField("code39Length2")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH2(zebra = byteArrayOf(0x13), totinfo = byteArrayOf(0x13)),

        @BindField("code39ReducedQuietZone")
        @BindValue(ValueType.ENUM, ReducedQuietZoneVal::class)
        REDUCED_QUIET_ZONE(zebra = byteArrayOf(0xF8.toByte(), 0x04, 0xB9.toByte())),

        @BindField("code39ConvertToCode32")
        @BindValue(ValueType.ENUM, ConvertToCode32Val::class)
        CONVERT_TO_CODE32(zebra = byteArrayOf(0x56), totinfo = byteArrayOf(0x56)),

        @BindField("code39FullAscii")
        @BindValue(ValueType.ENUM, FullAsciiVal::class)
        FULL_ASCII(zebra = byteArrayOf(0x11), totinfo = byteArrayOf(0x11)),

        @BindField("code39ReportCheckDigit")
        @BindValue(ValueType.ENUM, ReportCheckDigitVal::class)
        REPORT_CHECK_DIGIT(zebra = byteArrayOf(0x2B), totinfo = byteArrayOf(0x2B)),

        @BindField("code39ReportCode32Prefix")
        @BindValue(ValueType.ENUM, ReportCode32PrefixVal::class)
        REPORT_CODE32_PREFIX(zebra = byteArrayOf(0xE7.toByte()), totinfo = byteArrayOf(0xE7.toByte())),

        @BindField("code39SecurityLevel")
        @BindValue(ValueType.ENUM, SecurityLevelVal::class)
        SECURITY_LEVEL(zebra = byteArrayOf(0xF1.toByte(), 0xEE.toByte())),

        @BindField("code39VerifyCheckDigit")
        @BindValue(ValueType.ENUM, VerifyCheckDigitVal::class)
        VERIFY_CHECK_DIGIT(zebra = byteArrayOf(0x30), totinfo = byteArrayOf(0x30));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class TriopticCode39Val(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class ReducedQuietZoneVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class ConvertToCode32Val(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class FullAsciiVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class ReportCheckDigitVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class ReportCode32PrefixVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnumNameMatch(external = Code39Type.SecurityType::class)
    enum class SecurityLevelVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        LEVEL_0(zebra = byteArrayOf(0x00)),
        LEVEL_1(zebra = byteArrayOf(0x01)),
        LEVEL_2(zebra = byteArrayOf(0x02)),
        LEVEL_3(zebra = byteArrayOf(0x03))
    }

    @EnableDisableEnum
    enum class VerifyCheckDigitVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }
}
