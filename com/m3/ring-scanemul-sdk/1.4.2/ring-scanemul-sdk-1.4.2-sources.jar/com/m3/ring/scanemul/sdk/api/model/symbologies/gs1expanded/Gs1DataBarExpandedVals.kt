package com.m3.ring.scanemul.sdk.api.model.symbologies.gs1expanded

data class Gs1DataBarExpandedVals(
    val enabled: Boolean? = null
)