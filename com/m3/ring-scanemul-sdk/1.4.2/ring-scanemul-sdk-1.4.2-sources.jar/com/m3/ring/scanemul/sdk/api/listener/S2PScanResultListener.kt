package com.m3.ring.scanemul.sdk.api.listener

import android.bluetooth.BluetoothDevice

interface S2PScanResultListener {
    fun onDeviceFound(device: BluetoothDevice)
    fun onScanFailed(errorCode: Int, errorMsg: String)
}
