package com.m3.ring.scanemul.sdk.internal.scan.data.spp.dto

internal sealed class DiscoveryScanResult {
    data object Started : DiscoveryScanResult()
    data class Found(val deviceDto: DiscoveryDeviceDto) : DiscoveryScanResult()
}