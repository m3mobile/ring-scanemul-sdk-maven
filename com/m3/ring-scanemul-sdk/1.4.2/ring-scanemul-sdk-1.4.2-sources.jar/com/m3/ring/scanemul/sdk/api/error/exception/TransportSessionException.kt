package com.m3.ring.scanemul.sdk.api.error.exception

class TransportSessionException(
    override val message: String,
) : Exception(message)