package com.m3.ring.scanemul.sdk.api.listener

import com.m3.ring.scanemul.sdk.api.model.scan.DiscoveryDeviceModel

interface DiscoveryScanResultListener {
    fun onStarted()
    fun onDeviceFound(device: DiscoveryDeviceModel)
    fun onFinished()
    fun onError(errorCode: Int, errorMsg: String)
}