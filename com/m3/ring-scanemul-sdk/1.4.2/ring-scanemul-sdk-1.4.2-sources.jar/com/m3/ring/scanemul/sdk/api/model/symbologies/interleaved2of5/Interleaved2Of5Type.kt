package com.m3.ring.scanemul.sdk.api.model.symbologies.interleaved2of5

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object Interleaved2Of5Type {
    enum class CheckDigitType : TypeValue {
        DISABLE, ENABLE, USS_CHECK_DIGIT, OPCC_CHECK_DIGIT
    }

    enum class SecurityType : TypeValue {
        LEVEL_0, LEVEL_1, LEVEL_2, LEVEL_3
    }
}
