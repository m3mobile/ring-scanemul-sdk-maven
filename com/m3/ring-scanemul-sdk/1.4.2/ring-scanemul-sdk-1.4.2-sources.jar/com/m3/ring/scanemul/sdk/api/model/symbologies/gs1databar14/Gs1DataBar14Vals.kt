package com.m3.ring.scanemul.sdk.api.model.symbologies.gs1databar14

data class Gs1DataBar14Vals(
    val enabled: Boolean? = null
)