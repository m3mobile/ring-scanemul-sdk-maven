package com.m3.ring.scanemul.sdk.internal.common.consts

object Const {
    const val PREFIX_MAX_LENGTH = 16
    const val POSTFIX_MAX_LENGTH = 16
}