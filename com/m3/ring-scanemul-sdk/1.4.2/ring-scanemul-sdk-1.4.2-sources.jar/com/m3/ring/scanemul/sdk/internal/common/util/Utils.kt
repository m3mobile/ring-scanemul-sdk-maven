package com.m3.ring.scanemul.sdk.internal.common.util

import android.graphics.Bitmap
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.m3.ring.scanemul.sdk.internal.device.state.InternalDeviceState
import java.util.UUID

internal object Utils {
    /**
     * S2P을 위한 Code 128 바코드를 생성합니다.
     *
     * @param content 바코드에 포함될 내용
     * @param width 바코드의 너비 (기본값: 261)
     * @param height 바코드의 높이 (기본값: 51)
     * @param format 바코드 형식 (기본값: BarcodeFormat.CODE_128)
     * @return 생성된 바코드 이미지 (Bitmap) 또는 오류 발생 시 null
     */
    fun generateBarcodeForS2P(content: String, width: Int, height: Int, format: BarcodeFormat = BarcodeFormat.CODE_128): Bitmap? {
        val contentWithFnc1 = "\u00f1" + content // Add FNC1 character at the start to make GS1-128 format

        return try {
            val bitMatrix: BitMatrix = MultiFormatWriter().encode(
                contentWithFnc1,
                format,
                width,
                height
            )
            val encoder = BarcodeEncoder()
            encoder.createBitmap(bitMatrix)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * 고유한 키를 생성합니다.
     * 이 키는 UUID를 기반으로 하며, 마지막 12자리만을 사용합니다.
     */
    fun generateUniqueKey(): String {
        return UUID.randomUUID().toString().takeLast(12).uppercase()
    }

    fun generateUuidFromUniqueKey(uniqueKey: String): UUID {
        return UUID.fromString(
            "00000000-0000-0000-0000-$uniqueKey"
        )
    }

    /**
     * 주어진 바이트 배열로부터 QR 코드를 생성합니다.
     *
     * @param byteArray QR 코드로 변환할 바이트 배열
     * @param size QR 코드의 크기 (기본값: 512)
     * @return 생성된 QR 코드 이미지 (Bitmap) 또는 오류 발생 시 null
     */
    private fun generateQrCodeFromByteArray(byteArray: ByteArray, size: Int = 512): Bitmap? {
        val dataStr = byteArray.toString(Charsets.ISO_8859_1)
        val hints = mapOf(
            EncodeHintType.CHARACTER_SET to "ISO-8859-1",
        )

        return try {
            val bitMatrix: BitMatrix = MultiFormatWriter().encode(
                dataStr,
                BarcodeFormat.QR_CODE,
                size,
                size,
                hints
            )
            val encoder = BarcodeEncoder()
            encoder.createBitmap(bitMatrix)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun generateQrBitmap(
        deviceState: InternalDeviceState,
        size: Int = 512
    ): Bitmap? {
        val vendorType = deviceState.fwSettingInfo.vendor ?: return null

        val packet = CmdUtils.createPacketForQR(
            internalDeviceState = deviceState,
            vendorType = vendorType
        )

        return generateQrCodeFromByteArray(packet, size)
    }
}