package com.m3.ring.scanemul.sdk.api.model.symbologies.upce1

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object UpcE1Type {
    enum class PreambleType : TypeValue {
        NONE, SYS_CHAR, COUNTRY_SYS_CHAR
    }
}