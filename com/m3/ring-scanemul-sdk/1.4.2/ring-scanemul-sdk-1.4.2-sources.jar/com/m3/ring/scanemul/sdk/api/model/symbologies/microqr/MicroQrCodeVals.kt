package com.m3.ring.scanemul.sdk.api.model.symbologies.microqr

data class MicroQrCodeVals(
    val enabled: Boolean? = null
)