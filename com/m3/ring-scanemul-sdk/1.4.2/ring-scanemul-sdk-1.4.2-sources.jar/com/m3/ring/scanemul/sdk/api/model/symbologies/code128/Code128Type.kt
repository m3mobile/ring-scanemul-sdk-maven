package com.m3.ring.scanemul.sdk.api.model.symbologies.code128

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object Code128Type {
    enum class SecurityType : TypeValue {
        LEVEL_0, LEVEL_1, LEVEL_2, LEVEL_3
    }

    enum class ISBT128ConcatModeType : TypeValue {
        ENABLE, DISABLE, AUTO
    }
}