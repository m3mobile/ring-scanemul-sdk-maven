package com.m3.ring.scanemul.sdk.api.model.symbologies.gs1limited

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object Gs1DataBarLimitedType {
    enum class SecurityType : TypeValue {
        LEVEL_0, LEVEL_1, LEVEL_2, LEVEL_3
    }
}
