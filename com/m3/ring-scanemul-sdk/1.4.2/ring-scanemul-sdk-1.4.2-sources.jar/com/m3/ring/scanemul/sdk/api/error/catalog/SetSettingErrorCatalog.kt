package com.m3.ring.scanemul.sdk.api.error.catalog

enum class SetSettingErrorCatalog(val code: Int, val msg: String) {
    INVALID_COMMAND(5001, "Invalid command"),
    UNSUPPORTED_SETTING(5002, "Unsupported setting"),
    SDK_ERROR(5003, "SDK internal error"),
    SETTING_FAILED(5004, "Setting request failed"),
    REQUEST_TIMEOUT(5005, "Request timed out"),
    UNKNOWN_ERROR(5100, "Unknown error occurred"),
}
