package com.m3.ring.scanemul.sdk.internal.protocol.scanner.format

/* Scanner Command Setting parameters */
object ZScannerCmdFormatIds {
    private const val Z_PREFIX_BYTE = 0xff.toByte() // 확장 SSI ID의 시작을 나타내는 prefix 바이트

    internal enum class OpCode(val value: Byte) {
        SET(0xc6.toByte()),
        GET(0xc7.toByte());

        companion object {
            fun fromByte(byte: Byte): OpCode? =
                OpCode.entries.find { it.value == byte }
        }
    }

    internal enum class MessageSource(val value: Byte) {
        SCANNER(0x00.toByte()),
        HOST(0x04.toByte());

        companion object {
            fun fromByte(byte: Byte): MessageSource? =
                MessageSource.entries.find { it.value == byte }
        }
    }

    internal enum class Status(val value: Byte) {
        FIRST_TRANSMISSION(0x00.toByte()), // 0 = First transmission,
        SUBSEQUENT_TRANSMISSION(0x01.toByte()); //1 = Subsequent transmission

        companion object {
            fun fromByte(byte: Byte): Status? =
                Status.entries.find { it.value == byte }
        }
    }

    internal enum class ParameterType(val value: Byte) {
        SYMBOLOGY(0x08.toByte());

        companion object {
            fun fromByte(byte: Byte): ParameterType? =
                ParameterType.entries.find { it.value == byte }
        }
    }

    /** Scanner Set Command Prefix Structure : (Opcode) (Message Source) (Parameter Type) (Prefix)**/
    internal val Z_FIXED_SET_COMMAND_PREFIX = byteArrayOf(
        OpCode.SET.value,
        MessageSource.HOST.value,
        ParameterType.SYMBOLOGY.value,
        Z_PREFIX_BYTE
    )

    /** Scanner Get Command Presets Structure: (Opcode) (Message Source) (Status)  **/
    internal val Z_FIXED_GET_COMMAND_PREFIX = byteArrayOf(
        OpCode.GET.value,
        MessageSource.HOST.value,
        Status.FIRST_TRANSMISSION.value,
    )

    /**
     * Scanner Id의 첫번 째 바이트에 따라 Scanner ID의 길이를 정의하는 맵입니다.
     */
    val zebraIdLengthMap = mapOf(
        0xF8.toByte() to 3, 0xF0.toByte() to 2, 0xF1.toByte() to 2
    )
}
