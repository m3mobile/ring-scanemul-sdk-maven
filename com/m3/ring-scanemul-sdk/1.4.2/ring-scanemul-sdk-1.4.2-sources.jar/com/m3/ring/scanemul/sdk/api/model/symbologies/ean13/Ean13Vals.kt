package com.m3.ring.scanemul.sdk.api.model.symbologies.ean13

data class Ean13Vals(
    val enabled: Boolean? = null
)