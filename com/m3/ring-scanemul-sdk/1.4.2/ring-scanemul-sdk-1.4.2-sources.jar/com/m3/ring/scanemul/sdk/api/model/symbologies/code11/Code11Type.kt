package com.m3.ring.scanemul.sdk.api.model.symbologies.code11

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object Code11Type {
    enum class VerifyCheckDigitType : TypeValue {
        DISABLE,
        ONE_CHECK_DIGIT,
        TWO_CHECK_DIGITS
    }
}