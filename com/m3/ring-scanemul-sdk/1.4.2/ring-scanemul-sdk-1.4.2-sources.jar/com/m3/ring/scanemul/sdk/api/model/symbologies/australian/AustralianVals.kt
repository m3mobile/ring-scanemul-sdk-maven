package com.m3.ring.scanemul.sdk.api.model.symbologies.australian

data class AustralianVals(
    val enabled: Boolean? = null,
)
