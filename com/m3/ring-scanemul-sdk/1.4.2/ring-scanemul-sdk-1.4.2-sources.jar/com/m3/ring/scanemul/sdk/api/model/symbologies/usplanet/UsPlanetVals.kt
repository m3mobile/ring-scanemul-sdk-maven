package com.m3.ring.scanemul.sdk.api.model.symbologies.usplanet

data class UsPlanetVals(
    val enabled: Boolean? = null,
    val reportCheckDigit: Boolean? = null // true = ENABLE
)
