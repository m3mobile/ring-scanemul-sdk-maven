package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.datamatrix.DataMatrixType
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
object DataMatrixSymbology {
    /* Ids */
    enum class DataMatrixIds(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("dataMatrixEnable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0xF0.toByte(), 0x24.toByte()), totinfo = byteArrayOf(0xF0.toByte(), 0x24.toByte())),

        @BindField("dataMatrixInverse")
        @BindValue(ValueType.ENUM, InverseVal::class)
        INVERSE(zebra = byteArrayOf(0xF1.toByte(), 0x4C.toByte()), totinfo = null),

        @BindField("dataMatrixDecodeMirrorImages")
        @BindValue(ValueType.ENUM, DecodeMirrorImagesVal::class)
        DECODE_MIRROR_IMAGES(zebra = byteArrayOf(0xF1.toByte(), 0x19.toByte())),

        @BindField("dataMatrixGS1DataMatrix")
        @BindValue(ValueType.ENUM, Gs1DataMatrixVal::class)
        GS1_DATA_MATRIX(zebra = byteArrayOf(0xF8.toByte(), 0x05.toByte(), 0x38.toByte()));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnumNameMatch(external = DataMatrixType.InverseType::class)
    enum class InverseVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        REGULAR_ONLY(zebra = byteArrayOf(0x00), totinfo = null),
        INVERSE_ONLY(zebra = byteArrayOf(0x01), totinfo = null),
        AUTO(zebra = byteArrayOf(0x02), totinfo = byteArrayOf(0x02))
    }

    @EnumNameMatch(external = DataMatrixType.DecodeMirrorImagesType::class)
    enum class DecodeMirrorImagesVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        NEVER(zebra = byteArrayOf(0x00)),
        ALWAYS(zebra = byteArrayOf(0x01)),
        AUTO(zebra = byteArrayOf(0x02))
    }

    @EnableDisableEnum
    enum class Gs1DataMatrixVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00))
    }
}
