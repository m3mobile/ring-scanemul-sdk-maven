package com.m3.ring.scanemul.sdk.api.listener

interface OperationResultListener {
    fun onSuccess()
    fun onFailure(errorMsg: String)
}