package com.m3.ring.scanemul.sdk.internal.connection.data.spp.dto

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import com.m3.ring.scanemul.sdk.internal.connection.domain.dto.ConnectionResult

data class SPPConnectionResult(
    override val isSuccess: Boolean,
    override val errorMsg: String? = null,
    override val device: BluetoothDevice,
    val socket: BluetoothSocket? = null,
) : ConnectionResult