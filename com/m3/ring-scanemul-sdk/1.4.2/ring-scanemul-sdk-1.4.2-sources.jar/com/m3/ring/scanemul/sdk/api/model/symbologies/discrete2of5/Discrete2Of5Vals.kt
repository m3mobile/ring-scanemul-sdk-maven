package com.m3.ring.scanemul.sdk.api.model.symbologies.discrete2of5

data class Discrete2Of5Vals(
    val enabled: Boolean? = null,
    val length1: Int? = null,
    val length2: Int? = null
)