package com.m3.ring.scanemul.sdk.api.model.symbologies.code39

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object Code39Type {
    enum class SecurityType : TypeValue {
        LEVEL_0, LEVEL_1, LEVEL_2, LEVEL_3
    }
}