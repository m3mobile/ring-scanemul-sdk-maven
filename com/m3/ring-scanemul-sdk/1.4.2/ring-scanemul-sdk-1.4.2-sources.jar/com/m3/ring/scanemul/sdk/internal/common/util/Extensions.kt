package com.m3.ring.scanemul.sdk.internal.common.util

internal object Extensions {

    /**
     * ByteArray를 16진수 쌍 문자열로 변환합니다.
     * 각 바이트는 2자리 16진수로 표현되며, 바이트 쌍은 세미콜론(;)으로 구분됩니다.
     */
    fun ByteArray.toPairedString(): String = this
        .toList()
        .chunked(2)
        .joinToString(";") { pair ->
            pair.joinToString(",") { byte -> "%02X".format(byte) }
        }

    /**
     * ByteArray의 각 바이트 값을 10진수 문자열로 변환하여 쉼표(,)로 구분된 문자열로 반환합니다.
     */
    fun ByteArray.toDecimalCsv(): String = this
        .map { it.toInt() }.joinToString(",")

    inline fun <T> ByteArray.toIntOrNull(converter: (Byte) -> T): T? {
        val b = this.firstOrNull() ?: return null
        return converter(b)
    }

    internal fun ByteArray.toHexString(): String {
        return joinToString(separator = " ") { byte ->
            String.format("%02X", byte)
        }
    }
}
