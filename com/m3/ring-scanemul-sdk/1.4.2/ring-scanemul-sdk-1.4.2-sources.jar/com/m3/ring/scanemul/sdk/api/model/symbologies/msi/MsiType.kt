package com.m3.ring.scanemul.sdk.api.model.symbologies.msi

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object MsiType {
    enum class CheckDigitType : TypeValue {
        ONE_CHECK_DIGIT, TWO_CHECK_DIGITS
    }

    enum class CheckDigitSchemeType : TypeValue {
        MOD_10_10, MOD_10_11
    }
}