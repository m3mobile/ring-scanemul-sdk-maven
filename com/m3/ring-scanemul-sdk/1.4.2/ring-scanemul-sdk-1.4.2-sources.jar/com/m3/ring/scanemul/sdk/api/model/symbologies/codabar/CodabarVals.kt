package com.m3.ring.scanemul.sdk.api.model.symbologies.codabar

data class CodabarVals(
    val enabled: Boolean? = null,
    val length1: Int? = null,
    val length2: Int? = null,
    val clsiEditing: Boolean? = null,
    val notisEditing: Boolean? = null,
    val securityLevel: CodabarType.SecurityType? = null,
)
