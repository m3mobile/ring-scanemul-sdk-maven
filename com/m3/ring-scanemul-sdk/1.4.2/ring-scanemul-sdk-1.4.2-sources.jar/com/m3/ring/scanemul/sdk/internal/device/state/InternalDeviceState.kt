package com.m3.ring.scanemul.sdk.internal.device.state

/**
 * 디바이스 설정 상태 정보
 */
data class InternalDeviceState(
    val fwSettingInfo: FwSettingInfo = FwSettingInfo(), // 펌웨어 설정 정보
    val scannerSettingInfo: ScannerSettingInfo = ScannerSettingInfo(), // 스캐너 설정 정보
    val name: String = "None", // 디바이스 이름
    val macAddress: String = "None" // 디바이스 MAC 주소
)