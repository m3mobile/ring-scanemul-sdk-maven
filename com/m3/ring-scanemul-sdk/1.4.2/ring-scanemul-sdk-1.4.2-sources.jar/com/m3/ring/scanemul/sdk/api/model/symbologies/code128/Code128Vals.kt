package com.m3.ring.scanemul.sdk.api.model.symbologies.code128

data class Code128Vals(
    val enabled: Boolean? = null,
    val length1: Int? = null,
    val length2: Int? = null,
    val reducedQuietZone: Boolean? = null,
    val ignoreFnc4: Boolean? = null,
    val checkIsbtTable: Boolean? = null,
    val isbt128ConcatMode: Code128Type.ISBT128ConcatModeType? = null,
    val securityLevel: Code128Type.SecurityType? = null,
    val emulationMode: Boolean? = null
)