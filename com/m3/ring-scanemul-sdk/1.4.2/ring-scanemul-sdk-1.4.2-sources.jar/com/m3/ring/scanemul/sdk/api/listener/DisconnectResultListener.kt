package com.m3.ring.scanemul.sdk.api.listener

interface DisconnectResultListener : OperationResultListener