package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
object Matrix2Of5Symbology {
    /* Ids */
    enum class Matrix2Of5Ids(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("matrix2Of5Enable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0xF1.toByte(), 0x6A), totinfo = byteArrayOf(0xF2.toByte(), 0x20.toByte())),

        @BindField("matrix2Of5Length1")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH1(zebra = byteArrayOf(0xF1.toByte(), 0x6B), totinfo = byteArrayOf(0xF5.toByte(), 0x00)),

        @BindField("matrix2Of5Length2")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH2(zebra = byteArrayOf(0xF1.toByte(), 0x6C), totinfo = byteArrayOf(0xF5.toByte(), 0x01)),

        @BindField("matrix2Of5Redundancy")
        @BindValue(ValueType.ENUM, RedundancyVal::class)
        REDUNDANCY(zebra = byteArrayOf(0xF1.toByte(), 0x6D)),

        @BindField("matrix2Of5ReportCheckDigit")
        @BindValue(ValueType.ENUM, ReportCheckDigitVal::class)
        REPORT_CHECK_DIGIT(zebra = byteArrayOf(0xF1.toByte(), 0x6F), totinfo = byteArrayOf(0xF2.toByte(), 0x22)),

        @BindField("matrix2Of5VerifyCheckDigit")
        @BindValue(ValueType.ENUM, VerifyCheckDigitVal::class)
        VERIFY_CHECK_DIGIT(zebra = byteArrayOf(0xF1.toByte(), 0x6E), totinfo = byteArrayOf(0xF2.toByte(), 0x21));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class RedundancyVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class ReportCheckDigitVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class VerifyCheckDigitVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }
}
