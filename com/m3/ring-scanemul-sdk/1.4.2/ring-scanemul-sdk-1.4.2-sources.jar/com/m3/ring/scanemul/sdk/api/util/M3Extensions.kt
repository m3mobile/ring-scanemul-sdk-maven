package com.m3.ring.scanemul.sdk.api.util

import com.m3.ring.scanemul.sdk.api.model.DeviceState
import com.m3.ring.scanemul.sdk.api.settings.SettingCommand
import com.m3.ring.scanemul.sdk.internal.device.mapping.toApiDeviceState
import com.m3.ring.scanemul.sdk.internal.device.mapping.toInternalDeviceState
import com.m3.ring.scanemul.sdk.internal.offline.InternalOfflineApplier
import com.m3.ring.scanemul.sdk.internal.protocol.common.commands.InternalSettingCommand

object M3Extensions {
    @JvmStatic
    fun ByteArray.toUtf8String(): String {
        return String(this, Charsets.UTF_8)
    }

    /**
     * Applies the given [SettingCommand] to the provided [DeviceState],
     * returning an updated [DeviceState].
     *
     * @param state The current device state.
     * @return The updated device state after applying the setting command.
     */
    @JvmStatic
    fun SettingCommand.applyTo(state: DeviceState): DeviceState {
        val internalState = state.toInternalDeviceState()
        val internalCmd: InternalSettingCommand = this.internalSettingCmd   // 래퍼의 internal 필드
        val updated = InternalOfflineApplier.apply(internalState, internalCmd)
        return updated.toApiDeviceState()
    }
}