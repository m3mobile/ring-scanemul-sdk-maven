package com.m3.ring.scanemul.sdk.api.model.symbologies.gs1limited

data class Gs1DataBarLimitedVals(
    val enabled: Boolean? = null,
    val securityLevel: Gs1DataBarLimitedType.SecurityType? = null
)