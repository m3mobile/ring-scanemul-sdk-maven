package com.m3.ring.scanemul.sdk.api.model.symbologies.micropdf417

data class MicroPdf417Vals(
    val enabled: Boolean? = null
)