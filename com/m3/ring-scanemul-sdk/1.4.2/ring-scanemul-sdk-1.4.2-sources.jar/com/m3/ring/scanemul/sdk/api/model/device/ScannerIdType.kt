package com.m3.ring.scanemul.sdk.api.model.device

import com.m3.ring.scanemul.sdk.api.model.TypeValue

enum class ScannerIdType : TypeValue {
    SE4107, E4770, SE5500
}
