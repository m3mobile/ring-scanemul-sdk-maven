package com.m3.ring.scanemul.sdk.api.model.settings.basic

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object BasicFormatType {
    enum class TransmitCodeIdType : TypeValue {
        NONE, AIM, SYMBOL
    }

    enum class EndCharType : TypeValue {
        ENTER, TAB, NONE
    }
}