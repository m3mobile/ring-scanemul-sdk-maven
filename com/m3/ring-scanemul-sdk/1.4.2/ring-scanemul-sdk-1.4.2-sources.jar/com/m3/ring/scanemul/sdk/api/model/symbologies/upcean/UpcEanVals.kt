package com.m3.ring.scanemul.sdk.api.model.symbologies.upcean

data class UpcEanVals(
    val reportEan8CheckDigit: Boolean? = null,
    val reportEan13CheckDigit: Boolean? = null,

    val supplementalMode: UpcEanType.SupplementalModeType? = null, // only for Zebra
    val supplementalAimIdFormat: UpcEanType.SupplementalAimIdFormatType? = null, // only for Zebra
    val reducedQuietZone: Boolean? = null, // only for Zebra
    val booklandEnable: Boolean? = null,
    val booklandFormat: UpcEanType.BooklandFormatType? = null, // only for Zebra
    val uccCouponExtend: Boolean? = null, // only for Zebra
    val couponReport: UpcEanType.CouponReportType? = null, // only for Zebra
    val issnEan: Boolean? = null, // only for Zebra
    val translateUpcAToEan13: Boolean? = null, // only for Zebra
    val supplementalRedundancy: Int? = null, // only for Zebra
    val supplemental2: Boolean? = null, // only for Zebra
    val supplemental5: Boolean? = null, // only for Zebra

    val ean8ReadSupplements: Boolean? = null, // only for Totinfo
    val ean13ReadSupplements: Boolean? = null, // only for Totinfo
    val ean8Supplemental2: Boolean? = null, // only for Totinfo
    val ean13Supplemental2: Boolean? = null, // only for Totinfo
    val ean8Supplemental5: Boolean? = null, // only for Totinfo
    val ean13Supplemental5: Boolean? = null // only for Totinfo
)