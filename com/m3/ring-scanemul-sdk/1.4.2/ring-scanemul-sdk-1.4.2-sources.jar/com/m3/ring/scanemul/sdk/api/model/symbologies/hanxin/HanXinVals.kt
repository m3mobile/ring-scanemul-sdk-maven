package com.m3.ring.scanemul.sdk.api.model.symbologies.hanxin

data class HanXinVals(
    val enabled: Boolean? = null,
    val inverse: HanXinType.InverseType? = null
)