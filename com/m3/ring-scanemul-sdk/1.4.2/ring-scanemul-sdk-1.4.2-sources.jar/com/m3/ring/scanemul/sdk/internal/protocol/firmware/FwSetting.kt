package com.m3.ring.scanemul.sdk.internal.protocol.firmware

import com.m3.ring.scanemul.sdk.api.model.device.BtModeType
import com.m3.ring.scanemul.sdk.api.model.device.ScannerIdType
import com.m3.ring.scanemul.sdk.api.model.device.VendorType
import com.m3.ring.scanemul.sdk.api.model.settings.basic.BasicFormatType
import com.m3.ring.scanemul.sdk.api.model.settings.general.SoundType
import com.m3.ring.scanemul.sdk.api.model.settings.reader.ReaderType
import com.m3.ring.scanemul.sdk.api.util.M3Extensions.toUtf8String
import com.m3.ring.scanemul.sdk.internal.common.util.Extensions.toPairedString
import com.m3.ring.scanemul.sdk.internal.common.util.PacketUtils
import com.m3.ring.scanemul.sdk.internal.device.state.FwSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindFirmwareSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch

object FwSetting {

    enum class FwIds(
        val idByte: Byte,
        private val extractor: (FwSettingInfo) -> Any?, // FwSettingInfo에서 값을 추출하는 함수
        /**
         * FwSettingInfo와 ByteArray를 받아서 업데이트된 FwSettingInfo를 반환하는 함수
         *
         * @param info 현재 FwSettingInfo 객체
         * @param bytes 설정 값이 담긴 ByteArray
         * @return 업데이트된 FwSettingInfo 객체
         */
        val updater: (FwSettingInfo, ByteArray?) -> FwSettingInfo = { info, _ -> info },
        val serializer: (FwSettingInfo) -> ByteArray? = { null },

        /**
         * FwSettingInfo에 값이 반드시 존재해야 하는지 여부
         */
        val requiresExistingValue: Boolean = true // set 전용이라 값이 없어도 되는 경우 false
    ) {
        /**
         * SET으로 시작하는 프로퍼티들은 설정 전용입니다. GET으로 값을 읽을 수 없습니다.
         * GET으로 시작하는 프로퍼티들은 읽기 전용입니다. SET으로 값을 변경할 수 없습니다.
         * 나머지 프로퍼티들은 SET/GET 모두 가능합니다.
         *
         * FwIds 버전이 추가되면, Version의 Major 값을 증가시켜야 합니다.
         * 예) V1.3.8 -> V2.0.0
         *
         * 특정 기능을 추가하기 위해서 펌웨어 명령어가 추가되는 경우, 기존의 ID를 변경하지 않고 새로운 ID를 추가해야 합니다.
         * 즉, 이전 버전의 펌웨어와의 호환성을 유지하기 위해 기존 ID는 그대로 두고, 새로운 기능에 대해서만 새로운 ID를 할당해야 합니다.
         *
         * SDK의 Major 버전은 펌웨어의 Major 버전과 일치해야 합니다.
         */

        /* V1 */
        SET_DEFAULT(
            0x00.toByte(),
            extractor = { null },
            serializer = { null },
            requiresExistingValue = false
        ),
        SET_FIND_ME(
            0x01.toByte(),
            extractor = { null },
            serializer = { null },
            requiresExistingValue = false
        ),
        SET_ALL_FW_CMDS(
            0x1A.toByte(),
            extractor = { null },
            serializer = { null },
            requiresExistingValue = false
        ),

        SET_WITH_CODE_TYPE(
            0x25.toByte(),
            extractor = { null },
            serializer = { null },
            requiresExistingValue = false
        ),

        GET_VENDOR(
            0x09.toByte(),
            extractor = { it.vendor },
            updater = { info, bytes -> info.copy(vendor = Vendor.fromByte(bytes)) }
        ),

        GET_BATTERY(
            0x10.toByte(),
            extractor = { it.battery },
            updater = { info, bytes -> info.copy(battery = bytes?.toUtf8String()?.toIntOrNull()) }
        ),

        GET_SERIAL_NUMBER(
            0x11.toByte(),
            extractor = { it.serialNumber },
            updater = { info, bytes -> info.copy(serialNumber = bytes?.toUtf8String()) }
        ),

        GET_FW_VERSION(
            0x12.toByte(),
            extractor = { it.fwVersion },
            updater = { info, bytes -> info.copy(fwVersion = bytes?.toUtf8String()) }
        ),

        GET_MODEL(
            0x13.toByte(),
            extractor = { it.model },
            updater = { info, bytes -> info.copy(model = bytes?.toUtf8String()) }
        ),

        GET_FW_RELEASE_DATE(
            0x14.toByte(),
            extractor = { it.releaseDate },
            updater = { info, bytes -> info.copy(releaseDate = bytes?.toUtf8String()) }
        ),

        SOUND(
            0x02.toByte(),
            extractor = { it.sound },
            updater = { info, bytes -> info.copy(sound = SoundSetting.fromByte(bytes)) },
            serializer = { info -> info.sound?.value }
        ),

        VIBRATE(
            0x03.toByte(),
            extractor = { it.vibrate },
            updater = { info, bytes -> info.copy(vibrate = VibrateSetting.fromByte(bytes)) },
            serializer = { info -> info.vibrate?.value }
        ),

        BUTTON(
            0x04.toByte(),
            extractor = { it.button },
            updater = { info, bytes -> info.copy(button = ButtonSetting.fromByte(bytes)) },
            serializer = { info -> info.button?.value }
        ),

        END_CHAR(
            0x05.toByte(),
            extractor = { it.endChar },
            updater = { info, bytes -> info.copy(endChar = EndCharSetting.fromByte(bytes)) },
            serializer = { info -> info.endChar?.value }
        ),

        PREFIX(
            0x06.toByte(),
            extractor = { it.prefix },
            updater = { info, bytes -> info.copy(prefix = bytes?.toUtf8String()) },
            serializer = { info -> info.prefix?.takeIf { it.isNotEmpty() }?.toByteArray(Charsets.UTF_8) }
        ),

        POSTFIX(
            0x07.toByte(),
            extractor = { it.postfix },
            updater = { info, bytes -> info.copy(postfix = bytes?.toUtf8String()) },
            serializer = { info -> info.postfix?.takeIf { it.isNotEmpty() }?.toByteArray(Charsets.UTF_8) }
        ),

        MODE(
            0x08.toByte(),
            extractor = { it.mode },
            updater = { info, bytes -> info.copy(mode = BtModeSetting.fromByte(bytes)) },
            serializer = { info -> info.mode?.value }
        ),

        SUBSTRING(
            0x15.toByte(), // [byte,byte] 형식으로 전달해야 한다.
            extractor = { it.substring },
            updater = { info, bytes ->
                val substring = bytes?.map(Byte::toInt)?.joinToString(",")
                info.copy(substring = substring)
            },
            serializer = { info ->
                info.substring?.takeIf { it.isNotEmpty() }?.let(PacketUtils::decimalStringToByteArray)
            }
        ),

        REMOVE_FNC(
            0x16.toByte(),
            extractor = { it.removeFNC },
            updater = { info, bytes -> info.copy(removeFNC = RemoveFnc.fromByte(bytes)) },
            serializer = { info -> info.removeFNC?.value }
        ),

        TRANSLATE_DATA(
            0x17.toByte(), // [byte,byte;byte,byte...] 형식으로 전달해야 한다. (최대 8쌍)
            extractor = { it.translateData },
            updater = { info, bytes ->
                val translateData = bytes?.toPairedString()
                info.copy(translateData = translateData)
            },
            serializer = { info ->
                info.translateData?.takeIf { it.isNotEmpty() }?.let(PacketUtils::hexPairsListToByteArray)
            }
        ),

        PRE_POST_HEX(
            0x18.toByte(),
            extractor = { it.prePostHex },
            updater = { info, bytes -> info.copy(prePostHex = PrePostHex.fromByte(bytes)) },
            serializer = { info -> info.prePostHex?.value }
        ),

        UPCA_TO_EAN13(
            0x19.toByte(),
            extractor = { it.upcaToEan13 },
            updater = { info, bytes -> info.copy(upcaToEan13 = UPCAToEAN13.fromByte(bytes)) },
            serializer = { info -> info.upcaToEan13?.value }
        ),

        BATTERY_CALLBACK(
            0x1B.toByte(),
            extractor = { it.batteryCallback },
            updater = { info, bytes -> info.copy(batteryCallback = BatteryCallback.fromByte(bytes)) },
            serializer = { info -> info.batteryCallback?.value }
        ),

        READ_MODE(
            0x23.toByte(),
            extractor = { it.readMode },
            updater = { info, bytes -> info.copy(readMode = ReadMode.fromByte(bytes)) },
            serializer = { info -> info.readMode?.value }
        ),

        LED(
            0x24.toByte(),
            extractor = { it.led },
            updater = { info, bytes -> info.copy(led = LedSetting.fromByte(bytes)) },
            serializer = { info -> info.led?.value }
        ),

        @BindField("scannerId")
        SCANNER_ID(
            0x26.toByte(),
            extractor = { it.scannerId },
            updater = { info, bytes -> info.copy(scannerId = ScannerId.fromByte(bytes)) },
            serializer = { info -> info.scannerId?.value }
        );

        fun extract(info: FwSettingInfo): Any? = extractor(info)

        fun updateFwSettingInfo(bytes: ByteArray, info: FwSettingInfo): FwSettingInfo =
            updater(info, bytes)

        companion object {
            fun fromByte(byte: Byte): FwIds? =
                entries.find { it.idByte == byte }
        }
    }

    /* values */
    enum class Default(override val value: ByteArray) : FwValue {
        ENABLE(byteArrayOf(0x01.toByte()));
    }

    enum class FindMe(override val value: ByteArray) : FwValue {
        ENABLE(byteArrayOf(0x01.toByte()));
    }

    @EnumNameMatch(external = SoundType::class)
    enum class SoundSetting(override val value: ByteArray) : FwValue {
        ON(byteArrayOf(0x01.toByte())),
        OFF(byteArrayOf(0x00.toByte())),
        MUTE_ON_FAILED_SCAN(byteArrayOf(0x02.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): SoundSetting? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnableDisableEnum
    enum class VibrateSetting(override val value: ByteArray) : FwValue {
        DISABLE(byteArrayOf(0x00.toByte())),
        ENABLE(byteArrayOf(0x01.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): VibrateSetting? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnableDisableEnum
    enum class ButtonSetting(override val value: ByteArray) : FwValue {
        DISABLE(byteArrayOf(0x00.toByte())),
        ENABLE(byteArrayOf(0x01.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): ButtonSetting? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnumNameMatch(external = BasicFormatType.EndCharType::class)
    enum class EndCharSetting(override val value: ByteArray) : FwValue {
        ENTER(byteArrayOf(0x00.toByte())),
        TAB(byteArrayOf(0x01.toByte())),
        NONE(byteArrayOf(0x02.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): EndCharSetting? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnumNameMatch(external = BtModeType::class)
    enum class BtModeSetting(override val value: ByteArray) : FwValue {
        HID(byteArrayOf(0x00.toByte())),
        SPP(byteArrayOf(0x01.toByte()));
        // BLE(0x02.toByte()) // 필요시 추가

        companion object {
            fun fromByte(byte: ByteArray?): BtModeSetting? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnumNameMatch(external = VendorType::class)
    enum class Vendor(override val value: ByteArray) : FwValue {
        ZEBRA(byteArrayOf(0x00.toByte())),
        TOTINFO(byteArrayOf(0x01.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): Vendor? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnableDisableEnum
    enum class RemoveFnc(override val value: ByteArray) : FwValue {
        DISABLE(byteArrayOf(0x00.toByte())),
        ENABLE(byteArrayOf(0x01.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): RemoveFnc? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnableDisableEnum
    enum class PrePostHex(override val value: ByteArray) : FwValue {
        DISABLE(byteArrayOf(0x00.toByte())),
        ENABLE(byteArrayOf(0x01.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): PrePostHex? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnableDisableEnum
    enum class UPCAToEAN13(override val value: ByteArray) : FwValue {
        DISABLE(byteArrayOf(0x00.toByte())),
        ENABLE(byteArrayOf(0x01.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): UPCAToEAN13? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnumNameMatch(external = ReaderType.ReadModeType::class)
    enum class ReadMode(override val value: ByteArray) : FwValue {
        ASYNC(byteArrayOf(0x00.toByte())),
        SYNC(byteArrayOf(0x01.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): ReadMode? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnableDisableEnum
    enum class LedSetting(override val value: ByteArray) : FwValue {
        DISABLE(byteArrayOf(0x00.toByte())),
        ENABLE(byteArrayOf(0x01.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): LedSetting? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnableDisableEnum
    enum class SetWithCodeType(override val value: ByteArray) : FwValue {
        DISABLE(byteArrayOf(0x00.toByte())),
        ENABLE(byteArrayOf(0x01.toByte()));
    }

    /**
     * 스캐너 ID
     * - SE4107: Zebra SE4107 스캐너
     * - E4770: Totinfo E4770 스캐너
     * - SE5500: Zebra SE5500 스캐너
     */
    @EnumNameMatch(external = ScannerIdType::class)
    enum class ScannerId(override val value: ByteArray) : FwValue {
        SE4107(byteArrayOf(0x00.toByte())),
        E4770(byteArrayOf(0x01.toByte())),
        SE5500(byteArrayOf(0x02.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): ScannerId? =
                entries.find { it.value.contentEquals(byte) }
        }
    }

    @EnableDisableEnum
    enum class BatteryCallback(override val value: ByteArray) : FwValue {
        DISABLE(byteArrayOf(0x00.toByte())),
        ENABLE(byteArrayOf(0x01.toByte()));

        companion object {
            fun fromByte(byte: ByteArray?): BatteryCallback? =
                entries.find { it.value.contentEquals(byte) }
        }
    }
}
