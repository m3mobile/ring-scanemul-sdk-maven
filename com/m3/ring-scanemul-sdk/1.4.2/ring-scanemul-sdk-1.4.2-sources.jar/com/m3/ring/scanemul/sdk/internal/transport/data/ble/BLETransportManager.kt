package com.m3.ring.scanemul.sdk.internal.transport.data.ble

import android.bluetooth.BluetoothGatt
import com.m3.ring.scanemul.sdk.internal.transport.domain.TransportManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.flow.SharedFlow

//TODO 추후 BLETransportManager 구현
// 현재는 TransportManager 인터페이스를 구현하는 빈 클래스 형태로 작성
class BLETransportManager(private val gatt: BluetoothGatt, private val scope: CoroutineScope) : TransportManager {
    override fun startRead() {
        TODO("Not yet implemented")
    }

    override fun observeBinaryCommandData(): SharedFlow<ByteArray> {
        TODO("Not yet implemented")
    }

    override fun observeBarcodeData(): SharedFlow<ByteArray> {
        TODO("Not yet implemented")
    }

    override fun startWriteWorker() {
        TODO("Not yet implemented")
    }

    override fun requestWrite(data: ByteArray) {
        TODO("Not yet implemented")
    }

    override suspend fun requestWriteWithAck(data: ByteArray): Deferred<Boolean> {
        TODO("Not yet implemented")
    }

    override suspend fun requestGetScannerAllSettings(byteList: List<ByteArray>, onResult: (Boolean) -> Unit) {
        TODO("Not yet implemented")
    }

    override fun disconnect(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit) {
        TODO("Not yet implemented")
    }

    override fun observeDisconnect(): SharedFlow<Unit> {
        TODO("Not yet implemented")
    }
}