package com.m3.ring.scanemul.sdk.internal.protocol.common.commands

import com.m3.ring.scanemul.sdk.api.model.settings.basic.BasicFormatType
import com.m3.ring.scanemul.sdk.api.model.settings.general.SoundType
import com.m3.ring.scanemul.sdk.api.model.settings.reader.ReaderType
import com.m3.ring.scanemul.sdk.api.model.symbologies.codabar.CodabarType
import com.m3.ring.scanemul.sdk.api.model.symbologies.code11.Code11Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.code128.Code128Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.code39.Code39Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.datamatrix.DataMatrixType
import com.m3.ring.scanemul.sdk.api.model.symbologies.dotcode.DotCodeType
import com.m3.ring.scanemul.sdk.api.model.symbologies.gs1limited.Gs1DataBarLimitedType
import com.m3.ring.scanemul.sdk.api.model.symbologies.hanxin.HanXinType
import com.m3.ring.scanemul.sdk.api.model.symbologies.interleaved2of5.Interleaved2Of5Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.msi.MsiType
import com.m3.ring.scanemul.sdk.api.model.symbologies.upca.UpcAType
import com.m3.ring.scanemul.sdk.api.model.symbologies.upce.UpcEType
import com.m3.ring.scanemul.sdk.api.model.symbologies.upce1.UpcE1Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.upcean.UpcEanType
import com.m3.ring.scanemul.sdk.api.util.M3Utils
import com.m3.ring.scanemul.sdk.internal.common.consts.Const
import com.m3.ring.scanemul.sdk.internal.common.util.PacketUtils
import com.m3.ring.scanemul.sdk.internal.device.mapping.toBoolInternal
import com.m3.ring.scanemul.sdk.internal.device.mapping.toEnumInternal
import com.m3.ring.scanemul.sdk.internal.protocol.common.values.ByteArrayValue
import com.m3.ring.scanemul.sdk.internal.protocol.common.values.IntValue
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting.FwIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.BasicFormatSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.BasicFormatSetting.BasicFormatIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.GeneralSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.GeneralSetting.GeneralIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.ReaderSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.ReaderSetting.ReaderIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.AustralianPostalSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.AustralianPostalSymbology.AustralianPostalIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.AztecSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Chinese2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.CodabarSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.CodabarSymbology.CodabarIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code11Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code11Symbology.Code11Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code128Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code128Symbology.Code128Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code39Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code39Symbology.Code39Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code93Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code93Symbology.Code93Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.CompositeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.CompositeSymbology.CompositeIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.DataMatrixSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.DataMatrixSymbology.DataMatrixIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Discrete2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Discrete2Of5Symbology.Discrete2Of5Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.DotCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.DotCodeSymbology.DotCodeIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Ean13Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Ean13Symbology.Ean13Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Ean8Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Ean8Symbology.Ean8Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1128Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1128Symbology.Gs1128Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DataBar14Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DataBar14Symbology.Gs1DataBar14Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DataBarLimitedSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DataBarLimitedSymbology.Gs1DataBarLimitedIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DatabarExpandedSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DatabarExpandedSymbology.Gs1DatabarExpandedIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.HanXinSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.HanXinSymbology.HanXinIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Interleaved2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Interleaved2Of5Symbology.Interleaved2Of5Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Isbt128Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Isbt128Symbology.Isbt128Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.JapanesePostalSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.JapanesePostalSymbology.JapanesePostalIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Korean3Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Korean3Of5Symbology.Korean3Of5Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Matrix2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Matrix2Of5Symbology.Matrix2Of5Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MaxiCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MaxiCodeSymbology.MaxiCodeIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MicroPdf417Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MicroPdf417Symbology.MicroPdf417Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MicroQrCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MicroQrCodeSymbology.MicroQrCodeIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MsiSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MsiSymbology.MSIIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.NetherlandsKixSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.NetherlandsKixSymbology.NetherlandsKixIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Pdf417Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Pdf417Symbology.Pdf417Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.QrCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.QrCodeSymbology.QrCodeIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UKPostalSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UKPostalSymbology.UKPostalIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCASymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCASymbology.UPCAIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCE1Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCE1Symbology.UPCE1Ids
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCESymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCESymbology.UPCEIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCEanSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCEanSymbology.UPCEanIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.USPlanetSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.USPlanetSymbology.USPlanetIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.USPostnetSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.USPostnetSymbology.USPostnetIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UpuFicsPostalSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UpuFicsPostalSymbology.UpuFicsPostalIds


/**
 * 내부 설정 생성기: 외부에는 공개되지 않으며, api/Settings.kt가 여기로 위임합니다.
 * 반환 타입은 모두 InternalSettingCommand 입니다.
 */
internal object InternalSettings {
    object Codabar {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                CodabarIds.ENABLE,
                enable.toBoolInternal<CodabarSymbology.EnableVal>()
            )

        fun setLength1(length: Int) =
            InternalSettingCommand.Valid.Scanner(CodabarIds.LENGTH1, IntValue(length))

        fun setLength2(length: Int) =
            InternalSettingCommand.Valid.Scanner(CodabarIds.LENGTH2, IntValue(length))

        fun setCLSIEditing(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                CodabarIds.CLSI_EDITING,
                enable.toBoolInternal<CodabarSymbology.ClsiEditingVal>()
            )

        fun setNotisEditing(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                CodabarIds.NOTIS_EDITING,
                enable.toBoolInternal<CodabarSymbology.NotisEditingVal>()
            )

        fun setSecurityLevel(value: CodabarType.SecurityType) =
            InternalSettingCommand.Valid.Scanner(
                CodabarIds.SECURITY_LEVEL,
                value.toEnumInternal<CodabarSymbology.SecurityLevelVal>()
            )
    }

    object Code11 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code11Ids.ENABLE,
                enable.toBoolInternal<Code11Symbology.EnableVal>()
            )

        fun setLength1(length: Int) =
            InternalSettingCommand.Valid.Scanner(Code11Ids.LENGTH1, IntValue(length))

        fun setLength2(length: Int) =
            InternalSettingCommand.Valid.Scanner(Code11Ids.LENGTH2, IntValue(length))

        fun setReportCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code11Ids.REPORT_CHECK_DIGIT,
                enable.toBoolInternal<Code11Symbology.ReportCheckDigitVal>()
            )

        fun setVerifyCheckDigit(value: Code11Type.VerifyCheckDigitType) =
            InternalSettingCommand.Valid.Scanner(
                Code11Ids.VERIFY_CHECK_DIGIT,
                value.toEnumInternal<Code11Symbology.VerifyCheckDigitVal>()
            )
    }

    object Code39 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code39Ids.ENABLE,
                enable.toBoolInternal<Code39Symbology.EnableVal>()
            )

        fun setTriopticCode39(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code39Ids.TRIOPTIC_CODE39,
                enable.toBoolInternal<Code39Symbology.TriopticCode39Val>()
            )

        fun setLength1(length: Int) =
            InternalSettingCommand.Valid.Scanner(Code39Ids.LENGTH1, IntValue(length))

        fun setLength2(length: Int) =
            InternalSettingCommand.Valid.Scanner(Code39Ids.LENGTH2, IntValue(length))

        fun setReducedQuietZone(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code39Ids.REDUCED_QUIET_ZONE,
                enable.toBoolInternal<Code39Symbology.ReducedQuietZoneVal>()
            )

        fun setConvertToCode32(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code39Ids.CONVERT_TO_CODE32,
                enable.toBoolInternal<Code39Symbology.ConvertToCode32Val>()
            )

        fun setFullAscii(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code39Ids.FULL_ASCII,
                enable.toBoolInternal<Code39Symbology.FullAsciiVal>()
            )

        fun setReportCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code39Ids.REPORT_CHECK_DIGIT,
                enable.toBoolInternal<Code39Symbology.ReportCheckDigitVal>()
            )

        fun setReportCode32Prefix(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code39Ids.REPORT_CODE32_PREFIX,
                enable.toBoolInternal<Code39Symbology.ReportCode32PrefixVal>()
            )

        fun setSecurityLevel(value: Code39Type.SecurityType) =
            InternalSettingCommand.Valid.Scanner(
                Code39Ids.SECURITY_LEVEL,
                value.toEnumInternal<Code39Symbology.SecurityLevelVal>()
            )

        fun setVerifyCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code39Ids.VERIFY_CHECK_DIGIT,
                enable.toBoolInternal<Code39Symbology.VerifyCheckDigitVal>()
            )
    }

    object Code93 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code93Ids.ENABLE,
                enable.toBoolInternal<Code93Symbology.EnableVal>()
            )

        fun setLength1(length: Int) =
            InternalSettingCommand.Valid.Scanner(Code93Ids.LENGTH1, IntValue(length))

        fun setLength2(length: Int) =
            InternalSettingCommand.Valid.Scanner(Code93Ids.LENGTH2, IntValue(length))
    }

    object Code128 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code128Ids.ENABLE,
                enable.toBoolInternal<Code128Symbology.EnableVal>()
            )

        fun setLength1(length: Int) =
            InternalSettingCommand.Valid.Scanner(Code128Ids.LENGTH1, IntValue(length))

        fun setLength2(length: Int) =
            InternalSettingCommand.Valid.Scanner(Code128Ids.LENGTH2, IntValue(length))

        fun setReducedQuietZone(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code128Ids.REDUCED_QUIET_ZONE,
                enable.toBoolInternal<Code128Symbology.ReducedQuietZoneVal>()
            )

        fun setIgnoreFnc4(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code128Ids.IGNORE_FNC4,
                enable.toBoolInternal<Code128Symbology.IgnoreFNC4Val>()
            )

        fun setCheckIsbtTable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code128Ids.CHECK_ISBT_TABLE,
                enable.toBoolInternal<Code128Symbology.CheckISBTTableVal>()
            )

        fun setIsbt128ConcatMode(value: Code128Type.ISBT128ConcatModeType) =
            InternalSettingCommand.Valid.Scanner(
                Code128Ids.ISBT128_CONCAT_MODE,
                value.toEnumInternal<Code128Symbology.ISBT128ConcatModeVal>()
            )

        fun setSecurityLevel(value: Code128Type.SecurityType) =
            InternalSettingCommand.Valid.Scanner(
                Code128Ids.SECURITY_LEVEL,
                value.toEnumInternal<Code128Symbology.SecurityLevelVal>()
            )

        fun setEmulationMode(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Code128Ids.EMULATION_MODE,
                enable.toBoolInternal<Code128Symbology.EmulationModeVal>()
            )
    }

    object Gs1128 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Gs1128Ids.ENABLE,
                enable.toBoolInternal<Gs1128Symbology.EnableVal>()
            )
    }

    object Gs1DataBar14 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Gs1DataBar14Ids.ENABLE,
                enable.toBoolInternal<Gs1DataBar14Symbology.EnableVal>()
            )
    }

    object ISBT128 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Isbt128Ids.ENABLE,
                enable.toBoolInternal<Isbt128Symbology.EnableVal>()
            )
    }

    object Composite {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                CompositeIds.ENABLE,
                enable.toBoolInternal<CompositeSymbology.EnableVal>()
            )

        fun setABEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                CompositeIds.AB_ENABLE,
                enable.toBoolInternal<CompositeSymbology.AbEnableVal>()
            )

        fun setCEnable(value: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                CompositeIds.C_ENABLE,
                value.toBoolInternal<CompositeSymbology.CEnableVal>()
            )

        fun setTlc39Enable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                CompositeIds.TLC39_ENABLE,
                enable.toBoolInternal<CompositeSymbology.Tlc39EnableVal>()
            )

        fun setUpcCompositeMode(
            value: com.m3.ring.scanemul.sdk.api.model.symbologies.composite.CompositeType.UPCCompositeModeType
        ) =
            InternalSettingCommand.Valid.Scanner(
                CompositeIds.UPC_COMPOSITE_MODE,
                value.toEnumInternal<CompositeSymbology.UpcCompositeModeVal>()
            )
    }

    object DataMatrix {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                DataMatrixIds.ENABLE,
                enable.toBoolInternal<DataMatrixSymbology.EnableVal>()
            )

        fun setInverse(value: DataMatrixType.InverseType) =
            InternalSettingCommand.Valid.Scanner(
                DataMatrixIds.INVERSE,
                value.toEnumInternal<DataMatrixSymbology.InverseVal>()
            )

        fun setDecodeMirrorImages(value: DataMatrixType.DecodeMirrorImagesType) =
            InternalSettingCommand.Valid.Scanner(
                DataMatrixIds.DECODE_MIRROR_IMAGES,
                value.toEnumInternal<DataMatrixSymbology.DecodeMirrorImagesVal>()
            )

        fun setGs1DataMatrix(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                DataMatrixIds.GS1_DATA_MATRIX,
                enable.toBoolInternal<DataMatrixSymbology.Gs1DataMatrixVal>()
            )
    }

    object Discrete2Of5 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Discrete2Of5Ids.ENABLE,
                enable.toBoolInternal<Discrete2Of5Symbology.EnableVal>()
            )

        fun setLength1(length: Int) =
            InternalSettingCommand.Valid.Scanner(Discrete2Of5Ids.LENGTH1, IntValue(length))

        fun setLength2(length: Int) =
            InternalSettingCommand.Valid.Scanner(Discrete2Of5Ids.LENGTH2, IntValue(length))
    }

    object Gs1DataBarLimited {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Gs1DataBarLimitedIds.ENABLE,
                enable.toBoolInternal<Gs1DataBarLimitedSymbology.EnableVal>()
            )

        fun setLimitedSecurityLevel(value: Gs1DataBarLimitedType.SecurityType) =
            InternalSettingCommand.Valid.Scanner(
                Gs1DataBarLimitedIds.LIMITED_SECURITY_LEVEL,
                value.toEnumInternal<Gs1DataBarLimitedSymbology.LimitedSecurityLevelVal>()
            )
    }

    object Gs1DataBarExpanded {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Gs1DatabarExpandedIds.ENABLE,
                enable.toBoolInternal<Gs1DatabarExpandedSymbology.EnableVal>()
            )
    }

    object HanXin {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                HanXinIds.ENABLE,
                enable.toBoolInternal<HanXinSymbology.EnableVal>()
            )

        fun setInverse(value: HanXinType.InverseType) =
            InternalSettingCommand.Valid.Scanner(
                HanXinIds.INVERSE,
                value.toEnumInternal<HanXinSymbology.InverseVal>()
            )
    }

    object Interleaved2Of5 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Interleaved2Of5Ids.ENABLE,
                enable.toBoolInternal<Interleaved2Of5Symbology.EnableVal>()
            )

        fun setLength1(length: Int) =
            InternalSettingCommand.Valid.Scanner(Interleaved2Of5Ids.LENGTH1, IntValue(length))

        fun setLength2(length: Int) =
            InternalSettingCommand.Valid.Scanner(Interleaved2Of5Ids.LENGTH2, IntValue(length))

        fun setCheckDigit(value: Interleaved2Of5Type.CheckDigitType) =
            InternalSettingCommand.Valid.Scanner(
                Interleaved2Of5Ids.CHECK_DIGIT,
                value.toEnumInternal<Interleaved2Of5Symbology.CheckDigitVal>()
            )

        fun setReportCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Interleaved2Of5Ids.TRANSMIT_CHECK_DIGIT,
                enable.toBoolInternal<Interleaved2Of5Symbology.ReportCheckDigitVal>()
            )

        fun setSecurityLevel(value: Interleaved2Of5Type.SecurityType) =
            InternalSettingCommand.Valid.Scanner(
                Interleaved2Of5Ids.I2OF5_SECURITY_LEVEL,
                value.toEnumInternal<Interleaved2Of5Symbology.SecurityLevelVal>()
            )

        fun setConvertItf14ToEan13(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Interleaved2Of5Ids.CONVERT_ITF14_TO_EAN13,
                enable.toBoolInternal<Interleaved2Of5Symbology.ConvertITF14ToEAN13Val>()
            )

        fun setReducedQuietZone(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Interleaved2Of5Ids.I2OF5_REDUCED_QUIET_ZONE,
                enable.toBoolInternal<Interleaved2Of5Symbology.ReducedQuietZoneVal>()
            )
    }

    object Matrix2Of5 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Matrix2Of5Ids.ENABLE,
                enable.toBoolInternal<Matrix2Of5Symbology.EnableVal>()
            )

        fun setLength1(length: Int) =
            InternalSettingCommand.Valid.Scanner(Matrix2Of5Ids.LENGTH1, IntValue(length))

        fun setLength2(length: Int) =
            InternalSettingCommand.Valid.Scanner(Matrix2Of5Ids.LENGTH2, IntValue(length))

        fun setRedundancy(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Matrix2Of5Ids.REDUNDANCY,
                enable.toBoolInternal<Matrix2Of5Symbology.RedundancyVal>()
            )

        fun setReportCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Matrix2Of5Ids.REPORT_CHECK_DIGIT,
                enable.toBoolInternal<Matrix2Of5Symbology.ReportCheckDigitVal>()
            )

        fun setVerifyCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Matrix2Of5Ids.VERIFY_CHECK_DIGIT,
                enable.toBoolInternal<Matrix2Of5Symbology.VerifyCheckDigitVal>()
            )
    }

    object MSI {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                MSIIds.ENABLE,
                enable.toBoolInternal<MsiSymbology.EnableVal>()
            )

        fun setLength1(length: Int) =
            InternalSettingCommand.Valid.Scanner(MSIIds.LENGTH1, IntValue(length))

        fun setLength2(length: Int) =
            InternalSettingCommand.Valid.Scanner(MSIIds.LENGTH2, IntValue(length))

        fun setCheckDigit(value: MsiType.CheckDigitType) =
            InternalSettingCommand.Valid.Scanner(
                MSIIds.CHECK_DIGIT,
                value.toEnumInternal<MsiSymbology.CheckDigitVal>()
            )

        fun setCheckDigitScheme(value: MsiType.CheckDigitSchemeType) =
            InternalSettingCommand.Valid.Scanner(
                MSIIds.CHECK_DIGIT_SCHEME,
                value.toEnumInternal<MsiSymbology.CheckDigitSchemeVal>()
            )

        fun setReportCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                MSIIds.REPORT_CHECK_DIGIT,
                enable.toBoolInternal<MsiSymbology.ReportCheckDigitVal>()
            )
    }

    object UPCA {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCAIds.ENABLE,
                enable.toBoolInternal<UPCASymbology.EnableVal>()
            )

        fun setReportCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCAIds.REPORT_CHECK_DIGIT,
                enable.toBoolInternal<UPCASymbology.ReportCheckDigitVal>()
            )

        fun setPreamble(value: UpcAType.PreambleType) =
            InternalSettingCommand.Valid.Scanner(
                UPCAIds.PREAMBLE,
                value.toEnumInternal<UPCASymbology.PreambleVal>()
            )

        fun setSupplemental2Bit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCAIds.UPCA_2BITS_SUPPLEMENTALS,
                enable.toBoolInternal<UPCASymbology.Upca2BitsSupplementalsVal>()
            )

        fun setSupplemental5Bit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCAIds.UPCA_5BITS_SUPPLEMENTALS,
                enable.toBoolInternal<UPCASymbology.Upca5BitsSupplementalsVal>()
            )
    }

    object UPCE1 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCE1Ids.ENABLE,
                enable.toBoolInternal<UPCE1Symbology.EnableVal>()
            )

        fun setConvertToUpcA(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCE1Ids.CONVERT_TO_UPC_A,
                enable.toBoolInternal<UPCE1Symbology.ConvertToUpcAVal>()
            )

        fun setPreamble(value: UpcE1Type.PreambleType) =
            InternalSettingCommand.Valid.Scanner(
                UPCE1Ids.PREAMBLE,
                value.toEnumInternal<UPCE1Symbology.PreambleVal>()
            )

        fun setReportCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCE1Ids.REPORT_CHECK_DIGIT,
                enable.toBoolInternal<UPCE1Symbology.ReportCheckDigitVal>()
            )
    }

    object UPCE {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEIds.ENABLE,
                enable.toBoolInternal<UPCESymbology.EnableVal>()
            )

        fun setConvertToUpcA(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEIds.CONVERT_TO_UPC_A,
                enable.toBoolInternal<UPCESymbology.ConvertToUpcAVal>()
            )

        fun setPreamble(value: UpcEType.PreambleType) =
            InternalSettingCommand.Valid.Scanner(
                UPCEIds.PREAMBLE,
                value.toEnumInternal<UPCESymbology.PreambleVal>()
            )

        fun setReportCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEIds.REPORT_CHECK_DIGIT,
                enable.toBoolInternal<UPCESymbology.ReportCheckDigitVal>()
            )

        fun setSupplemental2Bit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEIds.UPCE_2BITS_SUPPLEMENTALS,
                enable.toBoolInternal<UPCESymbology.Upce2BitsSupplementalsVal>()
            )

        fun setSupplemental5Bit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEIds.UPCE_5BITS_SUPPLEMENTALS,
                enable.toBoolInternal<UPCESymbology.Upce5BitsSupplementalsVal>()
            )
    }

    object USPlanet {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                USPlanetIds.ENABLE,
                enable.toBoolInternal<USPlanetSymbology.EnableVal>()
            )

        fun setReportCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                USPlanetIds.REPORT_CHECK_DIGIT,
                enable.toBoolInternal<USPlanetSymbology.ReportCheckDigitVal>()
            )
    }

    object UKPostal {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UKPostalIds.ENABLE,
                enable.toBoolInternal<UKPostalSymbology.EnableVal>()
            )

        fun setReportCheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UKPostalIds.REPORT_CHECK_DIGIT,
                enable.toBoolInternal<UKPostalSymbology.ReportCheckDigitVal>()
            )
    }

    object Chinese2of5 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Chinese2Of5Symbology.Chinese2Of5Ids.ENABLE,
                enable.toBoolInternal<Chinese2Of5Symbology.EnableVal>()
            )
    }

    object DotCode {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                DotCodeIds.ENABLE,
                enable.toBoolInternal<DotCodeSymbology.EnableVal>()
            )

        fun setInverse(value: DotCodeType.InverseType) =
            InternalSettingCommand.Valid.Scanner(
                DotCodeIds.INVERSE,
                value.toEnumInternal<DotCodeSymbology.InverseVal>()
            )

        fun setMirror(value: DotCodeType.MirrorType) =
            InternalSettingCommand.Valid.Scanner(
                DotCodeIds.MIRROR,
                value.toEnumInternal<DotCodeSymbology.MirrorVal>()
            )

        fun setPrioritize(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                DotCodeIds.PRIORITIZE,
                enable.toBoolInternal<DotCodeSymbology.PrioritizeVal>()
            )
    }

    object EAN8 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(Ean8Ids.ENABLE, enable.toBoolInternal<Ean8Symbology.EnableVal>())
    }

    object EAN13 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Ean13Ids.ENABLE,
                enable.toBoolInternal<Ean13Symbology.EnableVal>()
            )
    }

    object UPCEan {
        fun setReportEan8CheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.REPORT_EAN8_CHECK_DIGIT,
                enable.toBoolInternal<UPCEanSymbology.ReportEan8CheckDigitVal>()
            )

        fun setReportEan13CheckDigit(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.REPORT_EAN13_CHECK_DIGIT,
                enable.toBoolInternal<UPCEanSymbology.ReportEan13CheckDigitVal>()
            )

        fun setSupplementalMode(value: UpcEanType.SupplementalModeType) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.SUPPLEMENTAL_MODE,
                value.toEnumInternal<UPCEanSymbology.SupplementalModeVal>()
            )

        fun setSupplementalAimIdFormat(value: UpcEanType.SupplementalAimIdFormatType) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.SUPPLEMENTAL_AIM_ID_FORMAT,
                value.toEnumInternal<UPCEanSymbology.SupplementalAimIdFormatVal>()
            )

        fun setReducedQuietZone(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.REDUCED_QUIET_ZONE,
                enable.toBoolInternal<UPCEanSymbology.ReducedQuietZoneVal>()
            )

        fun setBooklandEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.BOOKLAND_ENABLE,
                enable.toBoolInternal<UPCEanSymbology.BooklandEnableVal>()
            )

        fun setBooklandFormat(value: UpcEanType.BooklandFormatType) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.BOOKLAND_FORMAT,
                value.toEnumInternal<UPCEanSymbology.BooklandFormatVal>()
            )

        fun setUccCouponExtend(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.UCC_COUPON_EXTEND,
                enable.toBoolInternal<UPCEanSymbology.UccCouponExtendVal>()
            )

        fun setCouponReport(value: UpcEanType.CouponReportType) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.COUPON_REPORT,
                value.toEnumInternal<UPCEanSymbology.CouponReportVal>()
            )

        fun setIssnEan(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.ISSN_EAN,
                enable.toBoolInternal<UPCEanSymbology.IssnEanVal>()
            )

        fun setTranslateUpcAToEan13(enable: Boolean) =
            InternalSettingCommand.Valid.Firmware(FwIds.UPCA_TO_EAN13, enable.toBoolInternal<FwSetting.UPCAToEAN13>())

        fun setSupplementalRedundancy(value: Int) =
            InternalSettingCommand.Valid.Scanner(UPCEanIds.SUPPLEMENTAL_REDUNDANCY, IntValue(value))

        fun setEanSupplemental2(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.EAN_SUPPLEMENTAL_2,
                enable.toBoolInternal<UPCEanSymbology.Supplemental2Val>()
            )

        fun setEanSupplemental5(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.EAN_SUPPLEMENTAL_5,
                enable.toBoolInternal<UPCEanSymbology.Supplemental5Val>()
            )

        fun setEan8ReadSupplementals(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.EAN8_READ_SUPPLEMENTS,
                enable.toBoolInternal<UPCEanSymbology.Ean8ReadSupplementsVal>()
            )

        fun setEan13ReadSupplementals(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.EAN13_READ_SUPPLEMENTS,
                enable.toBoolInternal<UPCEanSymbology.Ean13ReadSupplementsVal>()
            )

        fun setEan8Supplemental2(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.EAN8_SUPPLEMENTAL_2,
                enable.toBoolInternal<UPCEanSymbology.Ean8Supplemental2Val>()
            )

        fun setEan13Supplemental2(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.EAN13_SUPPLEMENTAL_2,
                enable.toBoolInternal<UPCEanSymbology.Ean13Supplemental2Val>()
            )

        fun setEan8Supplemental5(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.EAN8_SUPPLEMENTAL_5,
                enable.toBoolInternal<UPCEanSymbology.Ean8Supplemental5Val>()
            )

        fun setEan13Supplemental5(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UPCEanIds.EAN13_SUPPLEMENTAL_5,
                enable.toBoolInternal<UPCEanSymbology.Ean13Supplemental5Val>()
            )
    }

    object Pdf417 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Pdf417Ids.ENABLE,
                enable.toBoolInternal<Pdf417Symbology.EnableVal>()
            )
    }

    object MicroPdf417 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                MicroPdf417Ids.ENABLE,
                enable.toBoolInternal<MicroPdf417Symbology.EnableVal>()
            )
    }

    object QrCode {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                QrCodeIds.ENABLE,
                enable.toBoolInternal<QrCodeSymbology.EnableVal>()
            )
    }

    object MicroQrCode {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                MicroQrCodeIds.ENABLE,
                enable.toBoolInternal<MicroQrCodeSymbology.EnableVal>()
            )
    }

    object Aztec {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                AztecSymbology.AztecIds.ENABLE,
                enable.toBoolInternal<AztecSymbology.EnableVal>()
            )
    }

    object JapanesePostal {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                JapanesePostalIds.ENABLE,
                enable.toBoolInternal<JapanesePostalSymbology.EnableVal>()
            )
    }

    object Korean3of5 {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                Korean3Of5Ids.ENABLE,
                enable.toBoolInternal<Korean3Of5Symbology.EnableVal>()
            )
    }

    object MaxiCode {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                MaxiCodeIds.ENABLE,
                enable.toBoolInternal<MaxiCodeSymbology.EnableVal>()
            )
    }

    object USPostnet {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                USPostnetIds.ENABLE,
                enable.toBoolInternal<USPostnetSymbology.EnableVal>()
            )
    }

    object NetherlandsKix {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                NetherlandsKixIds.ENABLE,
                enable.toBoolInternal<NetherlandsKixSymbology.EnableVal>()
            )
    }

    object AustralianPostal {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                AustralianPostalIds.ENABLE,
                enable.toBoolInternal<AustralianPostalSymbology.EnableVal>()
            )
    }

    object UpuFicsPostal {
        fun setEnable(enable: Boolean) =
            InternalSettingCommand.Valid.Scanner(
                UpuFicsPostalIds.ENABLE,
                enable.toBoolInternal<UpuFicsPostalSymbology.EnableVal>()
            )
    }

    object General {
        fun findMe(): InternalSettingCommand =
            InternalSettingCommand.Valid.Firmware(FwIds.SET_FIND_ME, FwSetting.FindMe.ENABLE)

        fun setAimer(enable: Boolean): InternalSettingCommand =
            InternalSettingCommand.Valid.Scanner(
                GeneralIds.AIM,
                enable.toBoolInternal<GeneralSetting.AimVal>()
            )

        fun setIllumination(enable: Boolean): InternalSettingCommand =
            InternalSettingCommand.Valid.Scanner(
                GeneralIds.ILLUMINATION,
                enable.toBoolInternal<GeneralSetting.IlluminationVal>()
            )

        fun setSound(type: SoundType): InternalSettingCommand =
            InternalSettingCommand.Valid.Firmware(FwIds.SOUND, type.toEnumInternal<FwSetting.SoundSetting>())

        fun setVibrate(enable: Boolean): InternalSettingCommand =
            InternalSettingCommand.Valid.Firmware(FwIds.VIBRATE, enable.toBoolInternal<FwSetting.VibrateSetting>())

        fun setLedEnable(enable: Boolean): InternalSettingCommand =
            InternalSettingCommand.Valid.Firmware(FwIds.LED, enable.toBoolInternal<FwSetting.LedSetting>())

        fun setButtonEnable(enable: Boolean): InternalSettingCommand =
            InternalSettingCommand.Valid.Firmware(FwIds.BUTTON, enable.toBoolInternal<FwSetting.ButtonSetting>())

        /** Not stored in firmware; set again after reconnect if needed */
        fun setWithCodeType(enable: Boolean): InternalSettingCommand =
            InternalSettingCommand.Valid.Firmware(FwIds.SET_WITH_CODE_TYPE, enable.toBoolInternal<FwSetting.SetWithCodeType>())
    }

    object ReaderParams {
        fun readMode(value: ReaderType.ReadModeType): InternalSettingCommand =
            InternalSettingCommand.Valid.Firmware(FwIds.READ_MODE, value.toEnumInternal<FwSetting.ReadMode>())

        /** value in deciseconds (seconds × 10) */
        fun laserOnTime(value: Int): InternalSettingCommand =
            InternalSettingCommand.Valid.Scanner(ReaderIds.LASER_ON_TIME, IntValue(value))

        fun inverse1D(value: ReaderType.Inverse1DType): InternalSettingCommand =
            InternalSettingCommand.Valid.Scanner(
                ReaderIds.INVERSE_1D,
                value.toEnumInternal<ReaderSetting.Inverse1DVal>()
            )

        fun quietZoneLevelFor1D(value: ReaderType.QuietZoneLevelType): InternalSettingCommand =
            InternalSettingCommand.Valid.Scanner(
                ReaderIds.QUIET_ZONE_LEVEL_FOR_1D,
                value.toEnumInternal<ReaderSetting.QuietZoneLevelFor1DVal>()
            )

        fun poorQualityDecodeEffort(value: ReaderType.PoorQualityDecodeEffortType): InternalSettingCommand =
            InternalSettingCommand.Valid.Scanner(
                ReaderIds.POOR_QUALITY_DECODE_EFFORT,
                value.toEnumInternal<ReaderSetting.PoorQualityDecodeEffortVal>()
            )
    }

    object BasicDataFormat {
        fun transmitCodeID(value: BasicFormatType.TransmitCodeIdType): InternalSettingCommand =
            InternalSettingCommand.Valid.Scanner(
                BasicFormatIds.TRANSMIT_CODE_ID,
                value.toEnumInternal<BasicFormatSetting.TransmitCodeIdVal>()
            )

        fun endChar(value: BasicFormatType.EndCharType): InternalSettingCommand =
            InternalSettingCommand.Valid.Firmware(FwIds.END_CHAR, value.toEnumInternal<FwSetting.EndCharSetting>())

        fun subString(rawValue: String): InternalSettingCommand {
            // 빈 값(또는 공백만 있는 값)이면 기본값 "0,0" 사용
            val value = rawValue.ifBlank { "0,0" }

            if (!M3Utils.isDecimalPair(value)) {
                return InternalSettingCommand.Error("Substring value is not a valid decimal string.")
            }

            val byteArray = PacketUtils.decimalStringToByteArray(value)

            return InternalSettingCommand.Valid.Firmware(FwIds.SUBSTRING, ByteArrayValue(byteArray))
        }

        fun setRemoveFnc(enable: Boolean): InternalSettingCommand =
            InternalSettingCommand.Valid.Firmware(FwIds.REMOVE_FNC, enable.toBoolInternal<FwSetting.RemoveFnc>())

        fun setTranslateData(value: String): InternalSettingCommand {
            // value must match "AA,BB;CC,DD;..." up to 8 pairs
            if (!M3Utils.isHexPairsSequenceAndMaxLength8(value)) {
                return InternalSettingCommand.Error("Translate data length exceeds 8 bytes or invalid format.")
            }

            val byteArray =
                if (value.isEmpty()) byteArrayOf() else PacketUtils.hexPairsListToByteArray(value)

            return InternalSettingCommand.Valid.Firmware(FwIds.TRANSLATE_DATA, ByteArrayValue(byteArray))
        }

        fun setPrefixPostfixAsAsciiHex(enable: Boolean): InternalSettingCommand =
            InternalSettingCommand.Valid.Firmware(FwIds.PRE_POST_HEX, enable.toBoolInternal<FwSetting.PrePostHex>())

        /** Maximum length of prefix is 16 bytes. */
        fun setPrefix(value: String): InternalSettingCommand {
            val length = value.toByteArray(Charsets.UTF_8).size
            return if (length > Const.PREFIX_MAX_LENGTH)
                InternalSettingCommand.Error("Prefix length is $length bytes. Maximum length is 16 bytes.")
            else
                InternalSettingCommand.Valid.Firmware(
                    FwIds.PREFIX,
                    ByteArrayValue(value.toByteArray(Charsets.UTF_8))
                )
        }

        /** Maximum length of postfix is 16 bytes. */
        fun setPostfix(value: String): InternalSettingCommand {
            val length = value.toByteArray(Charsets.UTF_8).size
            return if (length > Const.POSTFIX_MAX_LENGTH)
                InternalSettingCommand.Error("Postfix length is $length bytes. Maximum length is 16 bytes.")
            else
                InternalSettingCommand.Valid.Firmware(
                    FwIds.POSTFIX,
                    ByteArrayValue(value.toByteArray(Charsets.UTF_8))
                )
        }
    }

    object Dev {
        fun setBatteryCallback(enable: Boolean): InternalSettingCommand =
            InternalSettingCommand.Valid.Firmware(FwIds.BATTERY_CALLBACK, enable.toBoolInternal<FwSetting.BatteryCallback>())
    }
}
