package com.m3.ring.scanemul.sdk.api.model.symbologies.dotcode

data class DotCodeVals(
    val enabled: Boolean? = null,
    val inverse: DotCodeType.InverseType? = null,
    val mirror: DotCodeType.MirrorType? = null,
    val prioritize: Boolean? = null
)