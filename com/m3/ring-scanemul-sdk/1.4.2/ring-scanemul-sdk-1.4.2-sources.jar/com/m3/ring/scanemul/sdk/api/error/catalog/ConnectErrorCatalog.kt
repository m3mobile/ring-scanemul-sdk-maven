package com.m3.ring.scanemul.sdk.api.error.catalog

enum class ConnectErrorCatalog(val code: Int, val msg: String) {
    ALREADY_CONNECTING(2001, "Already connecting to a device."),
    CONNECTION_FAILED(2004, "Connection failed."),
    DEVICE_SETTINGS_LOAD_FAILED(2005, "Failed to load Device Settings"),
    UNKNOWN(2100, "Unknown connection error"),
}
