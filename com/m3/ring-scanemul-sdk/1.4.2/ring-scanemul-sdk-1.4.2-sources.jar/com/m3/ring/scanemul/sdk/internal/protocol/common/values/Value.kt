package com.m3.ring.scanemul.sdk.internal.protocol.common.values

interface Value