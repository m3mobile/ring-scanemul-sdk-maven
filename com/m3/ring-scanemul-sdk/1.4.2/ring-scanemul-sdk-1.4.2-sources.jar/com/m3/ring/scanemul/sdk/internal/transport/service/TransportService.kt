package com.m3.ring.scanemul.sdk.internal.transport.service

import android.Manifest
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.core.ConnectionType
import com.m3.ring.scanemul.sdk.api.core.TransportSession
import com.m3.ring.scanemul.sdk.api.error.catalog.ConnectErrorCatalog
import com.m3.ring.scanemul.sdk.api.listener.DiscoveryScanResultListener
import com.m3.ring.scanemul.sdk.internal.common.storage.PrefManager
import com.m3.ring.scanemul.sdk.internal.connection.domain.ConnectionRepo
import com.m3.ring.scanemul.sdk.internal.device.state.DeviceStateStore
import com.m3.ring.scanemul.sdk.internal.scan.data.ble.BLEScanManager
import com.m3.ring.scanemul.sdk.internal.scan.data.ble.BLEScanRepo
import com.m3.ring.scanemul.sdk.internal.scan.data.spp.SPPScanManager
import com.m3.ring.scanemul.sdk.internal.scan.data.spp.SPPScanRepo
import java.util.concurrent.atomic.AtomicBoolean


internal class TransportService : Service(), TransportClient {
    private lateinit var deviceStateStore: DeviceStateStore

    private val prefs by lazy {
        PrefManager(applicationContext.getSharedPreferences(PrefManager.PREF_NAME, MODE_PRIVATE))
    }

    private lateinit var connectionRepo: ConnectionRepo
    private val bleScanRepo by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        BLEScanRepo(BLEScanManager(applicationContext, prefs))
    }

    private val sppScanRepo by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        SPPScanRepo(SPPScanManager(applicationContext))
    }

    // 연결 시도 상태 플래그
    private var isConnecting = AtomicBoolean(false)

    inner class LocalBinder : Binder() {
        fun setDependencies(repo: ConnectionRepo, stateStore: DeviceStateStore) {
            connectionRepo = repo
            deviceStateStore = stateStore
        }

        fun client(): TransportClient = this@TransportService
    }

    private val binder = LocalBinder()

    override fun onBind(p0: Intent?): IBinder = binder

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    override fun onUnbind(intent: Intent?): Boolean {
        runCatching { stopS2PScan() }
        runCatching { stopDiscoveryScan() }
        isConnecting.set(false)
        return true
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    override fun connectToDevice(
        connectionType: ConnectionType,
        device: BluetoothDevice,
        onSuccess: (TransportSession) -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        // 중복 연결 방지
        if (!isConnecting.compareAndSet(false, true)) {
            val catalog = ConnectErrorCatalog.ALREADY_CONNECTING
            onFailure(catalog.code, catalog.msg)
            return
        }

        if (!::connectionRepo.isInitialized || !::deviceStateStore.isInitialized) {
            isConnecting.set(false)
            val catalog = ConnectErrorCatalog.CONNECTION_FAILED
            onFailure(catalog.code, "Connection dependencies are not initialized")
            return
        }

        val repo = connectionRepo

        repo.connectAndFetchAllSettings(
            device,
            onSuccess = { session ->
                isConnecting.set(false)
                onSuccess(session)
            },
            onFailure = { errorCode, errorMsg ->
                isConnecting.set(false)
                onFailure(errorCode, errorMsg)
            }
        )
    }

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    override fun startS2PScan(onDeviceFound: (BluetoothDevice) -> Unit, onScanFailed: (errorCode: Int, errorMsg: String) -> Unit) {
        bleScanRepo.scanS2PDevice(onDeviceFound, onScanFailed)
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    override fun stopS2PScan() {
        bleScanRepo.stopScan()
    }

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    override fun startDiscoveryScan(listener: DiscoveryScanResultListener) {
        sppScanRepo.startDiscoveryScan(listener)
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    override fun stopDiscoveryScan() {
        sppScanRepo.stopDiscoveryScan()
    }
}
