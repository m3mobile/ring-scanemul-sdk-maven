package com.m3.ring.scanemul.sdk.api.model.symbologies.pdf417

data class Pdf417Vals(
    val enabled: Boolean? = null
)