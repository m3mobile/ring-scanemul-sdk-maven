package com.m3.ring.scanemul.sdk.internal.transport.domain

import kotlinx.coroutines.Deferred
import kotlinx.coroutines.flow.SharedFlow

/**
 * 데이터 전송 및 수신을 관리하는 공통 Transport 인터페이스.
 * 각 구현체(SPP, BLE)는 이 인터페이스를 기반으로 동작합니다.
 */
interface TransportManager {
    /**
     * 소켓의 InputStream을 읽기 시작하여 수신 루프를 활성화합니다.
     * 연결이 유지되는 동안 내부적으로 지속적으로 데이터를 읽습니다.
     */
    fun startRead()

    /**
     * 펌웨어 및 설정 관련 바이너리 명령어를 관찰합니다.
     * @return 설정 관련 응답 데이터 스트림
     */
    fun observeBinaryCommandData(): SharedFlow<ByteArray>

    /**
     * 바코드 스캐너에서 수신된 바코드 데이터를 관찰합니다.
     * @return 바코드 데이터 스트림
     */
    fun observeBarcodeData(): SharedFlow<ByteArray>

    /**
     * Write Queue에 적재된 명령어를 순차적으로 전송하는 워커를 시작합니다.
     * (별도의 코루틴으로 동작)
     */
    fun startWriteWorker()

    /**
     * Write 명령어를 전송합니다.
     */
    fun requestWrite(data: ByteArray)

    /**
     * Ack(응답)을 기대하는 Write 명령어를 전송합니다.
     *
     * @param data 전송할 명령어 데이터
     * @return Ack 수신 성공 여부를 반환하는 [Deferred]
     */
    suspend fun requestWriteWithAck(data: ByteArray): Deferred<Boolean>

    /**
     * 스캐너의 모든 설정값을 요청합니다.
     *
     * @param byteList 설정 ID 목록 (분할 전송 가능)
     */
    suspend fun requestGetScannerAllSettings(byteList: List<ByteArray>, onResult: (Boolean) -> Unit)

    /**
     * 블루투스 디바이스와의 연결을 종료합니다.
     *
     * @param onSuccess 연결 종료 성공 여부 콜백
     */
    fun disconnect(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit)

    /**
     * 연결이 끊어진 이벤트를 관찰합니다.
     * @return 연결 해제 이벤트 스트림
     */
    fun observeDisconnect(): SharedFlow<Unit>
}