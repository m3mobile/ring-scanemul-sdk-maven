package com.m3.ring.scanemul.sdk.internal.scan.data.ble

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.ScanCallback
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.error.catalog.BLEScanErrorCatalog
import com.m3.ring.scanemul.sdk.internal.common.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean


internal class BLEScanRepo(private val bleScanManager: BLEScanManager) {
    private val workScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val callbackScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private var scanJob: Job? = null
    private val isScanning = AtomicBoolean(false)

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun scanS2PDevice(
        onDeviceFound: (BluetoothDevice) -> Unit,
        onScanFailed: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        // 중복 시작 방지
        if (!isScanning.compareAndSet(false, true)) {
            val catalog = BLEScanErrorCatalog.fromErrorCode(ScanCallback.SCAN_FAILED_ALREADY_STARTED)
            callbackScope.launch {
                runCatching { onScanFailed(catalog.code, catalog.msg) }
                    .onFailure { Logger.e(msg = "=========== Listener error in onScanFailed: ${it.message} ===========") }
            }
            return
        }

        // 이전 job 정리
        scanJob?.cancel()

        scanJob = workScope.launch {
            try {
                bleScanManager.scanS2PDevice(
                    onDeviceFound = { bluetoothDevice ->
                        bleScanManager.stopScan() // 디바이스 발견 후 스캔 중지
                        isScanning.set(false)
                        callbackScope.launch {
                            runCatching { onDeviceFound(bluetoothDevice) }
                                .onFailure { Logger.e(msg = "=========== Listener error in onDeviceFound: ${it.message} ===========") }
                        }
                    },
                    onScanFailed = { errorCode, errorMsg ->
                        bleScanManager.stopScan()
                        isScanning.set(false)
                        callbackScope.launch {
                            runCatching { onScanFailed(errorCode, errorMsg) }
                                .onFailure { Logger.e(msg = "=========== Listener error in onScanFailed: ${it.message} ===========") }
                        }
                    }
                )
            } catch (t: Throwable) {
                bleScanManager.stopScan()
                isScanning.set(false)
                val catalog = BLEScanErrorCatalog.SCAN_FAILED_INTERNAL_ERROR
                callbackScope.launch {
                    runCatching { onScanFailed(catalog.code, catalog.msg) }
                        .onFailure { Logger.e(msg = "=========== Listener error in onScanFailed: ${it.message} ===========") }
                }
            }
        }.also { job ->
            job.invokeOnCompletion {
                if (scanJob === job) scanJob = null
            }
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun stopScan() {
        if (!isScanning.compareAndSet(true, false)) return
        bleScanManager.stopScan()

        val job = scanJob
        scanJob = null
        job?.cancel()
    }
}
