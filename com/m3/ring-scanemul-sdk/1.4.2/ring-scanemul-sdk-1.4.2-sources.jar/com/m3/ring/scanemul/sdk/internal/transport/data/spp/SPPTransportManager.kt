package com.m3.ring.scanemul.sdk.internal.transport.data.spp

import android.bluetooth.BluetoothSocket
import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.common.util.CmdUtils
import com.m3.ring.scanemul.sdk.internal.common.util.Extensions.toHexString
import com.m3.ring.scanemul.sdk.internal.transport.data.core.dto.WriteRequest
import com.m3.ring.scanemul.sdk.internal.transport.domain.TransportManager
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import java.io.IOException

/**
 * SPPTransportManager는 SPP 프로토콜을 사용하여
 * BluetoothSocket을 통해 데이터를 전송하고 수신하는 기능을 제공합니다.
 *
 * @param socket 통신을 위해 연결 이후 생성된 소켓
 * @param scope 코루틴 스코프
 */
class SPPTransportManager(private val socket: BluetoothSocket, private val scope: CoroutineScope) : TransportManager {
    private val inputStream = socket.inputStream
    private val outputStream = socket.outputStream

    private val writeAckWaiters = ArrayDeque<CompletableDeferred<Boolean>>() // ACK/NACK 패킷을 기다리는 CompletableDeferred 객체들

    private val binaryCommandData = MutableSharedFlow<ByteArray>(
        extraBufferCapacity = 64
    )

    private val barcodeData = MutableSharedFlow<ByteArray>(
        extraBufferCapacity = 64
    )

    private val disconnectEvent = MutableSharedFlow<Unit>(
        replay = 0,
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    private val writeSetterQueue = Channel<WriteRequest>(Channel.UNLIMITED)
    private val ackMutex = Mutex()

    init {
        startRead()
        startWriteWorker()
    }

    /**
     * 이 메서드는 소켓의 InputStream을 읽기 시작하여 수신 루프를 활성화합니다.
     * 연결이 유지되는 동안 내부적으로 지속적으로 데이터를 읽습니다.
     * 이 메서드는 별도의 코루틴으로 동작하며, 수신된 데이터는
     * [binaryCommandData] 또는 [barcodeData] SharedFlow로 방출됩니다.
     * 만약 연결이 끊어지거나 읽기 중 오류가 발생하면
     * [disconnectEvent] SharedFlow로 이벤트를 방출합니다.
     */
    override fun startRead() {
        scope.launch {
            val buffer = ByteArray(1024)

            while (isActive) {
                try {
                    val bytesRead = inputStream.read(buffer)
                    if (bytesRead == -1) {
                        closeWriteSetterQueue()
                        disconnectEvent.tryEmit(Unit)
                        return@launch
                    }

                    if (bytesRead > 0) {
                        val value = buffer.copyOfRange(0, bytesRead)
                        Logger.i(msg = "=========== Received: ${value.toHexString()} ===========")

                        handleReceivedData(value)
                    }
                } catch (e: IOException) {
                    Logger.e(msg = "=========== Read failed: ${e.message} ===========")
                    closeWriteSetterQueue()
                    disconnectEvent.tryEmit(Unit)
                    break
                }
            }
        }
    }

    override fun observeBinaryCommandData(): SharedFlow<ByteArray> {
        return binaryCommandData
    }

    override fun observeBarcodeData(): SharedFlow<ByteArray> {
        return barcodeData
    }

    /**
     * Write Queue에 적재된 명령어를 순차적으로 전송하는 워커를 시작합니다.
     * 이 메서드는 별도의 코루틴으로 동작하며, 요청된 명령어를 순차적으로 전송합니다.
     * ACK/NACK 응답을 기다리는 경우, 해당 요청에 대한 CompletableDeferred 객체를 사용하여 응답을 처리합니다.
     */
    override fun startWriteWorker() {
        scope.launch {
            for (req in writeSetterQueue) {

                req.deferred?.let {
                    ackMutex.withLock { writeAckWaiters.addLast(it) }
                }

                try {
                    outputStream.write(req.data)
                    outputStream.flush()
                    Logger.i(msg = "=========== Write: ${req.data.toHexString()} ===========")

                    req.deferred?.let {
                        withTimeout(5_000) { //요청이 5초 이내에 완료되지 않으면 타임아웃
                            it.await()
                        }
                    }
                } catch (e: Exception) {
                    Logger.e(msg = "=========== Write failed: ${e.message} ===========")
                    req.deferred?.let {
                        ackMutex.withLock { writeAckWaiters.remove(it) }
                        it.complete(false)
                    }
                }
            }
        }
    }

    /**
     * 데이터를 전송하기 위해 Write Queue에 요청을 추가합니다.
     * 이 메서드는 ACK/NACK 응답을 기다리지 않습니다.
     */
    override fun requestWrite(data: ByteArray) {
        writeSetterQueue.trySend(WriteRequest(data))
    }

    /**
     * ACK/NACK 패킷을 기다리는 CompletableDeferred 객체를 추가하고, 데이터를 전송합니다.
     * 이 메서드는 ACK/NACK 응답을 기다리는 비동기 작업을 반환합니다.
     */
    override suspend fun requestWriteWithAck(data: ByteArray): Deferred<Boolean> {
        val deferred = CompletableDeferred<Boolean>()
        writeSetterQueue.trySend(WriteRequest(data, deferred))
        return deferred
    }


    /**
     * 모든 스캐너 타입의(펌웨어 설정X) 설정을 요청합니다.
     * 명령어 바이트가 크고 펌웨어 내부에서 연산 시간이 필요하기 때문에 2초 딜레이를 기준으로 바이트를 나누어서 전송합니다.
     */
    override suspend fun requestGetScannerAllSettings(byteList: List<ByteArray>, onResult: (Boolean) -> Unit) {
        byteList.forEach { data ->
            Logger.i(msg = "=========== Write: ${data.toHexString()} ===========")
            outputStream.write(data)
            outputStream.flush()
            delay(2_000)
        }

        onResult(true)
    }

    override fun disconnect(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit) {
        try {
            closeWriteSetterQueue()
            closeSocket()
            onSuccess() // 연결 해제 성공 콜백 호출
            Logger.i(msg = "=========== Disconnect Success ===========")
        } catch (e: Exception) {
            onFailure("Disconnect failed: ${e.message}")
            Logger.e(msg = "=========== Disconnect Failed ===========")
        }
    }


    private fun closeWriteSetterQueue() {
        writeSetterQueue.close()

        // ACK 대기자 전부 false로 종료
        scope.launch {
            val toFail: List<CompletableDeferred<Boolean>> = ackMutex.withLock {
                val copy = writeAckWaiters.toList()
                writeAckWaiters.clear()
                copy
            }
            toFail.forEach { it.complete(false) }
        }
    }

    private fun closeSocket() {
        outputStream?.close()
        inputStream?.close()
        socket.close()
    }

    /**
     * 이 메서드는 연결이 끊어졌을 때 호출되는 SharedFlow를 반환합니다.
     * @return 연결 해제 이벤트 스트림
     */
    override fun observeDisconnect(): SharedFlow<Unit> {
        return disconnectEvent
    }

    /**
     * 수신된 데이터를 처리합니다.
     * 이 메서드는 수신된 데이터가 바코드 데이터인지, 바이너리 명령어인지 판별하고
     * 각각의 SharedFlow로 방출합니다.
     * 또한, ACK/NACK 패킷인 경우에는 해당 패킷을 처리하는 메서드를 호출합니다.
     */
    private suspend fun handleReceivedData(value: ByteArray) {
        if (!CmdUtils.isBinaryCommand(value)) {
            barcodeData.emit(value)
            return
        }

        if (!CmdUtils.isChecksumValid(value)) return

        if (CmdUtils.isAckPacket(value)) {
            handleAckNakPacket(value)
        } else {
            binaryCommandData.emit(value)
        }
    }

    /**
     * ACK/NACK 패킷을 처리합니다.
     * ACK/NACK 패킷은 3번째 바이트가 0xD0인 경우로 정의됩니다.
     *
     * 이 메서드는 writeAckWaiters 큐에서 가장 먼저 추가된 CompletableDeferred 객체를 찾아
     * 해당 객체를 완료시키거나 실패시킵니다.
     * 응답 패킷의 4번째 바이트가 0x01이면 성공, 0x00이면 실패로 간주합니다.
     *
     * ex) f1(header) 05(length) d0(accessor type) 04(command source) 01(00:fail; 01:success) fe(checksum_1) 34(checksum_2)
     */
    private fun handleAckNakPacket(packet: ByteArray) {
        if (writeAckWaiters.isNotEmpty()) {
            val waiter = writeAckWaiters.removeFirstOrNull()
            waiter?.complete(packet[4] == 0x01.toByte())
        }
    }
}