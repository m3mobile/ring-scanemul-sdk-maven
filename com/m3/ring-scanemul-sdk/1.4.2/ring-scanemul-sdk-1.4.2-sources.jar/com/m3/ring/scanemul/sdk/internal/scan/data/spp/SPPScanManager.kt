package com.m3.ring.scanemul.sdk.internal.scan.data.spp

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.error.catalog.DiscoveryScanErrorCatalog
import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.scan.data.spp.dto.DiscoveryDeviceDto

internal class SPPScanManager(context: Context) {
    private val appContext = context.applicationContext
    private val adapter: BluetoothAdapter by lazy {
        (appContext.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    }

    private var receiver: BroadcastReceiver? = null

    private fun mainHandler() = Handler(Looper.getMainLooper()) // 디스커버리 용 메인 스레드 핸들러

    /**
     * Classic(BR/EDR) 디스커버리 한 라운드(12s)만 수행하고 끝나는 Flow.
     * collect가 시작되면 등록/시작, collect가 끝나거나 Finished가 오면 정리됨.
     */
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun startDiscoveryScan(
        onStarted: () -> Unit,
        onDeviceFound: (DiscoveryDeviceDto) -> Unit,
        onFinished: () -> Unit,
        onError: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        val filter = IntentFilter().apply {
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_FOUND)
        }

        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                when (intent?.action) {
                    BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                        onStarted()
                    }

                    BluetoothDevice.ACTION_FOUND -> {
                        val device: BluetoothDevice? =
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                intent.getParcelableExtra(
                                    BluetoothDevice.EXTRA_DEVICE,
                                    BluetoothDevice::class.java
                                )
                            } else {
                                @Suppress("DEPRECATION")
                                intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                            }
                        val rssiShort = intent.getShortExtra(
                            BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE
                        )
                        val rssi: Int? = if (rssiShort != Short.MIN_VALUE) rssiShort.toInt() else null

                        device?.let {
                            onDeviceFound(DiscoveryDeviceDto(btDevice = device, rssi = rssi))
                        }
                    }

                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                        safeUnregister()
                        onFinished()
                    }
                }
            }
        }

        receiver = r

        // 리시버 등록
        appContext.registerReceiver(
            r,
            filter,
            null,
            mainHandler()
        )

        // discovery 시작
        val ok = adapter.startDiscovery()
        if (!ok) {
            Logger.e(msg = "=========== startDiscovery() failed ===========")
            safeUnregister()
            val catalog = DiscoveryScanErrorCatalog.START_FAILED
            onError(catalog.code, catalog.msg)
        }
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun stopDiscoveryScan() {
        if (adapter.isDiscovering) {
            Logger.i(msg = "=========== SPP Discovery Scan Stopped ===========")
            adapter.cancelDiscovery()
            safeUnregister()
        }
    }

    private fun safeUnregister() {
        val r = receiver ?: return
        receiver = null
        runCatching { appContext.unregisterReceiver(r) }
            .onFailure {
                Logger.e(msg = "=========== Unregister receiver failure: ${it.message} ===========")
            }
    }
}
