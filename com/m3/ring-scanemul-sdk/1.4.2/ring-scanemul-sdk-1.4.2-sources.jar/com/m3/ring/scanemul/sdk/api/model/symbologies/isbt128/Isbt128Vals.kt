package com.m3.ring.scanemul.sdk.api.model.symbologies.isbt128

data class Isbt128Vals(
    val enabled: Boolean? = null
)