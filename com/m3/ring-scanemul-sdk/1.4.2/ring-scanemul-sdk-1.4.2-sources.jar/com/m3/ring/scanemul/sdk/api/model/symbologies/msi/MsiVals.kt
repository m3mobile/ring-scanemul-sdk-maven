package com.m3.ring.scanemul.sdk.api.model.symbologies.msi

data class MsiVals(
    val enabled: Boolean? = null,
    val length1: Int? = null,
    val length2: Int? = null,
    val checkDigit: MsiType.CheckDigitType? = null,
    val checkDigitScheme: MsiType.CheckDigitSchemeType? = null,
    val reportCheckDigit: Boolean? = null
)