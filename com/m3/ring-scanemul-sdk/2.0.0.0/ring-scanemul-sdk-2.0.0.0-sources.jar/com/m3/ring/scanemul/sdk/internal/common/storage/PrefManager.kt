package com.m3.ring.scanemul.sdk.internal.common.storage

import android.content.SharedPreferences

internal class PrefManager(private val sp: SharedPreferences) {
    companion object {
        const val PREF_NAME = "m3_prefs"
        const val UNIQUE_KEY = "m3_s2p_key"
        const val LAST_CONNECTED_MAC_ADDRESS = "m3_last_connected_mac_address"
    }

    private val editor: SharedPreferences.Editor = sp.edit()

    fun saveString(key: String, value: String) {
        editor.putString(key, value).apply()
    }

    fun getString(key: String, defaultValue: String = ""): String {
        return sp.getString(key, defaultValue) ?: defaultValue
    }
}
