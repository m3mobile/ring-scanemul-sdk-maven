package com.m3.ring.scanemul.sdk.internal.connection.data

/**
 * fetchAllSettings 성공 여부를 추적하는 상태 holder
 */
internal class SettingsLoadStateHolder {
    // fetchAllSettings이 성공적으로 완료되었는지 여부를 나타내는 플래그
    var isSettingsLoaded: Boolean = false
        private set

    fun markLoaded() {
        isSettingsLoaded = true
    }

    fun reset() {
        isSettingsLoaded = false
    }
}
