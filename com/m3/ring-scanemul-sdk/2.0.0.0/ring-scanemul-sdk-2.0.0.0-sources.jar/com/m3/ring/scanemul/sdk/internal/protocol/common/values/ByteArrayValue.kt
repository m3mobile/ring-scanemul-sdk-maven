package com.m3.ring.scanemul.sdk.internal.protocol.common.values

import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwValue

internal data class ByteArrayValue(override val value: ByteArray) : FwValue
