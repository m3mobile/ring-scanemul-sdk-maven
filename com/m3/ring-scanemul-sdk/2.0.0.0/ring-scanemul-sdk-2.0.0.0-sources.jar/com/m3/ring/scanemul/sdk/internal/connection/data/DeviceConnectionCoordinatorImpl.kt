package com.m3.ring.scanemul.sdk.internal.connection.data

import android.Manifest
import android.bluetooth.BluetoothDevice
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.core.ConnectionType
import com.m3.ring.scanemul.sdk.api.core.TransportSession
import com.m3.ring.scanemul.sdk.api.error.catalog.ConnectErrorCatalog
import com.m3.ring.scanemul.sdk.api.listener.DisconnectListener
import com.m3.ring.scanemul.sdk.api.model.FetchAllSettingsResult
import com.m3.ring.scanemul.sdk.api.model.FetchAllSettingsStatus
import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.common.storage.PrefManager
import com.m3.ring.scanemul.sdk.internal.common.util.SdkVersionProvider
import com.m3.ring.scanemul.sdk.internal.connection.data.ble.dto.BLEConnectionResult
import com.m3.ring.scanemul.sdk.internal.connection.data.spp.dto.SPPConnectionResult
import com.m3.ring.scanemul.sdk.internal.connection.domain.ConnectionManager
import com.m3.ring.scanemul.sdk.internal.connection.domain.DeviceConnectionCoordinator
import com.m3.ring.scanemul.sdk.internal.connection.domain.VersionCompatibilityChecker
import com.m3.ring.scanemul.sdk.internal.device.state.DeviceStateStore
import com.m3.ring.scanemul.sdk.internal.device.state.FwSettingInfo
import com.m3.ring.scanemul.sdk.internal.transport.data.core.DeviceProtocolChannel
import com.m3.ring.scanemul.sdk.internal.transport.data.core.TransportProtocolMismatchException
import com.m3.ring.scanemul.sdk.internal.transport.data.core.DeviceProtocolChannelFactory
import com.m3.ring.scanemul.sdk.internal.transport.data.core.TransportSessionImpl
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

internal class DeviceConnectionCoordinatorImpl(
    private val connectionType: ConnectionType,
    private val connectionManager: ConnectionManager,
    private val deviceStateStore: DeviceStateStore,
    private val prefManager: PrefManager
) : DeviceConnectionCoordinator {
    private lateinit var workScope: CoroutineScope
    private lateinit var callbackScope: CoroutineScope
    private var session: TransportSession? = null
    private var protocolChannel: DeviceProtocolChannel? = null
    private var connectedDevice: BluetoothDevice? = null
    private val isConnecting = AtomicBoolean(false)
    private val settingsLoadStateHolder = SettingsLoadStateHolder()

    /**
     * 디바이스와 transport session 연결을 요청합니다.
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    override fun connect(
        device: BluetoothDevice,
        onSuccess: (session: TransportSession) -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        // 연결 요청 마다 새로운 코루틴 스코프 생성
        workScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        callbackScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

        if (!isConnecting.compareAndSet(false, true)) {
            callbackScope.launch {
                val catalog = ConnectErrorCatalog.ALREADY_CONNECTING
                runCatching { onFailure(catalog.code, catalog.msg) }
                    .onFailure { Logger.e(msg = "=========== Listener error in onFailure: ${it.message} ===========") }
            }
            return
        }

        establishTransportConnection(
            device = device,
            onSuccess = { protocolChannel ->
                settingsLoadStateHolder.reset()
                deviceStateStore.updateDeviceInfo(
                    deviceStateStore.getDeviceInfo().copy(
                        name = device.name,
                        macAddress = device.address
                    )
                )
                prefManager.saveString(PrefManager.LAST_CONNECTED_MAC_ADDRESS, device.address)
                val s = TransportSessionImpl(protocolChannel, deviceStateStore)
                session = s
                this.protocolChannel = protocolChannel
                connectedDevice = device

                callbackScope.launch {
                    isConnecting.set(false)
                    runCatching { onSuccess(s) }
                        .onFailure { Logger.e(msg = "=========== Listener error in onSuccess: ${it.message} ===========") }
                }
            },

            onFailure = { errorCode, errorMsg ->
                callbackScope.launch {
                    isConnecting.set(false)
                    runCatching {
                        onFailure(errorCode, errorMsg)
                    }.onFailure { Logger.e(msg = "=========== Listener error in onFailure ===========") }

                    scopeCancel()
                }
            }
        )
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    override fun fetchAllSettings(onResult: (FetchAllSettingsResult) -> Unit) {
        val channel = protocolChannel

        if (!::workScope.isInitialized || !::callbackScope.isInitialized || channel == null || session == null) {
            onResult(
                FetchAllSettingsResult(
                    status = FetchAllSettingsStatus.FAILED,
                    errorCode = ConnectErrorCatalog.CONNECTION_FAILED.code,
                    errorMsg = "Transport session is not initialized"
                )
            )
            return
        }

        workScope.launch {
            settingsLoadStateHolder.reset()
            val result = loadAllDeviceSettings(channel)

            if (result.status == FetchAllSettingsStatus.FAILED) {
                withContext(NonCancellable) { //channel.disconnect자체가 workScope를 취소하기 때문에 NonCancellable로 해당 코루틴 작업은 workScope가 종료되도 모든 작업을 완료하도록 구현. 추후에는 scope자체를 분리하는 방향으로 리팩토링 필요.
                    channel.disconnect(
                        onSuccess = {},
                        onFailure = { msg ->
                            Logger.e(msg = "=========== Failed settings connection cleanup: $msg ===========")
                        }
                    )
                    withContext(Dispatchers.Main.immediate) {
                        runCatching { onResult(result) }
                            .onFailure { Logger.e(msg = "=========== Listener error in fetchAllSettings result: ${it.message} ===========") }
                    }
                }
                return@launch
            }

            callbackScope.launch {
                if (result.status == FetchAllSettingsStatus.SUCCESS ||
                    result.status == FetchAllSettingsStatus.APP_UPDATE_RECOMMENDED ||
                    result.status == FetchAllSettingsStatus.FW_UPDATE_RECOMMENDED
                ) {
                    settingsLoadStateHolder.markLoaded()
                } else {
                    settingsLoadStateHolder.reset()
                }

                runCatching { onResult(result) }
                    .onFailure { Logger.e(msg = "=========== Listener error in fetchAllSettings result: ${it.message} ===========") }
            }
        }
    }

    /**
     * 디바이스와 연결을 요청합니다.
     *
     * @param device 연결 요청할 디바이스
     * @param onSuccess 연결 성공 시 호출되는 콜백
     * @param onFailure 연결 실패 시 호출되는 콜백
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private fun establishTransportConnection(
        device: BluetoothDevice,
        onSuccess: (channel: DeviceProtocolChannel) -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        var protocolChannel: DeviceProtocolChannel

        workScope.launch {
            val result = connectionManager.connect(device)

            if (result.isSuccess) {
                protocolChannel = when (connectionType) {
                    ConnectionType.SPP -> {
                        val socket = requireNotNull((result as? SPPConnectionResult)?.socket) {
                            "Expected SPP socket when connectionType=SPP"
                        }
                        DeviceProtocolChannelFactory.create(
                            socket = socket,
                            scope = workScope,
                            deviceStateStore = deviceStateStore,
                            settingsLoadStateHolder = settingsLoadStateHolder
                        )
                    }

                    ConnectionType.BLE -> {
                        val gatt = requireNotNull((result as? BLEConnectionResult)?.gatt) {
                            "Expected BLE gatt when connectionType=BLE"
                        }

                        DeviceProtocolChannelFactory.create(
                            gatt = gatt,
                            scope = workScope,
                            deviceStateStore = deviceStateStore,
                            settingsLoadStateHolder = settingsLoadStateHolder
                        )
                    }
                }

                protocolChannel.addDisconnectListener(object : DisconnectListener {
                    override fun onDisconnect() {
                        // 연결 해제 시 모든 코루틴 작업 종료
                        scopeCancel()
                        session = null
                        this@DeviceConnectionCoordinatorImpl.protocolChannel = null
                        connectedDevice = null
                        settingsLoadStateHolder.reset()
                    }
                })

                runCatching { onSuccess(protocolChannel) }
                    .onFailure { Logger.e(msg = "=========== Listener error in onSuccess: ${it.message} ===========") }

            } else {
                val catalog = ConnectErrorCatalog.CONNECTION_FAILED
                val errorMsg = result.errorMsg ?: catalog.msg
                runCatching { onFailure(catalog.code, errorMsg) }
                    .onFailure { Logger.e(msg = "=========== Listener error in onFailure: ${it.message} ===========") }
            }
        }
    }

    /**
     * 연결된 디바이스의 펌웨어/스캐너 전체 설정을 로드합니다.
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    private suspend fun loadAllDeviceSettings(channel: DeviceProtocolChannel): FetchAllSettingsResult {
        return try {
            val firmwareSuccess = channel.requestGetFirmwareAllSettings()
            if (!firmwareSuccess) {
                return FetchAllSettingsResult(
                    status = FetchAllSettingsStatus.FAILED,
                    errorCode = ConnectErrorCatalog.DEVICE_SETTINGS_LOAD_FAILED.code,
                    errorMsg = ConnectErrorCatalog.DEVICE_SETTINGS_LOAD_FAILED.msg
                )
            }

            val fwSettingInfo = deviceStateStore.getDeviceInfo().fwSettingInfo
            val compatibilityStatus = VersionCompatibilityChecker.check(
                sdkVersion = SdkVersionProvider.compatibilityVersion,
                fwVersion = fwSettingInfo.fwVersion
            )
            Logger.i(
                msg = "=========== SDK/FW compatibility result: $compatibilityStatus " +
                        "(sdk=${SdkVersionProvider.compatibilityVersion}, fw=${fwSettingInfo.fwVersion}) ==========="
            )

            when (compatibilityStatus) {
                FetchAllSettingsStatus.APP_SHOULD_UPDATE,
                FetchAllSettingsStatus.FW_SHOULD_UPDATE -> {
                    return FetchAllSettingsResult(
                        status = compatibilityStatus,
                        errorCode = ConnectErrorCatalog.SDK_FW_VERSION_MISMATCH.code,
                        errorMsg = ConnectErrorCatalog.SDK_FW_VERSION_MISMATCH.msg
                    )
                }

                FetchAllSettingsStatus.REQUIRED_DEVICE_INFO_MISSING -> {
                    return FetchAllSettingsResult(
                        status = compatibilityStatus,
                        errorCode = ConnectErrorCatalog.REQUIRED_DEVICE_INFO_MISSING.code,
                        errorMsg = ConnectErrorCatalog.REQUIRED_DEVICE_INFO_MISSING.msg
                    )
                }

                FetchAllSettingsStatus.SUCCESS,
                FetchAllSettingsStatus.APP_UPDATE_RECOMMENDED,
                FetchAllSettingsStatus.FW_UPDATE_RECOMMENDED -> Unit

                FetchAllSettingsStatus.FAILED -> {
                    return FetchAllSettingsResult(
                        status = FetchAllSettingsStatus.FAILED,
                        errorCode = ConnectErrorCatalog.DEVICE_SETTINGS_LOAD_FAILED.code,
                        errorMsg = ConnectErrorCatalog.DEVICE_SETTINGS_LOAD_FAILED.msg
                    )
                }
            }

            if (hasMissingRequiredDeviceInfo(fwSettingInfo)) {
                return FetchAllSettingsResult(
                    status = FetchAllSettingsStatus.REQUIRED_DEVICE_INFO_MISSING,
                    errorCode = ConnectErrorCatalog.REQUIRED_DEVICE_INFO_MISSING.code,
                    errorMsg = ConnectErrorCatalog.REQUIRED_DEVICE_INFO_MISSING.msg
                )
            }

            delay(300) // 펌웨어 설정 요청 후 약간의 딜레이를 줘야 안정적으로 Vendor Type 파싱하고 Scanner 설정 요청할 수 있음.
            val scannerSuccess = channel.requestGetScannerAllSettings()
            if (!scannerSuccess) {
                FetchAllSettingsResult(
                    status = FetchAllSettingsStatus.FAILED,
                    errorCode = ConnectErrorCatalog.DEVICE_SETTINGS_LOAD_FAILED.code,
                    errorMsg = ConnectErrorCatalog.DEVICE_SETTINGS_LOAD_FAILED.msg
                )
            } else {
                FetchAllSettingsResult(status = compatibilityStatus)
            }
        } catch (_: TransportProtocolMismatchException) {
            FetchAllSettingsResult(
                status = FetchAllSettingsStatus.REQUIRED_DEVICE_INFO_MISSING,
                errorCode = ConnectErrorCatalog.REQUIRED_DEVICE_INFO_MISSING.code,
                errorMsg = ConnectErrorCatalog.REQUIRED_DEVICE_INFO_MISSING.msg
            )
        } catch (e: Exception) {
            FetchAllSettingsResult(
                status = FetchAllSettingsStatus.FAILED,
                errorCode = ConnectErrorCatalog.DEVICE_SETTINGS_LOAD_FAILED.code,
                errorMsg = e.message ?: ConnectErrorCatalog.DEVICE_SETTINGS_LOAD_FAILED.msg
            )
        }
    }

    /**
     * 필수 디바이스 정보가 설정되어 있는지 확인합니다.
     */
    private fun hasMissingRequiredDeviceInfo(fwSettingInfo: FwSettingInfo): Boolean {
        val requiredDeviceInfo = listOf(
            "vendor" to fwSettingInfo.vendor
        )

        for ((name, value) in requiredDeviceInfo) {
            if (value == null) {
                Logger.e(msg = "=========== Required device info is missing: $name ===========")
                return true
            }
        }

        return false
    }

    /**
     * ConnectionRepo에서 관리 중인 모든 코루틴 작업(scope)을 종료합니다.
     *
     * 연결 해제(Disconnect) 시점 등에서 호출하여
     * 백그라운드 작업/리소스가 남지 않도록 정리합니다.
     */
    override fun scopeCancel() {
        protocolChannel = null
        connectedDevice = null
        session = null
        settingsLoadStateHolder.reset()
        workScope.cancel()  // 모든 job 종료
        callbackScope.cancel() // all callback jobs 종료
    }
}
