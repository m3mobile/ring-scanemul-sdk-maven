package com.m3.ring.scanemul.sdk.internal.protocol.firmware

internal interface FwSettingId : FwSettable {
    val idByte: Byte

    fun toByteArray(vendorType: FwSetting.Vendor): ByteArray? =
        byteArrayOf(idByte).takeIf { canSet(vendorType) }
}
