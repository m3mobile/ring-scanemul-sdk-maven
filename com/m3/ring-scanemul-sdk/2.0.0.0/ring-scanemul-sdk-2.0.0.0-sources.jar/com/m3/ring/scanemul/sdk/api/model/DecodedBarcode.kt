package com.m3.ring.scanemul.sdk.api.model

/**
 * A barcode result decoded and normalized by the SDK.
 *
 * Barcode type metadata appended by firmware is removed from [data] and [rawData].
 * Firmware basic formatting, including the configured end character, is preserved.
 *
 * @property data Decoded output text with firmware basic formatting and [endChar] included.
 * @property rawData Decoded output bytes with [endChar] included and barcode type metadata removed.
 * @property type Display name of the barcode type, `null` when firmware did not include type metadata,
 * or `"unknown"` when metadata was present but could not be mapped.
 * @property typeId Vendor-independent barcode type identifier, or `null` when unavailable or unmapped.
 * @property endChar End character already included at the end of [data], or an empty string when absent.
 */
data class DecodedBarcode(
    val data: String,
    val rawData: ByteArray,
    val type: String? = null,
    val typeId: BarcodeTypeId? = null,
    val endChar: String = ""
)
