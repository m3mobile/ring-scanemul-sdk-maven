package com.m3.ring.scanemul.sdk.internal.scan.data.ble

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.ParcelUuid
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.error.catalog.BLEScanErrorCatalog
import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.common.storage.PrefManager
import com.m3.ring.scanemul.sdk.internal.common.util.Utils
import com.m3.ring.scanemul.sdk.internal.scan.domain.ScanManager

internal class BLEScanManager(
    private val context: Context,
    private val prefManager: PrefManager
) : ScanManager {
    private val bluetoothManager: BluetoothManager by lazy {
        context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    }

    private val scanner: BluetoothLeScanner by lazy {
        bluetoothManager.adapter.bluetoothLeScanner
    }

    /**
     * BLE 스캔 설정을 정의합니다.
     * - SCAN_MODE_LOW_LATENCY: 가능한 한 빠르게 스캔 결과를 반환합니다.
     * - setLegacy(false): Bluetooth 5 확장을 사용하여 스캔합니다.
     * - setReportDelay(0L): 광고 중인 디바이스 정보를 실시간으로 전달합니다.
     */
    private val settings: ScanSettings = ScanSettings.Builder()
        .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
        .setLegacy(false)
        .setReportDelay(0L)
        .build()

    private var callback: ScanCallback? = null

    /**
     * S2P UUID를 기본 필터로 사용하고, MAC address가 있으면 별도 필터를 추가해 OR 조건으로 스캔합니다.
     */
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun scanBLEDevice(
        macAddress: String?,
        onDeviceFound: (BluetoothDevice) -> Unit,
        onScanFailed: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        Logger.i(msg = "=========== call BLE Scan: $macAddress ===========")

        if (macAddress != null && !BluetoothAdapter.checkBluetoothAddress(macAddress)) {
            val catalog = BLEScanErrorCatalog.INVALID_MAC_ADDRESS
            onScanFailed(catalog.code, catalog.msg)
            return
        }

        val filters = mutableListOf(
            ScanFilter.Builder()
                .setServiceUuid(ParcelUuid(Utils.generateUuidFromUniqueKey(prefManager.getString(PrefManager.UNIQUE_KEY))))
                .build()
        )

        if (macAddress != null) {
            filters += ScanFilter.Builder()
                .setDeviceAddress(macAddress)
                .build()
        }

        startScan(onDeviceFound, onScanFailed, filters)
    }

    /**
     * BLE 스캔을 시작합니다.
     */
    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    override fun startScan(
        onDeviceFound: (BluetoothDevice) -> Unit,
        onScanFailed: (errorCode: Int, errorMsg: String) -> Unit,
        myUuidFilter: List<ScanFilter>?
    ) {
        Logger.i(msg = "=========== startBLEScan ===========")

        callback = object : ScanCallback() {
            @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                Logger.i(msg = "=========== onScanResult: ${result.device.name} - ${result.device.address} - ${result.scanRecord?.serviceUuids}==========")
                onDeviceFound(result.device)
            }

            override fun onScanFailed(errorCode: Int) {
                val catalog = BLEScanErrorCatalog.fromErrorCode(errorCode)
                Logger.e(msg = "=========== Scan failed : $errorCode (${catalog.msg}) ===========")
                onScanFailed(catalog.code, catalog.msg)
            }
        }

        scanner.startScan(myUuidFilter, settings, callback)
    }

    /**
     * 스캔을 중지합니다.
     */
    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    override fun stopScan() {
        callback?.let {
            runCatching { scanner.stopScan(it) }
            Logger.i(msg = "=========== stopS2PScan ===========")
        }
    }
}
