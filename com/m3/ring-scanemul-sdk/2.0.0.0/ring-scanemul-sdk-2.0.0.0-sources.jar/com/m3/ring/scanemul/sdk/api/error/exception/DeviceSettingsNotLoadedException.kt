package com.m3.ring.scanemul.sdk.api.error.exception

class DeviceSettingsNotLoadedException(
    override val message: String,
) : Exception(message)
