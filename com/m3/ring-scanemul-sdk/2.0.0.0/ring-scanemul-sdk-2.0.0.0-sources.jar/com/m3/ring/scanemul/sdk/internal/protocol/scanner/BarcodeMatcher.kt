package com.m3.ring.scanemul.sdk.internal.protocol.scanner

import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting

/**
 * 스캐너 타입에 따라 스캐너 ID와 값을 찾아주는 기능성 객체입니다.
 */
internal object BarcodeMatcher {

    /**
     * 스캐너 ID를 매칭하기 위한 맵입니다.
     */
    val idSelectorMap: Map<FwSetting.Vendor, (ScannerIds) -> ByteArray?> = mapOf(
        FwSetting.Vendor.ZEBRA to { id -> id.zebra },
        FwSetting.Vendor.TOTINFO to { id -> id.totinfo }
    )

    /**
     * 스캐너 값(ScannerValue)을 매칭하기 위한 맵입니다.
     */
    val valueSelectorMap: Map<FwSetting.Vendor, (ScannerValue) -> ByteArray?> = mapOf(
        FwSetting.Vendor.ZEBRA to { value -> value.zebra },
        FwSetting.Vendor.TOTINFO to { value -> value.totinfo }
    )


    /**
     * 공통 매칭 함수 (T: Enum 클래스 타입)
     * 스캐너 타입에 따라 주어진 바이트 배열과 일치하는 Enum 값을 찾습니다.
     *
     * @param entries Enum 클래스의 모든 항목을 포함하는 리스트입니다.
     * @param vendorType 스캐너 벤더 타입입니다.
     * @param byteArray 비교할 바이트 배열입니다.
     * @param selectorMap 스캐너 타입에 따라 Enum 값을 선택하기 위한 맵입니다. Zebra면 Zebra에 맞는 ByteArray를 반환합니다.
     * @return 일치하는 Enum 값이 있으면 반환하고, 없으면 null을 반환합니다.
     */
    fun <T : Enum<T>> findByScannerType(
        entries: List<T>,
        vendorType: FwSetting.Vendor,
        byteArray: ByteArray,
        selectorMap: Map<FwSetting.Vendor, (T) -> ByteArray?>
    ): T? {
        val selector = selectorMap[vendorType] ?: return null
        return entries.find { selector(it)?.contentEquals(byteArray) == true }
    }
}
