package com.m3.ring.scanemul.sdk.api.listener

import com.m3.ring.scanemul.sdk.api.model.FetchAllSettingsResult

interface FetchAllSettingsResultListener {
    fun onResult(result: FetchAllSettingsResult)
}
