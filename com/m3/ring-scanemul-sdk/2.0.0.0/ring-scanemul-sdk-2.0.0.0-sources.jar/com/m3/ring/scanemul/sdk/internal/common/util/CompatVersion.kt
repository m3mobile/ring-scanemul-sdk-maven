package com.m3.ring.scanemul.sdk.internal.common.util

internal data class CompatVersion(
    val major: Int,
    val minor: Int,
    val patch: Int,
    val revision: Int
) {
    companion object {
        fun parse(rawVersion: String?): CompatVersion? =
            when (val result = parseResult(rawVersion)) {
                is CompatVersionParseResult.Valid -> result.version
                CompatVersionParseResult.Missing,
                CompatVersionParseResult.Invalid -> null
            }

        fun parseResult(rawVersion: String?): CompatVersionParseResult {
            val trimmedVersion = rawVersion?.trim()
            if (trimmedVersion.isNullOrEmpty()) {
                return CompatVersionParseResult.Missing
            }

            val numericVersion = trimmedVersion.substringBefore("-").trim()
            if (numericVersion.isEmpty()) {
                return CompatVersionParseResult.Invalid
            }

            val parts = numericVersion.split(".")
            if (parts.size != 4) {
                return CompatVersionParseResult.Invalid
            }

            return CompatVersionParseResult.Valid(
                CompatVersion(
                    major = parts[0].toIntOrNull() ?: return CompatVersionParseResult.Invalid,
                    minor = parts[1].toIntOrNull() ?: return CompatVersionParseResult.Invalid,
                    patch = parts[2].toIntOrNull() ?: return CompatVersionParseResult.Invalid,
                    revision = parts[3].toIntOrNull() ?: return CompatVersionParseResult.Invalid
                )
            )
        }
    }
}

internal sealed interface CompatVersionParseResult {
    data class Valid(val version: CompatVersion) : CompatVersionParseResult
    data object Missing : CompatVersionParseResult
    data object Invalid : CompatVersionParseResult
}
