package com.m3.ring.scanemul.sdk.api.error.catalog

import android.bluetooth.le.ScanCallback

// Introduced in Tiramisu(API 33); use literal constants to avoid lint on lower minsdk.
private const val CODE_SCAN_FAILED_OUT_OF_HARDWARE_RESOURCES = 5
private const val CODE_SCAN_FAILED_SCANNING_TOO_FREQUENTLY = 6

enum class BLEScanErrorCatalog(val code: Int, val msg: String) {
    SCAN_FAILED_ALREADY_STARTED(ScanCallback.SCAN_FAILED_ALREADY_STARTED, "BLE scan already started."),
    SCAN_FAILED_APPLICATION_REGISTRATION_FAILED(ScanCallback.SCAN_FAILED_APPLICATION_REGISTRATION_FAILED, "Failed to register BLE scan callback."),
    SCAN_FAILED_FEATURE_UNSUPPORTED(ScanCallback.SCAN_FAILED_FEATURE_UNSUPPORTED, "BLE scanning is not supported on this device."),
    SCAN_FAILED_INTERNAL_ERROR(ScanCallback.SCAN_FAILED_INTERNAL_ERROR, "Internal BLE scan error occurred."),
    INVALID_MAC_ADDRESS(3000, "Invalid Bluetooth MAC address."),

    // Introduced in Tiramisu(API 33), so use literal to avoid lint on lower minsdk.
    SCAN_FAILED_OUT_OF_HARDWARE_RESOURCES(CODE_SCAN_FAILED_OUT_OF_HARDWARE_RESOURCES, "Out of BLE hardware resources."),
    SCAN_FAILED_SCANNING_TOO_FREQUENTLY(CODE_SCAN_FAILED_SCANNING_TOO_FREQUENTLY, "BLE scanning requested too frequently. Try again later."),
    CLIENT_NOT_READY(3001, "Transport client is not ready. Initialize the SDK first."),
    UNKNOWN_ERROR(3100, "Unknown BLE scan error.");

    companion object {
        fun fromErrorCode(code: Int): BLEScanErrorCatalog =
            when (code) {
                ScanCallback.SCAN_FAILED_ALREADY_STARTED -> SCAN_FAILED_ALREADY_STARTED
                ScanCallback.SCAN_FAILED_APPLICATION_REGISTRATION_FAILED -> SCAN_FAILED_APPLICATION_REGISTRATION_FAILED
                ScanCallback.SCAN_FAILED_FEATURE_UNSUPPORTED -> SCAN_FAILED_FEATURE_UNSUPPORTED
                ScanCallback.SCAN_FAILED_INTERNAL_ERROR -> SCAN_FAILED_INTERNAL_ERROR
                INVALID_MAC_ADDRESS.code -> INVALID_MAC_ADDRESS
                CODE_SCAN_FAILED_OUT_OF_HARDWARE_RESOURCES -> SCAN_FAILED_OUT_OF_HARDWARE_RESOURCES
                CODE_SCAN_FAILED_SCANNING_TOO_FREQUENTLY -> SCAN_FAILED_SCANNING_TOO_FREQUENTLY
                CLIENT_NOT_READY.code -> CLIENT_NOT_READY
                else -> UNKNOWN_ERROR
            }
    }
}
