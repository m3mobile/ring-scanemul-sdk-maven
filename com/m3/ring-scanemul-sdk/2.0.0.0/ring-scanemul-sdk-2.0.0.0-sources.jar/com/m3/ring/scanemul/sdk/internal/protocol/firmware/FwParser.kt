package com.m3.ring.scanemul.sdk.internal.protocol.firmware

import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.common.util.CmdUtils.CHECKSUM_LENGTH
import com.m3.ring.scanemul.sdk.internal.common.util.CmdUtils.SETTING_VALUE_INDEX
import com.m3.ring.scanemul.sdk.internal.device.state.FwSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting.FwIds

internal object FwParser {
    /**
     * 펌웨어 설정 정보를 파싱합니다.
     * 주어진 ID와 값 바이트 배열을 사용하여 FirmwareSettingInfo 객체를 업데이트합니다.
     *
     * @param idByte 펌웨어 설정 ID 바이트
     * @param valueByte 펌웨어 설정 값 바이트 배열
     * @param curFwSettingInfo 현재 펌웨어 설정 정보 객체
     * @return 업데이트된 FirmwareSettingInfo 객체
     */
    fun parseFwSettings(idByte: Byte, valueByte: ByteArray, curFwSettingInfo: FwSettingInfo): FwSettingInfo {
        val settingId = FwIds.fromByte(idByte) ?: return curFwSettingInfo.also {
            Logger.i(msg = "=========== Unknown Firmware ID skipped: ${idByte.toUByte()} ===========")
        }
        var builder = curFwSettingInfo
        builder = getFwSettingInfo(settingId, valueByte, builder)

        return builder
    }

    /**
     * 펌웨어 설정 정보를 전체 데이터에서 파싱합니다.
     * 데이터는 [id + size + value] 형식으로 구성되어 있으며, size가 0인 경우 value는 비어 있습니다.
     *
     * @param data 펌웨어 설정 데이터
     * @return 파싱된 FirmwareSettingInfo 객체
     */
    fun parseFwAllSettings(data: ByteArray): FwSettingInfo {
        var index = SETTING_VALUE_INDEX
        var builder = FwSettingInfo()

        while (index < data.size - CHECKSUM_LENGTH) {
            val idValue = data.getOrNull(index) ?: break
            val size = data.getOrNull(index + 1)?.toUByte()?.toInt() ?: break
            // payload가 없는 경우 (size == 0)
            val payload = if (size > 0 && index + 2 + size <= data.size - CHECKSUM_LENGTH) {
                data.copyOfRange(index + 2, index + 2 + size)
            } else {
                byteArrayOf()
            }

            val settingId = FwIds.fromByte(idValue)
            if (settingId == null) {
                Logger.i(msg = "=========== Unknown Firmware ID skipped in all settings: ${idValue.toUByte()} ===========")
            } else {
                builder = getFwSettingInfo(settingId, payload, builder)
            }

            index += 2 + size
        }
        return builder
    }

    /**
     * 주어진 ID에 해당하는 설정 업데이트 함수를 호출하여
     * FirmwareSettingInfo 객체를 반환합니다.
     *
     * @param id 펌웨어 설정 ID
     * @param valueByte 설정 값 바이트 배열
     * @param deviceInfoState 현재 장치 정보 상태
     * @return 업데이트된 FirmwareSettingInfo 객체
     */
    fun getFwSettingInfo(
        id: FwIds,
        valueByte: ByteArray,
        deviceInfoState: FwSettingInfo
    ): FwSettingInfo = id.updateFwSettingInfo(valueByte, deviceInfoState)
}
