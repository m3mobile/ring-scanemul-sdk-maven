package com.m3.ring.scanemul.sdk.internal.decoding

import com.m3.ring.scanemul.sdk.api.model.BarcodeTypeId

internal data class BarcodeTypeTableEntry(
    val displayName: String,
    val typeId: BarcodeTypeId?
)
