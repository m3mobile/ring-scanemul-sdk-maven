package com.m3.ring.scanemul.sdk.api.model

enum class FetchAllSettingsStatus {
    SUCCESS,
    APP_SHOULD_UPDATE,
    FW_SHOULD_UPDATE,
    APP_UPDATE_RECOMMENDED,
    FW_UPDATE_RECOMMENDED,
    REQUIRED_DEVICE_INFO_MISSING,
    FAILED
}
