package com.m3.ring.scanemul.sdk.api.model

data class FetchAllSettingsResult @JvmOverloads constructor(
    val status: FetchAllSettingsStatus,
    val errorCode: Int? = null,
    val errorMsg: String? = null
)
