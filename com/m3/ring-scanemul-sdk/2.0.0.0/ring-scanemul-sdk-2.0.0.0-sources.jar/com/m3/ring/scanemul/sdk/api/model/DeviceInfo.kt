package com.m3.ring.scanemul.sdk.api.model

import com.m3.ring.scanemul.sdk.api.model.device.BtModeType
import com.m3.ring.scanemul.sdk.api.model.device.ScannerIdType
import com.m3.ring.scanemul.sdk.api.model.device.VendorType

data class DeviceInfo(
    val name: String? = null, // Ring Scanner Name
    val macAddress: String? = null, // Ring Scanner MAC Address
    val model: String? = null, // Scanner Model (ex. SE4107)
    val vendor: VendorType? = null, // Scanner Vendor (ex. Zebra)
    val serialNumber: String? = null, // Ring Scanner Serial Number
    val fwVersion: String? = null, // Ring Scanner FW Version (ex. V2.0.0.0)
    val configVersion: Int? = null, // Ring Scanner Config Version (ex. 3)
    val releaseDate: String? = null, // Ring Scanner FW Release Date (ex. 2026-07-29)
    val batteryPercent: Int? = null, // Ring Scanner Battery Percent (ex. 90)
    val scannerId: ScannerIdType? = null, // Ring Scanner ID (ex. SE4107)
    val btMode: BtModeType? = null, // Ring Scanner BT Mode (ex. HID)
)
