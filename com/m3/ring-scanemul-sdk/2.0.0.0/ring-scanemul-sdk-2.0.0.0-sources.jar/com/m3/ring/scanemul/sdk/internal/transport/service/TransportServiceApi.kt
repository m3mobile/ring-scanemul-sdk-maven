package com.m3.ring.scanemul.sdk.internal.transport.service

import android.bluetooth.BluetoothDevice
import com.m3.ring.scanemul.sdk.api.core.ConnectionType
import com.m3.ring.scanemul.sdk.api.core.TransportSession
import com.m3.ring.scanemul.sdk.api.listener.DiscoveryScanResultListener
import com.m3.ring.scanemul.sdk.api.model.FetchAllSettingsResult

/**
 * 연결 또는 스캔을 관리하는 클라이언트 인터페이스입니다.
 */
internal interface TransportServiceApi {
    fun connectToDevice(
        connectionType: ConnectionType,
        device: BluetoothDevice,
        onSuccess: (TransportSession) -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    )

    fun fetchAllSettings(onResult: (FetchAllSettingsResult) -> Unit)

    fun startS2PScan(
        onDeviceFound: (BluetoothDevice) -> Unit,
        onScanFailed: (errorCode: Int, errorMsg: String) -> Unit
    )

    fun startReconnectScan(
        onDeviceFound: (BluetoothDevice) -> Unit,
        onScanFailed: (errorCode: Int, errorMsg: String) -> Unit
    )

    fun stopS2PScan()

    fun startDiscoveryScan(listener: DiscoveryScanResultListener)
    fun stopDiscoveryScan()
}
