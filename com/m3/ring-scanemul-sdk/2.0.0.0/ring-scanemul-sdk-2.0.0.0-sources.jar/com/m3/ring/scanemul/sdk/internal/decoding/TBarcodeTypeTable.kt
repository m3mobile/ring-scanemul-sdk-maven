package com.m3.ring.scanemul.sdk.internal.decoding

import com.m3.ring.scanemul.sdk.api.model.BarcodeTypeId

internal object TBarcodeTypeTable {
    private val totinfoMap: Map<Int, BarcodeTypeTableEntry> = mapOf(
        0x00 to entry("Not Applicable", null),
        0x8B to entry("EAN-13 + 5", BarcodeTypeId.EAN_13),
        0x01 to entry("Code 39", BarcodeTypeId.CODE_39),
        0x0A to entry("EAN-8", BarcodeTypeId.EAN_8),
        0x0B to entry("EAN-13", BarcodeTypeId.EAN_13),
        0x02 to entry("Codabar", BarcodeTypeId.CODABAR),
        0x4B to entry("EAN-13 + 2", BarcodeTypeId.EAN_13),
        0x03 to entry("Code 128", BarcodeTypeId.CODE_128),
        0x04 to entry("Discrete 2 of 5", BarcodeTypeId.DISCRETE_2OF5),
        0x0E to entry("MSI", BarcodeTypeId.MSI),
        0x05 to entry("IATA", null),
        0x0F to entry("GS1-128", BarcodeTypeId.GS1_128),
        0x06 to entry("Interleaved 2 of 5", BarcodeTypeId.INTERLEAVED_2OF5),
        0x10 to entry("UPC-E1", BarcodeTypeId.UPC_E1),
        0x07 to entry("Code 93", BarcodeTypeId.CODE_93),
        0x50 to entry("UPC-E1 + 2", BarcodeTypeId.UPC_E1),
        0x08 to entry("UPC-A", BarcodeTypeId.UPC_A),
        0x90 to entry("UPC-E1 + 5", BarcodeTypeId.UPC_E1),
        0x48 to entry("UPC-A + 2", BarcodeTypeId.UPC_A),
        0x15 to entry("Trioptic", BarcodeTypeId.CODE_39),
        0x88 to entry("UPC-A + 5", BarcodeTypeId.UPC_A),
        0x16 to entry("Bookland", BarcodeTypeId.EAN_13),
        0x09 to entry("UPC-E", BarcodeTypeId.UPC_E),
        0x17 to entry("Coupon Code", null),
        0x49 to entry("UPC-E + 2", BarcodeTypeId.UPC_E),
        0x30 to entry("GS1 DataBar-14", BarcodeTypeId.GS1_DATABAR_14),
        0x4A to entry("EAN-8 + 2", BarcodeTypeId.EAN_8),
        0x0C to entry("Code 11", BarcodeTypeId.CODE_11),
        0x8A to entry("EAN-8 + 5", BarcodeTypeId.EAN_8),
        0xA0 to entry("Matrix 2 of 5", BarcodeTypeId.MATRIX_2OF5),
        0xF0 to entry("PDF-417", BarcodeTypeId.PDF417),
        0xF1 to entry("QR Code", BarcodeTypeId.QR_CODE),
        0xF2 to entry("Data Matrix", BarcodeTypeId.DATA_MATRIX),
        0xF3 to entry("Aztec Code", BarcodeTypeId.AZTEC),
        0xF4 to entry("Maxicode", BarcodeTypeId.MAXICODE),
        0xF5 to entry("Veri Code", null),
        0xF7 to entry("Han Xin", BarcodeTypeId.HAN_XIN),
        0xA2 to entry("AIM128", BarcodeTypeId.CODE_128),
        0xA3 to entry("ISSN", BarcodeTypeId.EAN_13),
        0xA4 to entry("UK Plessey", null)
    )

    fun entryFor(code: Int?): BarcodeTypeTableEntry? = totinfoMap[code]

    private fun entry(displayName: String, typeId: BarcodeTypeId?): BarcodeTypeTableEntry =
        BarcodeTypeTableEntry(displayName, typeId)
}
