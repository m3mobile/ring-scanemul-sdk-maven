package com.m3.ring.scanemul.sdk.internal.transport.data.core

import android.graphics.Bitmap
import com.m3.ring.scanemul.sdk.api.error.catalog.SetSettingErrorCatalog
import com.m3.ring.scanemul.sdk.api.listener.DecodingDataListener
import com.m3.ring.scanemul.sdk.api.listener.DisconnectListener
import com.m3.ring.scanemul.sdk.api.model.DecodedBarcode
import com.m3.ring.scanemul.sdk.internal.common.ListenerRegistry
import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.common.util.CmdUtils
import com.m3.ring.scanemul.sdk.internal.common.util.Utils
import com.m3.ring.scanemul.sdk.internal.connection.data.SettingsLoadStateHolder
import com.m3.ring.scanemul.sdk.internal.decoding.DecodedBarcodeMapper
import com.m3.ring.scanemul.sdk.internal.device.profile.ScannerProfile
import com.m3.ring.scanemul.sdk.internal.device.profile.VendorProfileRegistry
import com.m3.ring.scanemul.sdk.internal.device.state.DeviceStateStore
import com.m3.ring.scanemul.sdk.internal.device.state.InternalDeviceState
import com.m3.ring.scanemul.sdk.internal.protocol.common.commands.InternalSettingCommand
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.AccessorCommandType
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.CommandSourceType
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwCmdPreset
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwParser
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting.FwIds
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSettingInfoAccessor
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.GetAllSettingsCommands
import com.m3.ring.scanemul.sdk.internal.transport.data.core.dto.TransportRequestResult
import com.m3.ring.scanemul.sdk.internal.transport.data.core.dto.TransportRequestType
import com.m3.ring.scanemul.sdk.internal.transport.domain.ByteTransport
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

internal class DeviceProtocolChannel(
    private val byteTransport: ByteTransport,
    private val deviceStateStore: DeviceStateStore,
    private val settingsLoadStateHolder: SettingsLoadStateHolder,
) {

    private val decodingDataListenerRegistry = ListenerRegistry<DecodingDataListener>()

    // 외부용
    private val disconnectListenerRegistry = ListenerRegistry<DisconnectListener>()

    // 내부용
    private var disconnectObserver: (() -> Unit)? = null

    private val workScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val callbackScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    // FW getAll은 ACK 성공 후 SharedFlow를 거쳐 파싱됩니다.
    // ACK 성공만 보고 바로 버전 호환성을 비교하면 fwVersion이 아직 null인 상태로 판단될 수 있어,
    // 요청 완료 기준을 FW all settings 파싱 및 Store 반영 완료까지 맞추기 위한 내부 동기화입니다.
    private var firmwareAllSettingsParsedDeferred: CompletableDeferred<Unit>? = null

    init {
        observeBinaryCommand()
        observeBarcodeValue()
        observeDisconnect()
    }

    /**
     * 연결이 끊어졌을 때의 이벤트를 관찰합니다.
     * 연결이 끊어지면 [DisconnectListener]를 통해 알림을 보냅니다.
     */
    private fun observeDisconnect() {
        workScope.launch {
            byteTransport.observeDisconnect().distinctUntilChanged().collect {
                notifyDisconnect()

                deviceStateStore.clearDeviceStateListeners()
                deviceStateStore.clearDeviceInfo()

                // 리스너 정리하지 않으면, 연결할 때 마다 리스너가 쌓여서 중복 호출될 수 있음
                decodingDataListenerRegistry.clear()
                disconnectListenerRegistry.clear()

                scopeCancel()
            }
        }
    }

    /**
     * 연결 끊김 이벤트 SharedFlow를 반환합니다. (Hot Stream)
     *
     * @return 연결 끊김 이벤트 SharedFlow
     */
    fun observeDisconnectWithFlow() = byteTransport.observeDisconnect()

    /**
     * 바코드 데이터를 관찰합니다.
     * 바코드 데이터가 수신되면 [DecodingDataListener]를 통해 알림을 보냅니다.
     */
    private fun observeBarcodeValue() {
        workScope.launch {
            byteTransport.observeBarcodeData().collect { value ->
                updateBarcodeData(decodeBarcodeData(value))
            }
        }
    }

    /**
     * 바코드 데이터 SharedFlow를 반환합니다. (Hot Stream)
     *
     * @return 바코드 데이터 SharedFlow
     */
    fun observeBarcodeValueWithFlow() = byteTransport.observeBarcodeData().map(::decodeBarcodeData)

    private fun decodeBarcodeData(data: ByteArray): DecodedBarcode =
        DecodedBarcodeMapper.map(
            rawData = data,
            fwSettingInfo = deviceStateStore.getDeviceInfo().fwSettingInfo
        )

    /**
     * 펌웨어 및 스캐너 설정 관련 바이너리 명령어를 관찰합니다.
     * 수신된 명령어의 소스 타입에 따라 스캐너 설정 또는 펌웨어 설정을 처리합니다.
     */
    private fun observeBinaryCommand() {
        workScope.launch {
            byteTransport.observeBinaryCommandData().filter { CmdUtils.isBinaryCommand(it) }.collect {
                when (it[CmdUtils.SOURCE_TYPE_INDEX]) {
                    CommandSourceType.SCANNER.value -> handleScannerCommand(it)
                    CommandSourceType.FIRMWARE.value -> handleFirmwareCommand(it)
                }
            }
        }
    }


    /**
     * 연결된 블루투스 디바이스로부터 전달 받은 설정(Setting) 명령어를 처리합니다.
     * 명령어의 [CommandSourceType]이 SCANNER인 경우, 스캐너 설정 정보를 파싱하고
     * [DeviceStateStore]에 업데이트합니다.
     *
     * @param data 스캐너 설정값이 포함되어 있는 명령어
     */
    private fun handleScannerCommand(data: ByteArray) {
        val deviceInfo = deviceStateStore.getDeviceInfo()

        if (deviceInfo.fwSettingInfo.vendor == null) {
            throw IllegalArgumentException("ScannerType is null!")
        }

        val newScannerSettingInfo =
            CmdUtils.parseScannerSettings(data, deviceInfo, deviceInfo.fwSettingInfo.vendor)

        // GET 명령어에 대한 응답인 경우, 파싱된 전체 스캐너 설정 정보를 로그로 출력
        if (data.getOrNull(2) == AccessorCommandType.GET_RESPONSE.value) {
            Logger.i(msg = "=========== Parsed Scanner Settings [ALL]: $newScannerSettingInfo ===========")
        }

        deviceStateStore.updateDeviceInfo(deviceInfo.copy(scannerSettingInfo = newScannerSettingInfo))
    }


    /**
     * 연결된 블루투스 디바이스로부터 전달 받은 설정 명령어를 처리합니다.
     * [DeviceStateStore]에 업데이트합니다.
     *
     * @param data 펌웨어 설정값이 포함되어 있는 명령어
     */
    private fun handleFirmwareCommand(data: ByteArray) {
        val deviceInfo = deviceStateStore.getDeviceInfo()

        when (data[CmdUtils.SUB_COMMAND_INDEX]) {
            FwIds.SET_ALL_FW_CMDS.idByte -> {
                val newFirmwareSettings = FwParser.parseFwAllSettings(data)
                Logger.i(msg = "=========== Parsed Firmware Settings [ALL]: $newFirmwareSettings ===========")
                deviceStateStore.updateDeviceInfo(deviceInfo.copy(fwSettingInfo = newFirmwareSettings))
                firmwareAllSettingsParsedDeferred?.complete(Unit)
                firmwareAllSettingsParsedDeferred = null
            }

            else -> {
                val cmdId = data.getOrNull(CmdUtils.SUB_COMMAND_INDEX) ?: return
                val valueByte = data.sliceArray((CmdUtils.SUB_COMMAND_INDEX + 1) until (data.size - 2))
                val newFirmwareSetting = FwParser.parseFwSettings(
                    cmdId, valueByte, deviceInfo.fwSettingInfo
                )
                deviceStateStore.updateDeviceInfo(deviceInfo.copy(fwSettingInfo = newFirmwareSetting))
            }
        }
    }

    /**
     * 블루투스 디바이스에 데이터를 쓰기 요청합니다.
     *
     * @param data 쓰기 요청할 데이터
     */
    fun requestWrite(data: ByteArray) {
        byteTransport.requestWrite(data)
    }

    /**
     * 블루투스 디바이스와 연결을 해제합니다.
     *
     * @param onSuccess 연결 해제 성공 콜백
     * @param onFailure 연결 해제 실패 콜백
     */
    fun disconnect(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit) {
        byteTransport.disconnect(
            onSuccess = {
                callbackScope.launch { onSuccess() }
            },
            onFailure = { msg ->
                callbackScope.launch { onFailure(msg) }
            })
    }

    /**
     * 현재 설정되어 있는 모든 스캐너 용 설정값을 요청합니다.
     */
    suspend fun requestGetScannerAllSettings(): Boolean {
        val vendorType = deviceStateStore.getDeviceInfo().fwSettingInfo.vendor
            ?: throw IllegalArgumentException("Vendor Type is null!")
        val command = GetAllSettingsCommands.getAllSettings(vendorType)

        return try {
            val result = byteTransport.requestWriteWithAck(
                command,
                TransportRequestType.SCANNER_GET_ALL
            ).await()

            when (result) {
                TransportRequestResult.SUCCESS -> true
                TransportRequestResult.FAILED -> false
                TransportRequestResult.TRANSPORT_PROTOCOL_MISMATCH -> throw TransportProtocolMismatchException()
            }
        } catch (e: TransportProtocolMismatchException) {
            Logger.e(msg = "=========== Get scanner settings failed: ${e.message} ===========")
            throw e
        } catch (e: Exception) {
            Logger.e(msg = "=========== Get scanner settings failed: ${e.message} ===========")
            false
        }
    }

    /**
     * 현재 설정되어 있는 모든 펌웨어 용 설정값을 요청합니다.
     */
    suspend fun requestGetFirmwareAllSettings(): Boolean {
        val command = CmdUtils.createFirmwareGetCommand(FwIds.SET_ALL_FW_CMDS.idByte)

        // requestWriteWithAck의 SUCCESS는 응답 수신까지만 보장하므로,
        // fwVersion null 상태로 호환성 비교가 먼저 실행되지 않도록 FW all settings 파싱 완료까지 기다립니다.
        val parsedDeferred = CompletableDeferred<Unit>()
        firmwareAllSettingsParsedDeferred = parsedDeferred

        return try {
            val result = byteTransport.requestWriteWithAck(
                command,
                TransportRequestType.FIRMWARE_GET_ALL
            ).await()
            if (result != TransportRequestResult.SUCCESS) {
                firmwareAllSettingsParsedDeferred = null
                return false
            }

            val parsed = withTimeoutOrNull(1_000) {
                parsedDeferred.await()
            } != null
            if (!parsed) {
                firmwareAllSettingsParsedDeferred = null
            }
            parsed
        } catch (e: Exception) {
            firmwareAllSettingsParsedDeferred = null
            Logger.e(msg = "=========== Get firmware settings failed: ${e.message} ===========")
            false
        }
    }

    /**
     * 블루투스 디바이스에 새로운 설정을 요청합니다.
     *
     * @param setting 적용할 설정 정보
     * @param onSuccess 설정 성공 콜백
     * @param onFailure 설정 실패 콜백
     */
    fun setSetting(
        setting: InternalSettingCommand,
        onSuccess: () -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit,
    ) {
        fun fail(catalog: SetSettingErrorCatalog, msg: String = catalog.msg) {
            callbackScope.launch {
                onFailure(catalog.code, msg)
            }
        }

        // fetchAllSettings가 성공하지 못 했다면, 실패 처리.
        if (!settingsLoadStateHolder.isSettingsLoaded) {
            fail(SetSettingErrorCatalog.DEVICE_SETTINGS_NOT_LOADED)
            return
        }

        val fwSettingInfo = deviceStateStore.getDeviceInfo().fwSettingInfo

        val vendorType = fwSettingInfo.vendor
            ?: run {
                fail(
                    SetSettingErrorCatalog.SDK_ERROR,
                    "An SDK error occurred because vendor information is missing. Please update the ring scanner firmware and try again."
                )
                return
            }

        val registry = VendorProfileRegistry.registry[vendorType]
            ?: run {
                callbackScope.launch {
                    Logger.e(msg = "=========== Vendor profile not found for $vendorType ===========")
                    fail(SetSettingErrorCatalog.SDK_ERROR)
                }
                return
            }

        val (cmd, valueByte) = when (setting) {
            is InternalSettingCommand.Error -> {
                fail(SetSettingErrorCatalog.INVALID_COMMAND, setting.message)
                return
            }

            is InternalSettingCommand.Valid.Scanner -> {
                val value = setting.value
                if (value == null) {
                    fail(
                        SetSettingErrorCatalog.INVALID_COMMAND,
                        "${SetSettingErrorCatalog.INVALID_COMMAND.msg}: ${setting.id} has no value"
                    )
                    return
                }
                createScannerCmd(setting, registry, vendorType)
                    ?: run {
                        fail(
                            SetSettingErrorCatalog.UNSUPPORTED_SETTING,
                            "${SetSettingErrorCatalog.UNSUPPORTED_SETTING.msg}: ${setting.id} for $vendorType"
                        )
                        return
                    }
            }

            is InternalSettingCommand.Valid.Firmware -> {
                if (!FwSettingInfoAccessor.hasValue(fwSettingInfo, setting.id)) {
                    fail(
                        SetSettingErrorCatalog.UNSUPPORTED_SETTING,
                        "${SetSettingErrorCatalog.UNSUPPORTED_SETTING.msg}: ${setting.id}"
                    )
                    return
                }

                val value = setting.value
                if (value == null) {
                    fail(
                        SetSettingErrorCatalog.INVALID_COMMAND,
                        "${SetSettingErrorCatalog.INVALID_COMMAND.msg}: ${setting.id} has no value"
                    )
                    return
                }
                if (!setting.id.canSet(vendorType) || !value.canSet(vendorType)) {
                    fail(
                        SetSettingErrorCatalog.UNSUPPORTED_SETTING,
                        "${SetSettingErrorCatalog.UNSUPPORTED_SETTING.msg}: ${setting.id} for $vendorType"
                    )
                    return
                }

                createFwCmd(setting, vendorType)
                    ?: run {
                        fail(SetSettingErrorCatalog.SDK_ERROR)
                        return
                    }
            }
        }

        val validSetting = setting as? InternalSettingCommand.Valid
            ?: error("InternalSettingCommand.Error must not reach handleSetSettingResult")

        workScope.launch {
            val success = try {
                byteTransport.requestWriteWithAck(
                    cmd,
                    TransportRequestType.SET_SETTING
                ).await() == TransportRequestResult.SUCCESS
            } catch (e: TimeoutCancellationException) {
                null
            }

            val deviceInfo = deviceStateStore.getDeviceInfo()

            callbackScope.launch {
                handleSetSettingResult(
                    success,
                    validSetting,
                    valueByte,
                    deviceInfo,
                    onSuccess,
                    onFailure
                )
            }
        }
    }

    /**
     * 디바이스의 모든 설정을 기본값으로 초기화합니다.
     * 이후, 스캐너와 펌웨어의 모든 설정을 다시 요청하여
     * 디바이스의 상태를 최신으로 유지합니다.
     */
    fun setDefaultSetting(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit) {
        workScope.launch {
            val cmd = FwCmdPreset.default
            byteTransport.requestWrite(cmd)
            delay(2_000)
            val firmwareSuccess = requestGetFirmwareAllSettings()
            val scannerSuccess = firmwareSuccess && requestGetScannerAllSettings()
            callbackScope.launch {
                if (!firmwareSuccess) {
                    onFailure("Failed to fetch firmware settings after reset.")
                    return@launch
                }
                if (!scannerSuccess) {
                    onFailure("Failed to fetch scanner settings after reset.")
                    return@launch
                }
                onSuccess()
            }
        }
    }

    /**
     * 스캐너 설정 명령어를 생성합니다.
     * @param setting 설정 정보
     * @param registry 벤더 프로필 레지스트리
     * @param vendorType 벤더 타입
     *
     * @return 설정 명령어 바이트 배열과 설정 값 바이트 배열의 쌍, 생성 실패 시 null
     */
    private fun createScannerCmd(
        setting: InternalSettingCommand.Valid.Scanner,
        registry: ScannerProfile,
        vendorType: FwSetting.Vendor
    ): Pair<ByteArray, ByteArray>? {
        val idByte = setting.id.toByteArray(vendorType) ?: return null
        val valueByte = setting.value?.toByteArray(vendorType) ?: return null
        return Pair(registry.createSetCommand(idByte + valueByte), valueByte)
    }

    /**
     * 펌웨어 설정 명령어를 생성합니다.
     *
     * @param setting 설정 정보
     * @return 설정 명령어 바이트 배열과 설정 값 바이트 배열의 쌍, 생성 실패 시 null
     */
    private fun createFwCmd(
        setting: InternalSettingCommand.Valid.Firmware,
        vendorType: FwSetting.Vendor,
    ): Pair<ByteArray, ByteArray>? {
        val idByte = setting.id.toByteArray(vendorType) ?: return null
        val valueByte = setting.value?.toByteArray(vendorType) ?: return null
        return Pair(CmdUtils.createFirmwareSetCommand(idByte + valueByte), valueByte)
    }

    /**
     * 설정 요청에 대한 결과를 처리합니다.
     *
     * @param success 설정 성공 여부
     * @param setting 설정 정보
     * @param valueByte 설정 값 바이트 배열
     * @param deviceInfo 디바이스 정보
     * @param onSuccess 설정 성공 콜백
     * @param onFailure 설정 실패 콜백
     */
    private fun handleSetSettingResult(
        success: Boolean?,
        setting: InternalSettingCommand.Valid,
        valueByte: ByteArray,
        deviceInfo: InternalDeviceState,
        onSuccess: () -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        when (success) {
            true -> {
                updateSettingInfoOnSuccess(setting, valueByte, deviceInfo)
                when (setting) {
                    is InternalSettingCommand.Valid.Scanner ->
                        Logger.i(msg = "=========== Set Success [SCANNER] id=${setting.id}, value=${setting.value} ===========")

                    is InternalSettingCommand.Valid.Firmware ->
                        Logger.i(msg = "=========== Set Success [FIRMWARE] id=${setting.id}, value=${setting.value} ===========")
                }
                onSuccess()
            }

            false -> {
                val errorCatalog = SetSettingErrorCatalog.SETTING_FAILED
                val errorMsg: String = when (setting) {
                    is InternalSettingCommand.Valid.Scanner ->
                        "${errorCatalog.msg} id=${setting.id}"

                    is InternalSettingCommand.Valid.Firmware ->
                        "${errorCatalog.msg} id=${setting.id}"
                }
                Logger.e(msg = errorMsg)
                onFailure(errorCatalog.code, errorMsg)
            }

            null -> {
                val errorCatalog = SetSettingErrorCatalog.REQUEST_TIMEOUT
                Logger.e(msg = errorCatalog.msg)
                onFailure(errorCatalog.code, errorCatalog.msg)
            }
        }
    }


    /**
     * 설정이 성공적으로 적용되었을 때, InternalDeviceState에 설정했던 값으로 업데이트합니다.
     */
    private fun updateSettingInfoOnSuccess(
        setting: InternalSettingCommand.Valid,
        valueByte: ByteArray,
        deviceInfo: InternalDeviceState
    ) {
        val vendorType = deviceInfo.fwSettingInfo.vendor
            ?: throw IllegalArgumentException("Vendor Type is null!")

        when (setting) {
            is InternalSettingCommand.Valid.Scanner -> {
                val newScanner = setting.id.updateScannerSettingInfo(vendorType, valueByte, deviceInfo.scannerSettingInfo)
                deviceStateStore.updateDeviceInfo(deviceInfo.copy(scannerSettingInfo = newScanner))
            }

            is InternalSettingCommand.Valid.Firmware -> {
                val newFw = FwParser.getFwSettingInfo(
                    setting.id, valueByte, deviceInfo.fwSettingInfo
                )
                deviceStateStore.updateDeviceInfo(deviceInfo.copy(fwSettingInfo = newFw))
            }
        }
    }

    /**
     * 모든 설정을 담은 QR 코드를 생성합니다.
     *
     * @param btMode QR 코드에 포함할 블루투스 모드 설정
     * @return QR 코드 이미지
     */
    fun generateQrBitmap(btMode: FwSetting.BtModeSetting?): Bitmap? {
        val curDeviceInfo = deviceStateStore.getDeviceInfo()
        val targetDeviceInfo = curDeviceInfo.copy(fwSettingInfo = curDeviceInfo.fwSettingInfo.copy(mode = btMode))
        return Utils.generateQrBitmap(targetDeviceInfo)
    }

    /**
     * TransportRepo에서 관리 중인 모든 코루틴 작업(scope)을 종료합니다.
     *
     * 연결 해제(Disconnect) 시점 등에서 호출하여
     * 백그라운드 작업/리소스가 남지 않도록 정리합니다.
     */
    private fun scopeCancel() {
        callbackScope.cancel() // 모든 callback 작업 종료
        workScope.cancel()  // 모든 job 종료
    }

    /* =============== About listeners ================ */
    /* Barcode */
    fun addDecodingDataListener(barCodeDataListener: DecodingDataListener) {
        decodingDataListenerRegistry.add(barCodeDataListener)
    }

    fun removeDecodingDataListener(barCodeDataListener: DecodingDataListener) {
        decodingDataListenerRegistry.remove(barCodeDataListener)
    }

    private fun updateBarcodeData(data: DecodedBarcode) {
        callbackScope.launch {
            decodingDataListenerRegistry.notifyAll {
                runCatching { it.onReceive(data) }
                    .onFailure { Logger.e(msg = "=========== Listener error in onReceive: ${it.message} ===========") }
            }
        }
    }

    /* Disconnect */
    fun addDisconnectListener(disconnectListener: DisconnectListener) {
        disconnectListenerRegistry.add(disconnectListener)
    }

    fun removeDisconnectListener(disconnectListener: DisconnectListener) {
        disconnectListenerRegistry.remove(disconnectListener)
    }

    // Internal use only
    fun addOnDisconnected(observer: () -> Unit) {
        disconnectObserver = observer
    }

    private suspend fun notifyDisconnect() {
        withContext(Dispatchers.Main.immediate + NonCancellable) { // 반드시 실행되어야 함
            disconnectObserver?.invoke()
            disconnectListenerRegistry.notifyAll {
                runCatching { it.onDisconnect() }
                    .onFailure { Logger.e(msg = "=========== Listener error in onDisconnect: ${it.message} ===========") }
            }
        }
    }
}
