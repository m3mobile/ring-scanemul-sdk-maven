package com.m3.ring.scanemul.sdk.internal.transport.data.spp

import com.m3.ring.scanemul.sdk.internal.transport.data.core.dto.TransportRequestResult
import kotlinx.coroutines.CompletableDeferred

internal data class MatchedPendingResponse(
    val responseType: Byte,
    val deferred: CompletableDeferred<TransportRequestResult>
)

