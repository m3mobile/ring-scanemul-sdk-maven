package com.m3.ring.scanemul.sdk.internal.protocol.firmware

/**
 * 펌웨어 통신할 때 사용하는 포맷 ID
 *
 * SET : 설정 명령
 * GET : 조회 명령
 * RESPONSE : 펌웨어로부터 응답을 받을 때
 */
internal enum class AccessorCommandType(val value: Byte) {
    SET(0xA0.toByte()),
    GET(0xB0.toByte()),
    GET_RESPONSE(0xC0.toByte()),
    SET_RESPONSE(0xD0.toByte());
}

internal enum class CommandSourceType(val value: Byte) {
    FIRMWARE(0x02.toByte()),
    SCANNER(0x04.toByte());
}
