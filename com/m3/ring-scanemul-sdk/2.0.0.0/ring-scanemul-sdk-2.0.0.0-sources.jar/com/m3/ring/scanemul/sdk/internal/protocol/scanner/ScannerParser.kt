package com.m3.ring.scanemul.sdk.internal.protocol.scanner

import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting

/**
 * 스캐너 설정 정보를 Byte로부터 파싱합니다.
 */
internal object ScannerParser {
    /**
     * 스캐너 설정 정보를 업데이트합니다.
     *
     * @param id 스캐너 설정 ID를 나타내는 [ScannerIds]입니다.
     * @param valueByte 스캐너 설정 값을 나타내는 바이트 배열입니다.
     * @param vendorType 스캐너의 종류를 나타내는 [FwSetting.Vendor]입니다.
     * @param scannerSettingInfo 현재 장치 정보 상태를 나타내는 [ScannerSettingInfo]입니다.
     * @return 업데이트된 [ScannerSettingInfo] 객체를 반환합니다.
     */
    fun parseForScannerSetting(
        idByte: ByteArray,
        valueByte: ByteArray,
        vendorType: FwSetting.Vendor,
        scannerSettingInfo: ScannerSettingInfo
    ): ScannerSettingInfo {
        return ScannerSettingInfoParserGenerated.parseForScannerSetting(
            idBytes = idByte,
            valueBytes = valueByte,
            vendorType = vendorType,
            info = scannerSettingInfo
        )
    }
}
