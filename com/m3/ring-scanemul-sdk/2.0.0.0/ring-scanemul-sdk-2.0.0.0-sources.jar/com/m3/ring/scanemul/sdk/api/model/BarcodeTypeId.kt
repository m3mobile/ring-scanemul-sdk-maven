package com.m3.ring.scanemul.sdk.api.model

import java.util.Locale

/**
 * Normalized barcode symbology ids exposed by the SDK.
 */
enum class BarcodeTypeId {
    UPC_A,
    UPC_E,
    UPC_E1,
    EAN_8,
    EAN_13,
    CODE_128,
    GS1_128,
    ISBT_128,
    CODE_39,
    CODE_93,
    INTERLEAVED_2OF5,
    DISCRETE_2OF5,
    CHINESE_2OF5,
    CODABAR,
    MSI,
    CODE_11,
    DATA_MATRIX,
    GS1_DATABAR_14,
    GS1_DATABAR_LIMITED,
    GS1_DATABAR_EXPANDED,
    PDF417,
    MICRO_PDF417,
    QR_CODE,
    MICRO_QR_CODE,
    DOT_CODE,
    AZTEC,
    HAN_XIN,
    COMPOSITE,
    COMPOSITE_AB,
    COMPOSITE_C,
    JAPANESE_POSTAL,
    KOREAN_3OF5,
    MATRIX_2OF5,
    MAXICODE,
    US_PLANET,
    US_POSTNET,
    UK_POSTAL,
    NETHERLANDS_KIX,
    AUSTRALIAN_POSTAL,
    UPU_FICS_POSTAL;

    val id: String
        get() = name.lowercase(Locale.ROOT)

    companion object {
        @JvmStatic
        fun fromId(id: String?): BarcodeTypeId? {
            val normalizedId = id?.trim().orEmpty()
            if (normalizedId.isEmpty()) return null

            return entries.firstOrNull {
                it.id.equals(normalizedId, ignoreCase = true) ||
                    it.name.equals(normalizedId, ignoreCase = true)
            }
        }
    }
}
