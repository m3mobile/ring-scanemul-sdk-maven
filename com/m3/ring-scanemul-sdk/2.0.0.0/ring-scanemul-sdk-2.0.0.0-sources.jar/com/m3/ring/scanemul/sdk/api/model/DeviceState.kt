package com.m3.ring.scanemul.sdk.api.model

import com.m3.ring.scanemul.sdk.api.model.settings.basic.BasicFormat
import com.m3.ring.scanemul.sdk.api.model.settings.advanced.AdvancedSettings
import com.m3.ring.scanemul.sdk.api.model.settings.general.GeneralSettings
import com.m3.ring.scanemul.sdk.api.model.settings.reader.ReaderSettings
import com.m3.ring.scanemul.sdk.api.model.symbologies.Symbologies

data class DeviceState(
    val deviceInfo: DeviceInfo = DeviceInfo(),
    val general: GeneralSettings = GeneralSettings(),
    val symbologies: Symbologies = Symbologies(),
    val basicFormat: BasicFormat = BasicFormat(),
    val readerSettings: ReaderSettings = ReaderSettings(),
    val advancedSettings: AdvancedSettings = AdvancedSettings()
)
