package com.m3.ring.scanemul.sdk.internal.protocol.firmware

internal interface FwValue : FwSettable {
    val value: ByteArray

    fun toByteArray(vendorType: FwSetting.Vendor): ByteArray? =
        value.takeIf { canSet(vendorType) }
}
