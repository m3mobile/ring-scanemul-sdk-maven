package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.composite.CompositeType
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
internal object CompositeSymbology {
    /* Ids */
    enum class CompositeIds(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        /*
         Totinfo에는 Composite Enable만 있고,
         Zebra는 CompositeAB, CompositeC로 나뉘어져 있다.
         */
        @BindField("compositeEnable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(totinfo = byteArrayOf(0xF2.toByte(), 0x17.toByte())),

        @BindField("compositeAbEnable")
        @BindValue(ValueType.ENUM, AbEnableVal::class)
        AB_ENABLE(zebra = byteArrayOf(0xF0.toByte(), 0x56)),

        @BindField("compositeCEnable")
        @BindValue(ValueType.ENUM, CEnableVal::class)
        C_ENABLE(zebra = byteArrayOf(0xF0.toByte(), 0x55)),

        @BindField("compositeTLC39Enable")
        @BindValue(ValueType.ENUM, Tlc39EnableVal::class)
        TLC39_ENABLE(zebra = byteArrayOf(0xF0.toByte(), 0x73)),

        @BindField("compositeUPCCompositeMode")
        @BindValue(ValueType.ENUM, UpcCompositeModeVal::class)
        UPC_COMPOSITE_MODE(zebra = byteArrayOf(0xF0.toByte(), 0x58));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(totinfo = byteArrayOf(0x00)),
        ENABLE(totinfo = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class AbEnableVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = null),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = null)
    }

    @EnableDisableEnum
    enum class CEnableVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = null),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = null)
    }

    @EnableDisableEnum
    enum class Tlc39EnableVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00)),
        ENABLE(zebra = byteArrayOf(0x01))
    }

    @EnumNameMatch(external = CompositeType.UPCCompositeModeType::class)
    enum class UpcCompositeModeVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        NEVER_LINKED(zebra = byteArrayOf(0x00)),
        ALWAYS_LINKED(zebra = byteArrayOf(0x01)),
        AUTO_DISCRIMINATE(zebra = byteArrayOf(0x02))
    }
}
