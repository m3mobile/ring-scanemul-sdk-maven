package com.m3.ring.scanemul.sdk.api.model.settings.reader

import com.m3.ring.scanemul.sdk.api.model.TypeValue

object ReaderType {
    enum class Inverse1DType : TypeValue {
        REGULAR_ONLY, INVERSE_ONLY, INVERSE_AUTODETECT
    }

    enum class QuietZoneLevelType : TypeValue {
        LEVEL_0, LEVEL_1, LEVEL_2, LEVEL_3
    }

    enum class PoorQualityDecodeEffortType : TypeValue {
        LEVEL_0, LEVEL_1, LEVEL_2, LEVEL_3
    }

    enum class ReadModeType : TypeValue {
        ASYNC, SYNC, AIM_RELEASE
    }
}
