package com.m3.ring.scanemul.sdk.api.error.exception

class ConnectToDeviceException(
    val errorCode: Int,
    override val message: String?
) : Exception(message)
