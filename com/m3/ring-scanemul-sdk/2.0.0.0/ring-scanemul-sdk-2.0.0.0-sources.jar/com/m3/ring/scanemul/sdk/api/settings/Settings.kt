package com.m3.ring.scanemul.sdk.api.settings

import com.m3.ring.scanemul.sdk.api.model.settings.basic.BasicFormatType
import com.m3.ring.scanemul.sdk.api.model.settings.general.SoundType
import com.m3.ring.scanemul.sdk.api.model.settings.reader.ReaderType
import com.m3.ring.scanemul.sdk.api.model.symbologies.codabar.CodabarType
import com.m3.ring.scanemul.sdk.api.model.symbologies.code11.Code11Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.code128.Code128Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.code39.Code39Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.composite.CompositeType
import com.m3.ring.scanemul.sdk.api.model.symbologies.datamatrix.DataMatrixType
import com.m3.ring.scanemul.sdk.api.model.symbologies.dotcode.DotCodeType
import com.m3.ring.scanemul.sdk.api.model.symbologies.gs1limited.Gs1DataBarLimitedType
import com.m3.ring.scanemul.sdk.api.model.symbologies.hanxin.HanXinType
import com.m3.ring.scanemul.sdk.api.model.symbologies.interleaved2of5.Interleaved2Of5Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.msi.MsiType
import com.m3.ring.scanemul.sdk.api.model.symbologies.upca.UpcAType
import com.m3.ring.scanemul.sdk.api.model.symbologies.upce.UpcEType
import com.m3.ring.scanemul.sdk.api.model.symbologies.upce1.UpcE1Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.upcean.UpcEanType
import com.m3.ring.scanemul.sdk.internal.protocol.common.commands.InternalSettings

/**
 * Public facade to configure scanner and firmware settings.
 * All concrete logic lives in internal/InternalSettings.
 * Each method wraps the internal command into a public [SettingCommand].
 */
object Settings {

    object AustralianPostal {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.AustralianPostal.setEnable(enable))
    }

    object Aztec {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Aztec.setEnable(enable))
    }

    object Chinese2of5 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Chinese2of5.setEnable(enable))
    }

    object Codabar {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Codabar.setEnable(enable))

        @JvmStatic
        fun setLength1(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Codabar.setLength1(length))

        @JvmStatic
        fun setLength2(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Codabar.setLength2(length))

        @JvmStatic
        fun setCLSIEditing(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Codabar.setCLSIEditing(enable))

        @JvmStatic
        fun setNotisEditing(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Codabar.setNotisEditing(enable))

        @JvmStatic
        fun setSecurityLevel(value: CodabarType.SecurityType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Codabar.setSecurityLevel(value))
    }

    object Code11 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code11.setEnable(enable))

        @JvmStatic
        fun setLength1(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code11.setLength1(length))

        @JvmStatic
        fun setLength2(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code11.setLength2(length))

        @JvmStatic
        fun setReportCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code11.setReportCheckDigit(enable))

        @JvmStatic
        fun setVerifyCheckDigit(value: Code11Type.VerifyCheckDigitType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code11.setVerifyCheckDigit(value))
    }

    object Code39 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code39.setEnable(enable))

        @JvmStatic
        fun setTriopticCode39(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code39.setTriopticCode39(enable))

        @JvmStatic
        fun setLength1(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code39.setLength1(length))

        @JvmStatic
        fun setLength2(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code39.setLength2(length))

        @JvmStatic
        fun setReducedQuietZone(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code39.setReducedQuietZone(enable))

        @JvmStatic
        fun setConvertToCode32(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code39.setConvertToCode32(enable))

        @JvmStatic
        fun setFullAscii(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code39.setFullAscii(enable))

        @JvmStatic
        fun setReportCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code39.setReportCheckDigit(enable))

        @JvmStatic
        fun setReportCode32Prefix(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code39.setReportCode32Prefix(enable))

        @JvmStatic
        fun setSecurityLevel(value: Code39Type.SecurityType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code39.setSecurityLevel(value))

        @JvmStatic
        fun setVerifyCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code39.setVerifyCheckDigit(enable))
    }

    object Code93 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code93.setEnable(enable))

        @JvmStatic
        fun setLength1(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code93.setLength1(length))

        @JvmStatic
        fun setLength2(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code93.setLength2(length))
    }

    object Code128 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code128.setEnable(enable))

        @JvmStatic
        fun setLength1(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code128.setLength1(length))

        @JvmStatic
        fun setLength2(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code128.setLength2(length))

        @JvmStatic
        fun setReducedQuietZone(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code128.setReducedQuietZone(enable))

        @JvmStatic
        fun setIgnoreFnc4(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code128.setIgnoreFnc4(enable))

        @JvmStatic
        fun setCheckIsbtTable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code128.setCheckIsbtTable(enable))

        @JvmStatic
        fun setIsbt128ConcatMode(value: Code128Type.ISBT128ConcatModeType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code128.setIsbt128ConcatMode(value))

        @JvmStatic
        fun setSecurityLevel(value: Code128Type.SecurityType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code128.setSecurityLevel(value))

        @JvmStatic
        fun setEmulationMode(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Code128.setEmulationMode(enable))
    }

    object Composite {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Composite.setEnable(enable))

        @JvmStatic
        fun setABEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Composite.setABEnable(enable))

        @JvmStatic
        fun setCEnable(value: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Composite.setCEnable(value))

        @JvmStatic
        fun setTlc39Enable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Composite.setTlc39Enable(enable))

        @JvmStatic
        fun setUpcCompositeMode(value: CompositeType.UPCCompositeModeType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Composite.setUpcCompositeMode(value))
    }

    object DataMatrix {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.DataMatrix.setEnable(enable))

        @JvmStatic
        fun setInverse(value: DataMatrixType.InverseType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.DataMatrix.setInverse(value))

        @JvmStatic
        fun setDecodeMirrorImages(value: DataMatrixType.DecodeMirrorImagesType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.DataMatrix.setDecodeMirrorImages(value))

        @JvmStatic
        fun setGs1DataMatrix(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.DataMatrix.setGs1DataMatrix(enable))
    }

    object Discrete2Of5 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Discrete2Of5.setEnable(enable))

        @JvmStatic
        fun setLength1(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Discrete2Of5.setLength1(length))

        @JvmStatic
        fun setLength2(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Discrete2Of5.setLength2(length))
    }

    object DotCode {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.DotCode.setEnable(enable))

        @JvmStatic
        fun setInverse(value: DotCodeType.InverseType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.DotCode.setInverse(value))

        @JvmStatic
        fun setMirror(value: DotCodeType.MirrorType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.DotCode.setMirror(value))

        @JvmStatic
        fun setPrioritize(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.DotCode.setPrioritize(enable))
    }

    object EAN8 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.EAN8.setEnable(enable))
    }

    object EAN13 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.EAN13.setEnable(enable))
    }

    object Gs1DataBar14 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Gs1DataBar14.setEnable(enable))
    }

    object Gs1DataBarExpanded {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Gs1DataBarExpanded.setEnable(enable))
    }

    object Gs1DataBarLimited {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Gs1DataBarLimited.setEnable(enable))

        @JvmStatic
        fun setLimitedSecurityLevel(value: Gs1DataBarLimitedType.SecurityType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Gs1DataBarLimited.setLimitedSecurityLevel(value))
    }

    object Gs1128 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Gs1128.setEnable(enable))
    }

    object HanXin {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.HanXin.setEnable(enable))

        @JvmStatic
        fun setInverse(value: HanXinType.InverseType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.HanXin.setInverse(value))
    }

    object Interleaved2Of5 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Interleaved2Of5.setEnable(enable))

        @JvmStatic
        fun setLength1(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Interleaved2Of5.setLength1(length))

        @JvmStatic
        fun setLength2(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Interleaved2Of5.setLength2(length))

        @JvmStatic
        fun setCheckDigit(value: Interleaved2Of5Type.CheckDigitType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Interleaved2Of5.setCheckDigit(value))

        @JvmStatic
        fun setReportCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Interleaved2Of5.setReportCheckDigit(enable))

        @JvmStatic
        fun setSecurityLevel(value: Interleaved2Of5Type.SecurityType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Interleaved2Of5.setSecurityLevel(value))

        @JvmStatic
        fun setConvertItf14ToEan13(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Interleaved2Of5.setConvertItf14ToEan13(enable))

        @JvmStatic
        fun setReducedQuietZone(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Interleaved2Of5.setReducedQuietZone(enable))
    }

    object ISBT128 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.ISBT128.setEnable(enable))
    }

    object JapanesePostal {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.JapanesePostal.setEnable(enable))
    }

    object Korean3of5 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Korean3of5.setEnable(enable))
    }

    object Matrix2of5 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Matrix2Of5.setEnable(enable))

        @JvmStatic
        fun setLength1(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Matrix2Of5.setLength1(length))

        @JvmStatic
        fun setLength2(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Matrix2Of5.setLength2(length))

        @JvmStatic
        fun setRedundancy(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Matrix2Of5.setRedundancy(enable))

        @JvmStatic
        fun setReportCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Matrix2Of5.setReportCheckDigit(enable))

        @JvmStatic
        fun setVerifyCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Matrix2Of5.setVerifyCheckDigit(enable))
    }

    object MaxiCode {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.MaxiCode.setEnable(enable))
    }

    object MicroPdf417 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.MicroPdf417.setEnable(enable))
    }

    object MicroQrCode {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.MicroQrCode.setEnable(enable))
    }

    object MSI {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.MSI.setEnable(enable))

        @JvmStatic
        fun setLength1(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.MSI.setLength1(length))

        @JvmStatic
        fun setLength2(length: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.MSI.setLength2(length))

        @JvmStatic
        fun setCheckDigit(value: MsiType.CheckDigitType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.MSI.setCheckDigit(value))

        @JvmStatic
        fun setCheckDigitScheme(value: MsiType.CheckDigitSchemeType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.MSI.setCheckDigitScheme(value))

        @JvmStatic
        fun setReportCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.MSI.setReportCheckDigit(enable))
    }

    object NetherlandsKix {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.NetherlandsKix.setEnable(enable))
    }

    object Pdf417 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Pdf417.setEnable(enable))
    }

    object QrCode {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.QrCode.setEnable(enable))
    }

    object UKPostal {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UKPostal.setEnable(enable))

        @JvmStatic
        fun setReportCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UKPostal.setReportCheckDigit(enable))
    }

    object UPCA {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCA.setEnable(enable))

        @JvmStatic
        fun setReportCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCA.setReportCheckDigit(enable))

        @JvmStatic
        fun setPreamble(value: UpcAType.PreambleType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCA.setPreamble(value))

        @JvmStatic
        fun setSupplemental2Bit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCA.setSupplemental2Bit(enable))

        @JvmStatic
        fun setSupplemental5Bit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCA.setSupplemental5Bit(enable))
    }

    object UPCE1 {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCE1.setEnable(enable))

        @JvmStatic
        fun setConvertToUpcA(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCE1.setConvertToUpcA(enable))

        @JvmStatic
        fun setPreamble(value: UpcE1Type.PreambleType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCE1.setPreamble(value))

        @JvmStatic
        fun setReportCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCE1.setReportCheckDigit(enable))
    }

    object UPCEan {
        @JvmStatic
        fun setReportEan8CheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setReportEan8CheckDigit(enable))

        @JvmStatic
        fun setReportEan13CheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setReportEan13CheckDigit(enable))

        @JvmStatic
        fun setSupplementalMode(value: UpcEanType.SupplementalModeType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setSupplementalMode(value))

        @JvmStatic
        fun setSupplementalAimIdFormat(value: UpcEanType.SupplementalAimIdFormatType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setSupplementalAimIdFormat(value))

        @JvmStatic
        fun setReducedQuietZone(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setReducedQuietZone(enable))

        @JvmStatic
        fun setBooklandEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setBooklandEnable(enable))

        @JvmStatic
        fun setBooklandFormat(value: UpcEanType.BooklandFormatType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setBooklandFormat(value))

        @JvmStatic
        fun setUccCouponExtend(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setUccCouponExtend(enable))

        @JvmStatic
        fun setCouponReport(value: UpcEanType.CouponReportType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setCouponReport(value))

        @JvmStatic
        fun setIssnEan(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setIssnEan(enable))

        @JvmStatic
        fun setTranslateUpcAToEan13(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setTranslateUpcAToEan13(enable))

        @JvmStatic
        fun setSupplementalRedundancy(value: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setSupplementalRedundancy(value))

        @JvmStatic
        fun setEanSupplemental2(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setEanSupplemental2(enable))

        @JvmStatic
        fun setEanSupplemental5(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setEanSupplemental5(enable))

        @JvmStatic
        fun setEan8ReadSupplementals(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setEan8ReadSupplementals(enable))

        @JvmStatic
        fun setEan13ReadSupplementals(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setEan13ReadSupplementals(enable))

        @JvmStatic
        fun setEan8Supplemental2(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setEan8Supplemental2(enable))

        @JvmStatic
        fun setEan13Supplemental2(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setEan13Supplemental2(enable))

        @JvmStatic
        fun setEan8Supplemental5(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setEan8Supplemental5(enable))

        @JvmStatic
        fun setEan13Supplemental5(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCEan.setEan13Supplemental5(enable))
    }

    object UPCE {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCE.setEnable(enable))

        @JvmStatic
        fun setConvertToUpcA(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCE.setConvertToUpcA(enable))

        @JvmStatic
        fun setPreamble(value: UpcEType.PreambleType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCE.setPreamble(value))

        @JvmStatic
        fun setReportCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCE.setReportCheckDigit(enable))

        @JvmStatic
        fun setSupplemental2Bit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCE.setSupplemental2Bit(enable))

        @JvmStatic
        fun setSupplemental5Bit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UPCE.setSupplemental5Bit(enable))
    }

    object UpuFicsPostal {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.UpuFicsPostal.setEnable(enable))
    }

    object USPlanet {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.USPlanet.setEnable(enable))

        @JvmStatic
        fun setReportCheckDigit(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.USPlanet.setReportCheckDigit(enable))
    }

    object USPostnet {
        @JvmStatic
        fun setEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.USPostnet.setEnable(enable))
    }

    object General {
        @JvmStatic
        fun findMe(): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.General.findMe())

        @JvmStatic
        fun setAimer(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.General.setAimer(enable))

        @JvmStatic
        fun setIllumination(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.General.setIllumination(enable))

        @JvmStatic
        fun setSound(type: SoundType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.General.setSound(type))

        @JvmStatic
        fun setVibrate(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.General.setVibrate(enable))

        @JvmStatic
        fun setLedEnable(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.General.setLedEnable(enable))

        @JvmStatic
        fun setSleepMode(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.General.setSleepMode(enable))

    }

    object ReaderParams {
        @JvmStatic
        fun setReadMode(value: ReaderType.ReadModeType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.ReaderParams.readMode(value))

        @JvmStatic
        fun setInverse1D(value: ReaderType.Inverse1DType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.ReaderParams.inverse1D(value))

        @JvmStatic
        fun setQuietZoneLevelFor1D(value: ReaderType.QuietZoneLevelType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.ReaderParams.quietZoneLevelFor1D(value))

        @JvmStatic
        fun setPoorQualityDecodeEffort(value: ReaderType.PoorQualityDecodeEffortType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.ReaderParams.poorQualityDecodeEffort(value))
    }

    object Firmware {
        /** value is in seconds, 1..10. */
        @JvmStatic
        fun setLaserOnTime(value: Int): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Firmware.laserOnTime(value))
    }

    object BasicDataFormat {
        @JvmStatic
        fun setTransmitCodeID(value: BasicFormatType.TransmitCodeIdType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.BasicDataFormat.transmitCodeID(value))

        @JvmStatic
        fun setEndChar(value: BasicFormatType.EndCharType): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.BasicDataFormat.endChar(value))

        @JvmStatic
        fun setSubString(value: String): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.BasicDataFormat.subString(value))

        @JvmStatic
        fun setRemoveFnc(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.BasicDataFormat.setRemoveFnc(enable))

        @JvmStatic
        fun setTranslateData(value: String): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.BasicDataFormat.setTranslateData(value))

        @JvmStatic
        fun setPrefixPostfixAsAsciiHex(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.BasicDataFormat.setPrefixPostfixAsAsciiHex(enable))

        /** Maximum length of prefix is 16 bytes. */
        @JvmStatic
        fun setPrefix(value: String): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.BasicDataFormat.setPrefix(value))

        /** Maximum length of postfix is 16 bytes. */
        @JvmStatic
        fun setPostfix(value: String): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.BasicDataFormat.setPostfix(value))
    }

    object Advanced {
        @JvmStatic
        fun setBatteryCallback(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Advanced.setBatteryCallback(enable))

        @JvmStatic
        fun setAutoHidReconnect(enable: Boolean): SettingCommand =
            SettingCommand.fromInternal(InternalSettings.Advanced.setAutoHidReconnect(enable))
    }
}
