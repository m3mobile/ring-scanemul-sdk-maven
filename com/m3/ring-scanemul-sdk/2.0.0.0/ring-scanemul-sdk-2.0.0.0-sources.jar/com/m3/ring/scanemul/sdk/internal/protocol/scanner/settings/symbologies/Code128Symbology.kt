package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.code128.Code128Type
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
internal object Code128Symbology {
    /* Ids */
    enum class Code128Ids(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerIds {
        @BindField("code128Enable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0x08.toByte()), totinfo = byteArrayOf(0x08.toByte())),

        @BindField("code128Length1")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH1(zebra = byteArrayOf(0xD1.toByte()), totinfo = byteArrayOf(0xF5.toByte(), 0x04.toByte())),

        @BindField("code128Length2")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH2(zebra = byteArrayOf(0xD2.toByte()), totinfo = byteArrayOf(0xF5.toByte(), 0x05.toByte())),

        @BindField("code128ReducedQuietZone")
        @BindValue(ValueType.ENUM, ReducedQuietZoneVal::class)
        REDUCED_QUIET_ZONE(zebra = byteArrayOf(0xF8.toByte(), 0x04.toByte(), 0xB8.toByte())),

        @BindField("code128IgnoreFNC4")
        @BindValue(ValueType.ENUM, IgnoreFNC4Val::class)
        IGNORE_FNC4(zebra = byteArrayOf(0xF8.toByte(), 0x04.toByte(), 0xE6.toByte())),

        @BindField("code128CheckISBTTable")
        @BindValue(ValueType.ENUM, CheckISBTTableVal::class)
        CHECK_ISBT_TABLE(zebra = byteArrayOf(0xF1.toByte(), 0x42.toByte())),

        @BindField("code128ISBT128ConcatMode")
        @BindValue(ValueType.ENUM, ISBT128ConcatModeVal::class)
        ISBT128_CONCAT_MODE(zebra = byteArrayOf(0xF1.toByte(), 0x41.toByte())),

        @BindField("code128SecurityLevel")
        @BindValue(ValueType.ENUM, SecurityLevelVal::class)
        SECURITY_LEVEL(zebra = byteArrayOf(0xF1.toByte(), 0xEF.toByte())),

        @BindField("code128EmulationMode")
        @BindValue(ValueType.ENUM, EmulationModeVal::class)
        EMULATION_MODE(zebra = byteArrayOf(0x7B.toByte()));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class ReducedQuietZoneVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class IgnoreFNC4Val(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class CheckISBTTableVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00))
    }

    @EnumNameMatch(external = Code128Type.ISBT128ConcatModeType::class)
    enum class ISBT128ConcatModeVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00)),
        AUTO(zebra = byteArrayOf(0x02))
    }

    @EnumNameMatch(external = Code128Type.SecurityType::class)
    enum class SecurityLevelVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        LEVEL_0(zebra = byteArrayOf(0x00)),
        LEVEL_1(zebra = byteArrayOf(0x01)),
        LEVEL_2(zebra = byteArrayOf(0x02)),
        LEVEL_3(zebra = byteArrayOf(0x03))
    }

    @EnableDisableEnum
    enum class EmulationModeVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00))
    }
}
