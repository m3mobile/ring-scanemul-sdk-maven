package com.m3.ring.scanemul.sdk.internal.transport.data.ble

import android.bluetooth.BluetoothGatt
import com.m3.ring.scanemul.sdk.internal.transport.data.core.dto.TransportRequestType
import com.m3.ring.scanemul.sdk.internal.transport.data.core.dto.TransportRequestResult
import com.m3.ring.scanemul.sdk.internal.transport.domain.ByteTransport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.flow.SharedFlow

// TODO 추후 BleByteTransport 구현
// 현재는 ByteTransport 인터페이스를 구현하는 빈 클래스 형태로 작성
internal class BleByteTransport(private val gatt: BluetoothGatt, private val scope: CoroutineScope) : ByteTransport {
    override fun startRead() {
        TODO("Not yet implemented")
    }

    override fun observeBinaryCommandData(): SharedFlow<ByteArray> {
        TODO("Not yet implemented")
    }

    override fun observeBarcodeData(): SharedFlow<ByteArray> {
        TODO("Not yet implemented")
    }

    override fun startWriteWorker() {
        TODO("Not yet implemented")
    }

    override fun requestWrite(data: ByteArray) {
        TODO("Not yet implemented")
    }

    override suspend fun requestWriteWithAck(data: ByteArray, requestType: TransportRequestType): Deferred<TransportRequestResult> {
        TODO("Not yet implemented")
    }

    override fun disconnect(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit) {
        TODO("Not yet implemented")
    }

    override fun observeDisconnect(): SharedFlow<Unit> {
        TODO("Not yet implemented")
    }
}
