package com.m3.ring.scanemul.sdk.api.listener

import com.m3.ring.scanemul.sdk.api.model.DecodedBarcode

interface DecodingDataListener {
    fun onReceive(decodedBarcode: DecodedBarcode)
}
