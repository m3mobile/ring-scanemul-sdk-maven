package com.m3.ring.scanemul.sdk.internal.transport.data.core

import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothSocket
import com.m3.ring.scanemul.sdk.internal.connection.data.SettingsLoadStateHolder
import com.m3.ring.scanemul.sdk.internal.device.state.DeviceStateStore
import com.m3.ring.scanemul.sdk.internal.transport.data.ble.BleByteTransport
import com.m3.ring.scanemul.sdk.internal.transport.data.spp.SppByteTransport
import kotlinx.coroutines.CoroutineScope

internal object DeviceProtocolChannelFactory {
    fun create(
        socket: BluetoothSocket,
        scope: CoroutineScope,
        deviceStateStore: DeviceStateStore,
        settingsLoadStateHolder: SettingsLoadStateHolder
    ): DeviceProtocolChannel {
        return DeviceProtocolChannel(SppByteTransport(socket, scope), deviceStateStore, settingsLoadStateHolder)
    }

    fun create(
        gatt: BluetoothGatt,
        scope: CoroutineScope,
        deviceStateStore: DeviceStateStore,
        settingsLoadStateHolder: SettingsLoadStateHolder
    ): DeviceProtocolChannel {
        return DeviceProtocolChannel(BleByteTransport(gatt, scope), deviceStateStore, settingsLoadStateHolder)
    }
}
