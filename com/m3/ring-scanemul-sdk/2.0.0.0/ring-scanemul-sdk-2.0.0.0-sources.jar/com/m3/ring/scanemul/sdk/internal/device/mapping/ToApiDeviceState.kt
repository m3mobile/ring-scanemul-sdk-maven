package com.m3.ring.scanemul.sdk.internal.device.mapping

import com.m3.ring.scanemul.sdk.api.model.DeviceInfo
import com.m3.ring.scanemul.sdk.api.model.DeviceState
import com.m3.ring.scanemul.sdk.api.model.device.BtModeType
import com.m3.ring.scanemul.sdk.api.model.device.ScannerIdType
import com.m3.ring.scanemul.sdk.api.model.device.VendorType
import com.m3.ring.scanemul.sdk.api.model.settings.basic.BasicFormat
import com.m3.ring.scanemul.sdk.api.model.settings.basic.BasicFormatType
import com.m3.ring.scanemul.sdk.api.model.settings.advanced.AdvancedSettings
import com.m3.ring.scanemul.sdk.api.model.settings.general.GeneralSettings
import com.m3.ring.scanemul.sdk.api.model.settings.general.SoundType
import com.m3.ring.scanemul.sdk.api.model.settings.reader.ReaderSettings
import com.m3.ring.scanemul.sdk.api.model.settings.reader.ReaderType
import com.m3.ring.scanemul.sdk.api.model.symbologies.Symbologies
import com.m3.ring.scanemul.sdk.api.model.symbologies.australian.AustralianVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.aztec.AztecVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.chinese2of5.Chinese2Of5Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.codabar.CodabarType
import com.m3.ring.scanemul.sdk.api.model.symbologies.codabar.CodabarVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.code11.Code11Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.code11.Code11Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.code128.Code128Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.code128.Code128Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.code39.Code39Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.code39.Code39Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.code93.Code93Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.composite.CompositeType
import com.m3.ring.scanemul.sdk.api.model.symbologies.composite.CompositeVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.datamatrix.DataMatrixType
import com.m3.ring.scanemul.sdk.api.model.symbologies.datamatrix.DataMatrixVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.discrete2of5.Discrete2Of5Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.dotcode.DotCodeType
import com.m3.ring.scanemul.sdk.api.model.symbologies.dotcode.DotCodeVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.ean13.Ean13Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.ean8.Ean8Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.gs1128.Gs1128Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.gs1databar14.Gs1DataBar14Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.gs1expanded.Gs1DataBarExpandedVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.gs1limited.Gs1DataBarLimitedType
import com.m3.ring.scanemul.sdk.api.model.symbologies.gs1limited.Gs1DataBarLimitedVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.hanxin.HanXinType
import com.m3.ring.scanemul.sdk.api.model.symbologies.hanxin.HanXinVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.interleaved2of5.Interleaved2Of5Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.interleaved2of5.Interleaved2Of5Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.isbt128.Isbt128Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.japanesepostal.JapanesePostalVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.korean3of5.Korean3Of5Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.matrix2of5.Matrix2Of5Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.maxicode.MaxiCodeVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.micropdf417.MicroPdf417Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.microqr.MicroQrCodeVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.msi.MsiType
import com.m3.ring.scanemul.sdk.api.model.symbologies.msi.MsiVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.netherland.NetherlandsKixVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.pdf417.Pdf417Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.qrcode.QrCodeVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.ukpostal.UkPostalVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.upca.UpcAType
import com.m3.ring.scanemul.sdk.api.model.symbologies.upca.UpcAVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.upce.UpcEType
import com.m3.ring.scanemul.sdk.api.model.symbologies.upce.UpcEVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.upce1.UpcE1Type
import com.m3.ring.scanemul.sdk.api.model.symbologies.upce1.UpcE1Vals
import com.m3.ring.scanemul.sdk.api.model.symbologies.upcean.UpcEanType
import com.m3.ring.scanemul.sdk.api.model.symbologies.upcean.UpcEanVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.upufics.UpuFicsPostalVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.usplanet.UsPlanetVals
import com.m3.ring.scanemul.sdk.api.model.symbologies.uspostnet.UsPostnetVals
import com.m3.ring.scanemul.sdk.internal.device.state.InternalDeviceState
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting

internal fun InternalDeviceState.toApiDeviceState(): DeviceState {
    return DeviceState(
        deviceInfo = DeviceInfo(
            name = this.name,
            macAddress = this.macAddress,
            model = this.fwSettingInfo.model,
            vendor = this.fwSettingInfo.vendor.toEnumExternal<VendorType>(),
            serialNumber = this.fwSettingInfo.serialNumber,
            fwVersion = this.fwSettingInfo.fwVersion,
            configVersion = this.fwSettingInfo.configVersion,
            releaseDate = this.fwSettingInfo.releaseDate,
            batteryPercent = this.fwSettingInfo.battery,
            scannerId = this.fwSettingInfo.scannerId.toEnumInternal<ScannerIdType>(),
            btMode = this.fwSettingInfo.mode.toEnumExternal<BtModeType>(),
        ),
        general = GeneralSettings(
            sound = this.fwSettingInfo.sound.toEnumExternal<SoundType>(),
            vibrateEnabled = this.fwSettingInfo.vibrate.toBoolExternal(),
            ledEnabled = this.fwSettingInfo.led.toBoolExternal(),
            aimEnabled = this.scannerSettingInfo.aim.toBoolExternal(),
            illuminationEnabled = this.scannerSettingInfo.illumination.toBoolExternal(),
            sleepModeEnabled = this.fwSettingInfo.sleepMode.toBoolExternal()
        ),
        symbologies = Symbologies(
            australianPostalVals = AustralianVals(this.scannerSettingInfo.australianPostalEnable.toBoolExternal()),
            aztecVals = AztecVals(this.scannerSettingInfo.aztecEnable.toBoolExternal()),
            chinese2Of5Vals = Chinese2Of5Vals(this.scannerSettingInfo.chinese2Of5Enable.toBoolExternal()),
            codabarVals = CodabarVals(
                enabled = this.scannerSettingInfo.codabarEnable.toBoolExternal(),
                length1 = this.scannerSettingInfo.codabarLength1?.value,
                length2 = this.scannerSettingInfo.codabarLength2?.value,
                clsiEditing = this.scannerSettingInfo.codabarCLSIEditing.toBoolExternal(),
                notisEditing = this.scannerSettingInfo.codabarNOTISEditing.toBoolExternal(),
                securityLevel = this.scannerSettingInfo.codabarSecurityLevel.toEnumExternal<CodabarType.SecurityType>()
            ),
            code11Vals = Code11Vals(
                enabled = this.scannerSettingInfo.code11Enable.toBoolExternal(),
                length1 = this.scannerSettingInfo.code11Length1?.value,
                length2 = this.scannerSettingInfo.code11Length2?.value,
                reportCheckDigit = this.scannerSettingInfo.code11ReportCheckDigit.toBoolExternal(),
                verifyCheckDigit = this.scannerSettingInfo.code11VerifyCheckDigit.toEnumExternal<Code11Type.VerifyCheckDigitType>()
            ),
            code39Vals = Code39Vals(
                enabled = this.scannerSettingInfo.code39Enable.toBoolExternal(),
                triopticCode39 = this.scannerSettingInfo.code39TriopticCode39.toBoolExternal(),
                length1 = this.scannerSettingInfo.code39Length1?.value,
                length2 = this.scannerSettingInfo.code39Length2?.value,
                reducedQuietZone = this.scannerSettingInfo.code39ReducedQuietZone.toBoolExternal(),
                convertToCode32 = this.scannerSettingInfo.code39ConvertToCode32.toBoolExternal(),
                fullAscii = this.scannerSettingInfo.code39FullAscii.toBoolExternal(),
                reportCheckDigit = this.scannerSettingInfo.code39ReportCheckDigit.toBoolExternal(),
                reportCode32Prefix = this.scannerSettingInfo.code39ReportCode32Prefix.toBoolExternal(),
                securityLevel = this.scannerSettingInfo.code39SecurityLevel.toEnumExternal<Code39Type.SecurityType>(),
                verifyCheckDigit = this.scannerSettingInfo.code39VerifyCheckDigit.toBoolExternal()
            ),
            code93Vals = Code93Vals(
                enabled = this.scannerSettingInfo.code93Enable.toBoolExternal(),
                length1 = this.scannerSettingInfo.code93Length1?.value,
                length2 = this.scannerSettingInfo.code93Length2?.value
            ),
            code128Vals = Code128Vals(
                enabled = this.scannerSettingInfo.code128Enable.toBoolExternal(),
                length1 = this.scannerSettingInfo.code128Length1?.value,
                length2 = this.scannerSettingInfo.code128Length2?.value,
                reducedQuietZone = this.scannerSettingInfo.code128ReducedQuietZone.toBoolExternal(),
                ignoreFnc4 = this.scannerSettingInfo.code128IgnoreFNC4.toBoolExternal(),
                checkIsbtTable = this.scannerSettingInfo.code128CheckISBTTable.toBoolExternal(),
                isbt128ConcatMode = this.scannerSettingInfo.code128ISBT128ConcatMode.toEnumExternal<Code128Type.ISBT128ConcatModeType>(),
                securityLevel = this.scannerSettingInfo.code128SecurityLevel.toEnumExternal<Code128Type.SecurityType>(),
                emulationMode = this.scannerSettingInfo.code128EmulationMode.toBoolExternal()
            ),
            compositeVals = CompositeVals(
                enabled = this.scannerSettingInfo.compositeEnable.toBoolExternal(),
                compositeABEnabled = this.scannerSettingInfo.compositeAbEnable.toBoolExternal(),
                compositeCEnabled = this.scannerSettingInfo.compositeCEnable.toBoolExternal(),
                tlc39Enable = this.scannerSettingInfo.compositeTLC39Enable.toBoolExternal(),
                upcCompositeMode = this.scannerSettingInfo.compositeUPCCompositeMode.toEnumExternal<CompositeType.UPCCompositeModeType>()
            ),
            dataMatrixVals = DataMatrixVals(
                enabled = this.scannerSettingInfo.dataMatrixEnable.toBoolExternal(),
                inverse = this.scannerSettingInfo.dataMatrixInverse.toEnumExternal<DataMatrixType.InverseType>(),
                decodeMirrorImages = this.scannerSettingInfo.dataMatrixDecodeMirrorImages.toEnumExternal<DataMatrixType.DecodeMirrorImagesType>(),
                gs1DataMatrix = this.scannerSettingInfo.dataMatrixGS1DataMatrix.toBoolExternal()
            ),
            discrete2Of5Vals = Discrete2Of5Vals(
                enabled = this.scannerSettingInfo.discrete2Of5Enable.toBoolExternal(),
                length1 = this.scannerSettingInfo.discrete2Of5Length1?.value,
                length2 = this.scannerSettingInfo.discrete2Of5Length2?.value
            ),
            dotCodeVals = DotCodeVals(
                enabled = this.scannerSettingInfo.dotCodeEnable.toBoolExternal(),
                inverse = this.scannerSettingInfo.dotCodeInverse.toEnumExternal<DotCodeType.InverseType>(),
                mirror = this.scannerSettingInfo.dotCodeMirror.toEnumExternal<DotCodeType.MirrorType>(),
                prioritize = this.scannerSettingInfo.dotCodePrioritize.toBoolExternal()
            ),
            ean8Vals = Ean8Vals(
                enabled = this.scannerSettingInfo.ean8Enable.toBoolExternal()
            ),
            ean13Vals = Ean13Vals(
                enabled = this.scannerSettingInfo.ean13Enable.toBoolExternal()
            ),
            gs1DataBar14Vals = Gs1DataBar14Vals(
                enabled = this.scannerSettingInfo.gs1Databar14Enable.toBoolExternal()
            ),
            gs1DataBarExpandedVals = Gs1DataBarExpandedVals(
                enabled = this.scannerSettingInfo.gs1DatabarExpandedEnable.toBoolExternal()
            ),
            gs1DataBarLimitedVals = Gs1DataBarLimitedVals(
                enabled = this.scannerSettingInfo.gs1DataBarLimitedEnable.toBoolExternal(),
                securityLevel = this.scannerSettingInfo.gs1DataBarLimitedSecurityLevel.toEnumExternal<Gs1DataBarLimitedType.SecurityType>()
            ),
            gs1128Vals = Gs1128Vals(
                enabled = this.scannerSettingInfo.gs1128Enable.toBoolExternal()
            ),
            hanXinVals = HanXinVals(
                enabled = this.scannerSettingInfo.hanXinEnable.toBoolExternal(),
                inverse = this.scannerSettingInfo.hanXinInverse.toEnumExternal<HanXinType.InverseType>()
            ),
            interleaved2Of5Vals = Interleaved2Of5Vals(
                enabled = this.scannerSettingInfo.interleaved2Of5Enable.toBoolExternal(),
                length1 = this.scannerSettingInfo.interleaved2Of5Length1?.value,
                length2 = this.scannerSettingInfo.interleaved2Of5Length2?.value,
                checkDigit = this.scannerSettingInfo.interleaved2Of5CheckDigit.toEnumExternal<Interleaved2Of5Type.CheckDigitType>(),
                reportCheckDigit = this.scannerSettingInfo.interleaved2Of5ReportCheckDigit.toBoolExternal(),
                securityLevel = this.scannerSettingInfo.interleaved2Of5SecurityLevel.toEnumExternal<Interleaved2Of5Type.SecurityType>(),
                convertItf14ToEan13 = this.scannerSettingInfo.interleaved2Of5ConvertITF14ToEAN13.toBoolExternal(),
                reducedQuietZone = this.scannerSettingInfo.interleaved2Of5ReducedQuietZone.toBoolExternal()
            ),
            isbt128Vals = Isbt128Vals(
                enabled = this.scannerSettingInfo.isbt128Enable.toBoolExternal()
            ),
            japanesePostalVals = JapanesePostalVals(
                enabled = this.scannerSettingInfo.japanesePostalEnable.toBoolExternal()
            ),
            korean3Of5Vals = Korean3Of5Vals(
                enabled = this.scannerSettingInfo.korean3Of5Enable.toBoolExternal()
            ),
            matrix2Of5Vals = Matrix2Of5Vals(
                enabled = this.scannerSettingInfo.matrix2Of5Enable.toBoolExternal(),
                length1 = this.scannerSettingInfo.matrix2Of5Length1?.value,
                length2 = this.scannerSettingInfo.matrix2Of5Length2?.value,
                redundancy = this.scannerSettingInfo.matrix2Of5Redundancy.toBoolExternal(),
                reportCheckDigit = this.scannerSettingInfo.matrix2Of5ReportCheckDigit.toBoolExternal(),
                verifyCheckDigit = this.scannerSettingInfo.matrix2Of5VerifyCheckDigit.toBoolExternal()
            ),
            maxiCodeVals = MaxiCodeVals(
                enabled = this.scannerSettingInfo.maxicodeEnable.toBoolExternal()
            ),
            microPdf417Vals = MicroPdf417Vals(
                enabled = this.scannerSettingInfo.microPdf417Enable.toBoolExternal()
            ),
            microQrCodeVals = MicroQrCodeVals(
                enabled = this.scannerSettingInfo.microQrCodeEnable.toBoolExternal()
            ),
            msiVals = MsiVals(
                enabled = this.scannerSettingInfo.msiEnable.toBoolExternal(),
                length1 = this.scannerSettingInfo.msiLength1?.value,
                length2 = this.scannerSettingInfo.msiLength2?.value,
                checkDigit = this.scannerSettingInfo.msiCheckDigit.toEnumExternal<MsiType.CheckDigitType>(),
                checkDigitScheme = this.scannerSettingInfo.msiCheckDigitScheme.toEnumExternal<MsiType.CheckDigitSchemeType>(),
                reportCheckDigit = this.scannerSettingInfo.msiReportCheckDigit.toBoolExternal()
            ),
            netherlandsKixVals = NetherlandsKixVals(
                enabled = this.scannerSettingInfo.netherlandsKixEnable.toBoolExternal()
            ),
            pdf417Vals = Pdf417Vals(
                enabled = this.scannerSettingInfo.pdf417Enable.toBoolExternal()
            ),
            qrCodeVals = QrCodeVals(
                enabled = this.scannerSettingInfo.qrCodeEnable.toBoolExternal()
            ),
            ukPostalVals = UkPostalVals(
                enabled = this.scannerSettingInfo.ukPostalEnable.toBoolExternal(),
                reportCheckDigit = this.scannerSettingInfo.ukPostalReportCheckDigit.toBoolExternal()
            ),
            upcAVals = UpcAVals(
                enabled = this.scannerSettingInfo.upcaEnable.toBoolExternal(),
                reportCheckDigit = this.scannerSettingInfo.upcaReportCheckDigit.toBoolExternal(),
                preamble = this.scannerSettingInfo.upcaPreamble.toEnumExternal<UpcAType.PreambleType>(),
                upcA2BitsSupplementals = this.scannerSettingInfo.upca2BitsSupplementals.toBoolExternal(),
                upcA5BitsSupplementals = this.scannerSettingInfo.upca5BitsSupplementals.toBoolExternal()
            ),
            upcE1Vals = UpcE1Vals(
                enabled = this.scannerSettingInfo.upcE1Enable.toBoolExternal(),
                convertToUpcA = this.scannerSettingInfo.upcE1ConvertToUpcA.toBoolExternal(),
                preamble = this.scannerSettingInfo.upcE1Preamble.toEnumExternal<UpcE1Type.PreambleType>(),
                reportCheckDigit = this.scannerSettingInfo.upcE1ReportCheckDigit.toBoolExternal()
            ),
            upcEanVals = UpcEanVals(
                reportEan8CheckDigit = this.scannerSettingInfo.upcEanReportEan8CheckDigit.toBoolExternal(),
                reportEan13CheckDigit = this.scannerSettingInfo.upcEanReportEan13CheckDigit.toBoolExternal(),
                supplementalMode = this.scannerSettingInfo.upcEanSupplementalMode.toEnumExternal<UpcEanType.SupplementalModeType>(),
                supplementalAimIdFormat = this.scannerSettingInfo.upcEanSupplementalAimIdFormat.toEnumExternal<UpcEanType.SupplementalAimIdFormatType>(),
                reducedQuietZone = this.scannerSettingInfo.upcEanReducedQuietZone.toBoolExternal(),
                booklandEnable = this.scannerSettingInfo.upcEanBooklandEnable.toBoolExternal(),
                booklandFormat = this.scannerSettingInfo.upcEanBooklandFormat.toEnumExternal<UpcEanType.BooklandFormatType>(),
                uccCouponExtend = this.scannerSettingInfo.upcEanUccCouponExtend.toBoolExternal(),
                couponReport = this.scannerSettingInfo.upcEanCouponReport.toEnumExternal<UpcEanType.CouponReportType>(),
                issnEan = this.scannerSettingInfo.upcEanIssnEan.toBoolExternal(),
                translateUpcAToEan13 = this.fwSettingInfo.upcaToEan13.toBoolExternal(),
                supplementalRedundancy = this.scannerSettingInfo.upcEanSupplementalRedundancy?.value,
                supplemental2 = this.scannerSettingInfo.upcEanSupplemental2.toBoolExternal(),
                supplemental5 = this.scannerSettingInfo.upcEanSupplemental5.toBoolExternal(),
                ean8ReadSupplements = this.scannerSettingInfo.upcEan8ReadSupplements.toBoolExternal(),
                ean13ReadSupplements = this.scannerSettingInfo.upcEan13ReadSupplements.toBoolExternal(),
                ean8Supplemental2 = this.scannerSettingInfo.upcEan8Supplemental2.toBoolExternal(),
                ean13Supplemental2 = this.scannerSettingInfo.upcEan13Supplemental2.toBoolExternal(),
                ean8Supplemental5 = this.scannerSettingInfo.upcEan8Supplemental5.toBoolExternal(),
                ean13Supplemental5 = this.scannerSettingInfo.upcEan13Supplemental5.toBoolExternal()
            ),
            upcEVals = UpcEVals(
                enabled = this.scannerSettingInfo.upceEnable.toBoolExternal(),
                convertToUpcA = this.scannerSettingInfo.upceConvertToUpcA.toBoolExternal(),
                preamble = this.scannerSettingInfo.upcePreamble.toEnumExternal<UpcEType.PreambleType>(),
                reportCheckDigit = this.scannerSettingInfo.upceReportCheckDigit.toBoolExternal(),
                upcE2BitsSupplementals = this.scannerSettingInfo.upce2BitsSupplementals.toBoolExternal(),
                upcE5BitsSupplementals = this.scannerSettingInfo.upce5BitsSupplementals.toBoolExternal()
            ),
            upuFicsPostalVals = UpuFicsPostalVals(
                enabled = this.scannerSettingInfo.upuFicsPostalEnable.toBoolExternal()
            ),
            usPlanetVals = UsPlanetVals(
                enabled = this.scannerSettingInfo.usPlanetEnable.toBoolExternal(),
                reportCheckDigit = this.scannerSettingInfo.usPlanetReportCheckDigit.toBoolExternal()
            ),
            usPostnetVals = UsPostnetVals(
                enabled = this.scannerSettingInfo.usPostnetEnable.toBoolExternal()
            )
        ),
        readerSettings = ReaderSettings(
            readMode = this.fwSettingInfo.readMode.toEnumExternal<ReaderType.ReadModeType>(),
            laserOnTime = this.fwSettingInfo.laserOnTime
                ?.takeIf(FwSetting.LaserOnTime::isValid),
            inverse1D = this.scannerSettingInfo.readerInverse1D.toEnumExternal<ReaderType.Inverse1DType>(),
            quietZoneLevelFor1D = this.scannerSettingInfo.readerQuietZoneLevelFor1D.toEnumExternal<ReaderType.QuietZoneLevelType>(),
            poorQualityDecodeEffort = this.scannerSettingInfo.readerPoorQualityDecodeEffort.toEnumExternal<ReaderType.PoorQualityDecodeEffortType>()
        ),
        basicFormat = BasicFormat(
            transmitCodeId = this.scannerSettingInfo.transmitCodeId.toEnumExternal<BasicFormatType.TransmitCodeIdType>(),
            endChar = this.fwSettingInfo.endChar.toEnumExternal<BasicFormatType.EndCharType>(),
            substringFormation = this.fwSettingInfo.substring,
            removeFnc = this.fwSettingInfo.removeFNC.toBoolExternal(),
            translateData = this.fwSettingInfo.translateData,
            prefixPostfixAsAsciiHex = this.fwSettingInfo.prePostHex.toBoolExternal(),
            prefix = this.fwSettingInfo.prefix,
            postfix = this.fwSettingInfo.postfix
        ),
        advancedSettings = AdvancedSettings(
            batteryCallback = this.fwSettingInfo.batteryCallback.toBoolExternal(),
            autoHidReconnect = this.fwSettingInfo.autoHidReconnect.toBoolExternal()
        )
    )
}
