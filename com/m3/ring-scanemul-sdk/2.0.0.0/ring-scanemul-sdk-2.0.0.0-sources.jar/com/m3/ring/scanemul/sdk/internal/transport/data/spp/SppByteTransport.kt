package com.m3.ring.scanemul.sdk.internal.transport.data.spp

import android.bluetooth.BluetoothSocket
import com.m3.ring.scanemul.sdk.internal.common.Logger
import com.m3.ring.scanemul.sdk.internal.common.util.CmdUtils
import com.m3.ring.scanemul.sdk.internal.common.util.Extensions.toHexString
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.AccessorCommandType
import com.m3.ring.scanemul.sdk.internal.transport.data.core.dto.TransportRequestType
import com.m3.ring.scanemul.sdk.internal.transport.data.core.dto.TransportRequestResult
import com.m3.ring.scanemul.sdk.internal.transport.data.core.dto.WriteRequest
import com.m3.ring.scanemul.sdk.internal.transport.domain.ByteTransport
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import java.io.IOException

/**
 * SppByteTransport는 SPP 프로토콜을 사용하여
 * BluetoothSocket을 통해 데이터를 전송하고 수신하는 기능을 제공합니다.
 *
 * @param socket 통신을 위해 연결 이후 생성된 소켓
 * @param scope 코루틴 스코프
 */
internal class SppByteTransport(private val socket: BluetoothSocket, private val scope: CoroutineScope) : ByteTransport {
    private val inputStream = socket.inputStream
    private val outputStream = socket.outputStream

    private var pendingResponseType: Byte? = null //현재 ACK/NACK 응답을 기다리고 있는 명령어의 예상 응답 타입(GET_RESPONSE or SET_RESPONSE)
    private var pendingResponseDeferred: CompletableDeferred<TransportRequestResult>? = null //현재 ACK/NACK 응답을 기다리고 있는 명령어의 CompletableDeferred 객체
    private var pendingRequestType: TransportRequestType? = null //현재 응답을 기다리고 있는 요청의 목적

    private val binaryCommandData = MutableSharedFlow<ByteArray>(
        extraBufferCapacity = 64
    )

    private val barcodeData = MutableSharedFlow<ByteArray>(
        extraBufferCapacity = 64
    )

    private val disconnectEvent = MutableSharedFlow<Unit>(
        replay = 0,
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    private val writeSetterQueue = Channel<WriteRequest>(Channel.UNLIMITED)
    private val writeAckMutex = Mutex()

    init {
        startRead()
        startWriteWorker()
    }

    /**
     * 이 메서드는 소켓의 InputStream을 읽기 시작하여 수신 루프를 활성화합니다.
     * 연결이 유지되는 동안 내부적으로 지속적으로 데이터를 읽습니다.
     * 이 메서드는 별도의 코루틴으로 동작하며, 수신된 데이터는
     * [binaryCommandData] 또는 [barcodeData] SharedFlow로 방출됩니다.
     * 만약 연결이 끊어지거나 읽기 중 오류가 발생하면
     * [disconnectEvent] SharedFlow로 이벤트를 방출합니다.
     */
    override fun startRead() {
        scope.launch {
            val buffer = ByteArray(1024)

            while (isActive) {
                try {
                    val bytesRead = inputStream.read(buffer)
                    if (bytesRead == -1) {
                        closeWriteSetterQueue()
                        disconnectEvent.tryEmit(Unit)
                        return@launch
                    }

                    if (bytesRead > 0) {
                        val value = buffer.copyOfRange(0, bytesRead)
                        Logger.i(msg = "=========== Received: ${value.toHexString()} ===========")

                        handleReceivedData(value)
                    }
                } catch (e: IOException) {
                    Logger.e(msg = "=========== Read failed: ${e.message} ===========")
                    closeWriteSetterQueue()
                    disconnectEvent.tryEmit(Unit)
                    break
                }
            }
        }
    }

    override fun observeBinaryCommandData(): SharedFlow<ByteArray> {
        return binaryCommandData
    }

    override fun observeBarcodeData(): SharedFlow<ByteArray> {
        return barcodeData
    }

    /**
     * Write Queue에 적재된 명령어를 순차적으로 전송하는 워커를 시작합니다.
     * 이 메서드는 별도의 코루틴으로 동작하며, 요청된 명령어를 순차적으로 전송합니다.
     * ACK/NACK 응답을 기다리는 경우, 해당 요청에 대한 CompletableDeferred 객체를 사용하여 응답을 처리합니다.
     */
    override fun startWriteWorker() {
        scope.launch {
            for (req in writeSetterQueue) {
                req.deferred?.let {
                    registerPendingWriteResponse(req, it)
                }

                try {
                    outputStream.write(req.data)
                    outputStream.flush()
                    Logger.i(msg = "=========== Write: ${req.data.toHexString()} ===========")

                    req.deferred?.let {
                        withTimeout(5_000) { //요청이 5초 이내에 완료되지 않으면 타임아웃
                            it.await()
                        }
                    }
                } catch (e: Exception) {
                    Logger.e(msg = "=========== Write failed: ${e.message} ===========")
                    req.deferred?.let {
                        clearPendingWriteResponse(it)
                        it.complete(TransportRequestResult.FAILED)
                    }
                }
            }
        }
    }

    /**
     * 데이터를 전송하기 위해 Write Queue에 요청을 추가합니다.
     * 이 메서드는 ACK/NACK 응답을 기다리지 않습니다.
     */
    override fun requestWrite(data: ByteArray) {
        writeSetterQueue.trySend(WriteRequest(data))
    }

    /**
     * ACK/NACK 패킷을 기다리는 CompletableDeferred 객체를 추가하고, 데이터를 전송합니다.
     * 이 메서드는 ACK/NACK 응답을 기다리는 비동기 작업을 반환합니다.
     */
    override suspend fun requestWriteWithAck(data: ByteArray, requestType: TransportRequestType): Deferred<TransportRequestResult> {
        val deferred = CompletableDeferred<TransportRequestResult>()
        writeSetterQueue.trySend(WriteRequest(data, deferred, requestType))
        return deferred
    }

    override fun disconnect(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit) {
        try {
            closeWriteSetterQueue()
            closeSocket()
            onSuccess() // 연결 해제 성공 콜백 호출
            Logger.i(msg = "=========== Disconnect Success ===========")
        } catch (e: Exception) {
            onFailure("Disconnect failed: ${e.message}")
            Logger.e(msg = "=========== Disconnect Failed ===========")
        }
    }


    private fun closeWriteSetterQueue() {
        writeSetterQueue.close()

        // ACK/응답 대기자 전부 false로 종료
        scope.launch {
            val deferred = writeAckMutex.withLock {
                val current = pendingResponseDeferred
                pendingResponseType = null
                pendingResponseDeferred = null
                pendingRequestType = null
                current
            }
            deferred?.complete(TransportRequestResult.FAILED)
        }
    }

    private fun closeSocket() {
        outputStream?.close()
        inputStream?.close()
        socket.close()
    }

    /**
     * 이 메서드는 연결이 끊어졌을 때 호출되는 SharedFlow를 반환합니다.
     * @return 연결 해제 이벤트 스트림
     */
    override fun observeDisconnect(): SharedFlow<Unit> {
        return disconnectEvent
    }

    /**
     * 수신된 데이터를 처리합니다.
     * 이 메서드는 수신된 데이터가 바코드 데이터인지, 바이너리 명령어인지 판별하고
     * 각각의 SharedFlow로 방출합니다.
     * 또한, ACK/NACK 패킷인 경우에는 해당 패킷을 처리하는 메서드를 호출합니다.
     */
    private suspend fun handleReceivedData(value: ByteArray) {
        inspectPendingRequestResponse(value)?.let { result ->
            failPendingRequest(result, value)
            return
        }

        // 디코딩된 바코드 데이터인지 판별하여 해당하는 SharedFlow로 방출
        if (!CmdUtils.isBinaryCommand(value)) {
            barcodeData.emit(value)
            return
        }

        // 바이너리 명령어인 경우, 체크섬 유효성 검사
        if (!CmdUtils.isChecksumValid(value)) return

        val matchedPendingResponse = matchExpectedPendingResponse(value)
        if (matchedPendingResponse != null) {
            val result = getPendingResponseResult(matchedPendingResponse.responseType, value)
            matchedPendingResponse.deferred.complete(result)

            if (matchedPendingResponse.responseType != AccessorCommandType.GET_RESPONSE.value) {
                // GET_RESPONSE는 일반적으로 요청한 데이터가 담긴 패킷이므로, 명령어 데이터로도 활용될 수 있지만 SET_RESPONSE는 단순 ACK/NACK 패킷이므로 명령어 데이터로 방출하지 않음
                return
            }
        }

        binaryCommandData.emit(value)
    }

    /**
     * 현재 pending 요청 타입에 따라, 일반 수신 흐름에 앞서 예외 응답 여부를 판정합니다.
     * 예외 응답이 아니면 null을 반환하고 일반 처리 흐름을 계속합니다.
     */
    private suspend fun inspectPendingRequestResponse(packet: ByteArray): TransportRequestResult? {
        return when (readPendingRequestType()) {
            TransportRequestType.SCANNER_GET_ALL -> inspectScannerGetAllResponse(packet)
            TransportRequestType.FIRMWARE_GET_ALL -> null
            TransportRequestType.SET_SETTING -> null
            null -> null
        }
    }

    /**
     * 스캐너 전체 설정 조회 응답의 예외 케이스를 판정합니다.
     * 현재는 첫 바이트가 F1이 아닌 raw scanner 응답을 transport protocol mismatch로 간주합니다.
     */
    private fun inspectScannerGetAllResponse(packet: ByteArray): TransportRequestResult? {
        if (!CmdUtils.isBinaryCommand(packet)) {
            return TransportRequestResult.TRANSPORT_PROTOCOL_MISMATCH
        }

        return null
    }

    /**
     * 예외 응답으로 판정된 경우 현재 pending 요청을 정리하고 결과를 완료합니다.
     */
    private suspend fun failPendingRequest(result: TransportRequestResult, packet: ByteArray) {
        val deferred = clearPendingRequest() ?: return

        Logger.e(
            msg = "=========== Pending request failed: result=$result, packet=${packet.toHexString()} ==========="
        )
        deferred.complete(result)
    }

    private suspend fun readPendingRequestType(): TransportRequestType? =
        writeAckMutex.withLock { pendingRequestType }

    private suspend fun clearPendingRequest(): CompletableDeferred<TransportRequestResult>? =
        writeAckMutex.withLock {
            val current = pendingResponseDeferred
            pendingResponseType = null
            pendingResponseDeferred = null
            pendingRequestType = null
            current
        }

    /**
     * 현재 대기 중인 pending 응답과 수신 패킷이 일치하는지 확인하고, 일치하면 pending 상태를 회수합니다.
     */
    private suspend fun matchExpectedPendingResponse(packet: ByteArray): MatchedPendingResponse? {
        val responseType = packet.getOrNull(2) ?: return null
        var deferred: CompletableDeferred<TransportRequestResult>? = null

        writeAckMutex.withLock {
            if (pendingResponseType == responseType) {
                deferred = pendingResponseDeferred
                pendingResponseType = null
                pendingResponseDeferred = null
                pendingRequestType = null
            }
        }

        val currentDeferred = deferred ?: return null
        return MatchedPendingResponse(
            responseType = responseType,
            deferred = currentDeferred
        )
    }

    private fun getPendingResponseResult(
        responseType: Byte,
        packet: ByteArray
    ): TransportRequestResult {
        return when (responseType) {
            AccessorCommandType.SET_RESPONSE.value ->
                if (packet.getOrNull(4) == 0x01.toByte()) {
                    TransportRequestResult.SUCCESS
                } else {
                    TransportRequestResult.FAILED
                }

            AccessorCommandType.GET_RESPONSE.value -> TransportRequestResult.SUCCESS
            else -> TransportRequestResult.FAILED
        }
    }

    private suspend fun registerPendingWriteResponse(request: WriteRequest, deferred: CompletableDeferred<TransportRequestResult>) {
        val expectedResponseType = when (request.data.getOrNull(2)) {
            AccessorCommandType.GET.value -> AccessorCommandType.GET_RESPONSE.value
            AccessorCommandType.SET.value -> AccessorCommandType.SET_RESPONSE.value
            else -> null
        } ?: return

        writeAckMutex.withLock {
            pendingResponseType = expectedResponseType
            pendingResponseDeferred = deferred
            pendingRequestType = request.requestType
        }
    }

    private suspend fun clearPendingWriteResponse(deferred: CompletableDeferred<TransportRequestResult>) {
        writeAckMutex.withLock {
            if (pendingResponseDeferred == deferred) {
                pendingResponseType = null
                pendingResponseDeferred = null
                pendingRequestType = null
            }
        }
    }
}
