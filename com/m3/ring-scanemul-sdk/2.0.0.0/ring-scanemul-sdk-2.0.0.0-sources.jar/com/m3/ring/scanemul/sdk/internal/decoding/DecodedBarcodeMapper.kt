package com.m3.ring.scanemul.sdk.internal.decoding

import com.m3.ring.scanemul.sdk.api.model.DecodedBarcode
import com.m3.ring.scanemul.sdk.internal.device.state.FwSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting

internal object DecodedBarcodeMapper {
    private const val BARCODE_TYPE_LENGTH = 2
    private const val UNKNOWN_TYPE = "unknown"
    private val BARCODE_TYPE_PARSE_SKIP_PREFIXES = listOf(
        "{M3DS1}".encodeToByteArray()
    )

    fun map(rawData: ByteArray, fwSettingInfo: FwSettingInfo): DecodedBarcode {
        val barcodeTypeExpected =
            fwSettingInfo.mode == FwSetting.BtModeSetting.SPP &&
                    fwSettingInfo.enableSppBarcodeTypeOutput == FwSetting.SppBarcodeTypeOutput.ENABLE
        val shouldParseBarcodeType =
            barcodeTypeExpected && !shouldSkipBarcodeTypeParsing(rawData)

        val parsed = if (shouldParseBarcodeType) {
            parseBarcodeType(rawData, fwSettingInfo.vendor)
        } else {
            ParsedBarcodeType(payload = rawData)
        }

        val data = parsed.payload.decodeToString().trimEnd('\u0000')
        return DecodedBarcode(
            data = data,
            rawData = parsed.payload,
            type = parsed.entry?.displayName ?: if (shouldParseBarcodeType) UNKNOWN_TYPE else null,
            typeId = parsed.entry?.typeId,
            endChar = resolveEndChar(data, fwSettingInfo.endChar)
        )
    }

    private fun parseBarcodeType(
        rawData: ByteArray,
        vendor: FwSetting.Vendor?
    ): ParsedBarcodeType {
        if (rawData.size < BARCODE_TYPE_LENGTH) {
            return ParsedBarcodeType(payload = rawData)
        }

        val payloadEndIndex = rawData.size - BARCODE_TYPE_LENGTH
        val code = rawData
            .copyOfRange(payloadEndIndex, rawData.size)
            .decodeToString()
            .toIntOrNull(16)
        val entry = when (vendor) {
            FwSetting.Vendor.ZEBRA -> ZBarcodeTypeTable.entryFor(code)
            FwSetting.Vendor.TOTINFO -> TBarcodeTypeTable.entryFor(code)
            null -> null
        }

        return ParsedBarcodeType(
            payload = rawData.copyOfRange(0, payloadEndIndex),
            entry = entry
        )
    }

    private fun resolveEndChar(
        data: String,
        endCharSetting: FwSetting.EndCharSetting?
    ): String {
        val configuredEndChar = when (endCharSetting) {
            FwSetting.EndCharSetting.ENTER -> "\n"
            FwSetting.EndCharSetting.TAB -> "\t"
            FwSetting.EndCharSetting.NONE,
            null -> ""
        }
        return configuredEndChar.takeIf(data::endsWith).orEmpty()
    }

    private data class ParsedBarcodeType(
        val payload: ByteArray,
        val entry: BarcodeTypeTableEntry? = null
    )

    private fun shouldSkipBarcodeTypeParsing(rawData: ByteArray): Boolean =
        BARCODE_TYPE_PARSE_SKIP_PREFIXES.any { prefix -> rawData.startsWith(prefix) }

    private fun ByteArray.startsWith(prefix: ByteArray): Boolean =
        size >= prefix.size && prefix.indices.all { index -> this[index] == prefix[index] }
}
