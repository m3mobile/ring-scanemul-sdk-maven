package com.m3.ring.scanemul.sdk.internal.transport.data.core.dto

/**
 * Transport write 요청의 결과를 내부적으로 표현하는 타입입니다.
 * 외부 SDK API에는 직접 노출하지 않고 상위 계층에서 에러 코드로 변환합니다.
 */
internal enum class TransportRequestResult {
    SUCCESS,
    FAILED,
    TRANSPORT_PROTOCOL_MISMATCH,
}
