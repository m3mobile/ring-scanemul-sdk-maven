package com.m3.ring.scanemul.sdk.internal.transport.service

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import com.m3.ring.scanemul.sdk.api.error.catalog.ConnectErrorCatalog
import com.m3.ring.scanemul.sdk.internal.connection.domain.DeviceConnectionCoordinator
import com.m3.ring.scanemul.sdk.internal.device.state.DeviceStateStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

internal class TransportServiceConnector(
    private val appContext: Context,
    private val connectionCoordinator: DeviceConnectionCoordinator,
    private val deviceStateStore: DeviceStateStore
) {
    private val mainScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var conn: ServiceConnection? = null

    private var isBinding = false

    fun bindTransportService(
        onBound: (TransportService.LocalBinder) -> Unit,
        onLost: (ConnectErrorCatalog) -> Unit
    ) {
        mainScope.launch {
            if (isBinding || conn != null) return@launch

            isBinding = true

            val serviceConnection = object : ServiceConnection {
                override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                    isBinding = false
                    val binder = service as? TransportService.LocalBinder
                    if (binder == null) {
                        onLost(ConnectErrorCatalog.CONNECTION_FAILED)
                        return
                    }
            binder.setDependencies(connectionCoordinator, deviceStateStore)
                    onBound(binder)
                }

                override fun onServiceDisconnected(name: ComponentName?) {
                    conn = null
                    isBinding = false
                    onLost(
                        ConnectErrorCatalog.CONNECTION_FAILED
                    )
                }

                override fun onBindingDied(name: ComponentName?) {
                    // 바인딩 자체가 죽음 -> 이 바인딩은 재사용 불가
                    unbindInternal()
                    onLost(
                        ConnectErrorCatalog.CONNECTION_FAILED
                    )
                }

                override fun onNullBinding(name: ComponentName?) {
                    isBinding = false

                    // 바인딩이 null로 돌아옴 -> 서비스 구현/매니페스트 확인 필요
                    throw IllegalStateException("TransportService returned null binding. Check service implementation/manifest.")
                }
            }

            val isOk = appContext.applicationContext.bindService(
                Intent(appContext, TransportService::class.java), serviceConnection, Context.BIND_AUTO_CREATE
            )

            if (isOk) {
                conn = serviceConnection
            } else {
                // 바인딩 실패 -> 매니페스트 및 패키지/클래스 이름 확인 필요
                isBinding = false
                onLost(ConnectErrorCatalog.CONNECTION_FAILED) // throw 대신
            }
        }
    }

    fun dispose() {
        unbindInternal()
        mainScope.cancel()
    }

    private fun unbindInternal() {
        isBinding = false
        conn?.let { runCatching { appContext.applicationContext.unbindService(it) } }
        conn = null
    }
}
