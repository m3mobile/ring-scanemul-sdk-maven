package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.interleaved2of5.Interleaved2Of5Type
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
internal object Interleaved2Of5Symbology {
    /* Ids */
    enum class Interleaved2Of5Ids(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("interleaved2Of5Enable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0x06), totinfo = byteArrayOf(0x06)),

        @BindField("interleaved2Of5Length1")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH1(zebra = byteArrayOf(0x16), totinfo = byteArrayOf(0x16)),

        @BindField("interleaved2Of5Length2")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH2(zebra = byteArrayOf(0x17), totinfo = byteArrayOf(0x17)),

        @BindField("interleaved2Of5CheckDigit")
        @BindValue(ValueType.ENUM, CheckDigitVal::class)
        CHECK_DIGIT(zebra = byteArrayOf(0x31), totinfo = byteArrayOf(0x31)),

        @BindField("interleaved2Of5ReportCheckDigit")
        @BindValue(ValueType.ENUM, ReportCheckDigitVal::class)
        TRANSMIT_CHECK_DIGIT(zebra = byteArrayOf(0x2C), totinfo = byteArrayOf(0x2C)),

        @BindField("interleaved2Of5SecurityLevel")
        @BindValue(ValueType.ENUM, SecurityLevelVal::class)
        I2OF5_SECURITY_LEVEL(zebra = byteArrayOf(0xF8.toByte(), 0x04.toByte(), 0x61.toByte()), totinfo = null),

        @BindField("interleaved2Of5ConvertITF14ToEAN13")
        @BindValue(ValueType.ENUM, ConvertITF14ToEAN13Val::class)
        CONVERT_ITF14_TO_EAN13(zebra = byteArrayOf(0x52.toByte()), totinfo = null),

        @BindField("interleaved2Of5ReducedQuietZone")
        @BindValue(ValueType.ENUM, ReducedQuietZoneVal::class)
        I2OF5_REDUCED_QUIET_ZONE(zebra = byteArrayOf(0xF8.toByte(), 0x04.toByte(), 0xBA.toByte()), totinfo = null);

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnumNameMatch(external = Interleaved2Of5Type.CheckDigitType::class)
    enum class CheckDigitVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00)),
        ENABLE(totinfo = byteArrayOf(0x01)),
        USS_CHECK_DIGIT(zebra = byteArrayOf(0x01)),
        OPCC_CHECK_DIGIT(zebra = byteArrayOf(0x02))
    }

    @EnableDisableEnum
    enum class ReportCheckDigitVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnumNameMatch(external = Interleaved2Of5Type.SecurityType::class)
    enum class SecurityLevelVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        LEVEL_0(zebra = byteArrayOf(0x00)),
        LEVEL_1(zebra = byteArrayOf(0x01)),
        LEVEL_2(zebra = byteArrayOf(0x02)),
        LEVEL_3(zebra = byteArrayOf(0x03))
    }

    @EnableDisableEnum
    enum class ConvertITF14ToEAN13Val(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00)),
        ENABLE(zebra = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class ReducedQuietZoneVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00)),
        ENABLE(zebra = byteArrayOf(0x01))
    }
}
