package com.m3.ring.scanemul.sdk.internal.scan.data.spp.dto

import android.bluetooth.BluetoothDevice
import com.m3.ring.scanemul.sdk.api.model.scan.DiscoveryDeviceModel

internal data class DiscoveryDeviceDto(
    val btDevice: BluetoothDevice,
    val rssi: Int?,
)

internal fun DiscoveryDeviceDto.toModel() = DiscoveryDeviceModel(
    btDevice = btDevice,
    rssi = rssi
)
