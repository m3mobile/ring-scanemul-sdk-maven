package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.upcean.UpcEanType
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
internal object UPCEanSymbology {
    /* Ids */
    enum class UPCEanIds(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("upcEanReportEan8CheckDigit")
        @BindValue(ValueType.ENUM, ReportEan8CheckDigitVal::class)
        REPORT_EAN8_CHECK_DIGIT(
            zebra = byteArrayOf(0xF8.toByte(), 0x07.toByte(), 0x59.toByte()),
            totinfo = byteArrayOf(0xF2.toByte(), 0x80.toByte())
        ),

        @BindField("upcEanReportEan13CheckDigit")
        @BindValue(ValueType.ENUM, ReportEan13CheckDigitVal::class)
        REPORT_EAN13_CHECK_DIGIT(
            zebra = byteArrayOf(0xF8.toByte(), 0x07.toByte(), 0x5A.toByte()),
            totinfo = byteArrayOf(0xF2.toByte(), 0x16.toByte())
        ),

        @BindField("upcEanSupplementalMode")
        @BindValue(ValueType.ENUM, SupplementalModeVal::class)
        SUPPLEMENTAL_MODE(zebra = byteArrayOf(0x10), totinfo = null),

        @BindField("upcEanSupplementalAimIdFormat")
        @BindValue(ValueType.ENUM, SupplementalAimIdFormatVal::class)
        SUPPLEMENTAL_AIM_ID_FORMAT(zebra = byteArrayOf(0xF1.toByte(), 0xA0.toByte()), totinfo = null),

        @BindField("upcEanReducedQuietZone")
        @BindValue(ValueType.ENUM, ReducedQuietZoneVal::class)
        REDUCED_QUIET_ZONE(zebra = byteArrayOf(0xF8.toByte(), 0x05.toByte(), 0x09.toByte()), totinfo = null),

        @BindField("upcEanBooklandEnable")
        @BindValue(ValueType.ENUM, BooklandEnableVal::class)
        BOOKLAND_ENABLE(zebra = byteArrayOf(0x53.toByte()), totinfo = byteArrayOf(0x53.toByte())),

        @BindField("upcEanBooklandFormat")
        @BindValue(ValueType.ENUM, BooklandFormatVal::class)
        BOOKLAND_FORMAT(zebra = byteArrayOf(0xF1.toByte(), 0x40.toByte()), totinfo = null),

        @BindField("upcEanUccCouponExtend")
        @BindValue(ValueType.ENUM, UccCouponExtendVal::class)
        UCC_COUPON_EXTEND(zebra = byteArrayOf(0x55), totinfo = null),

        @BindField("upcEanCouponReport")
        @BindValue(ValueType.ENUM, CouponReportVal::class)
        COUPON_REPORT(zebra = byteArrayOf(0xF1.toByte(), 0xDA.toByte()), totinfo = null),

        @BindField("upcEanIssnEan")
        @BindValue(ValueType.ENUM, IssnEanVal::class)
        ISSN_EAN(zebra = byteArrayOf(0xF1.toByte(), 0x69.toByte()), totinfo = byteArrayOf(0xF2.toByte(), 0x33.toByte())),

        @BindField("upcEanSupplementalRedundancy")
        @BindValue(ValueType.INT_1BYTE)
        SUPPLEMENTAL_REDUNDANCY(zebra = byteArrayOf(0x50), totinfo = null),

        @BindField("upcEanSupplemental2")
        @BindValue(ValueType.ENUM, Supplemental2Val::class)
        EAN_SUPPLEMENTAL_2(zebra = byteArrayOf(0xCF.toByte()), totinfo = null),

        @BindField("upcEanSupplemental5")
        @BindValue(ValueType.ENUM, Supplemental5Val::class)
        EAN_SUPPLEMENTAL_5(zebra = byteArrayOf(0xD0.toByte()), totinfo = null),

        // TOTIFNO 전용 설정 아이디, 이 설정들이 enable이어야 Ean8_supplemental_2/5, Ean13_supplemental_2/5 설정이 동작함.
        @BindField("upcEan8ReadSupplements")
        @BindValue(ValueType.ENUM, Ean8ReadSupplementsVal::class)
        EAN8_READ_SUPPLEMENTS(zebra = null, totinfo = byteArrayOf(0xF2.toByte(), 0x39.toByte())),

        @BindField("upcEan13ReadSupplements")
        @BindValue(ValueType.ENUM, Ean13ReadSupplementsVal::class)
        EAN13_READ_SUPPLEMENTS(zebra = null, totinfo = byteArrayOf(0xF2.toByte(), 0x3C.toByte())),

        //TOTINFO용 EAN8_SUPPLEMENTAL_2와 EAN13_SUPPLEMENTAL_2를 합친게 Zebra에서는 EAN_SUPPLEMENTAL_2로 되어있음
        @BindField("upcEan8Supplemental2")
        @BindValue(ValueType.ENUM, Ean8Supplemental2Val::class)
        EAN8_SUPPLEMENTAL_2(zebra = null, totinfo = byteArrayOf(0xF2.toByte(), 0x37.toByte())),

        @BindField("upcEan13Supplemental2")
        @BindValue(ValueType.ENUM, Ean13Supplemental2Val::class)
        EAN13_SUPPLEMENTAL_2(zebra = null, totinfo = byteArrayOf(0xF2.toByte(), 0x3A.toByte())),

        //TOTINFO용 EAN8_SUPPLEMENTAL_5와 EAN13_SUPPLEMENTAL_5를 합친게 Zebra에서는 EAN_SUPPLEMENTAL_5로 되어있음
        @BindField("upcEan8Supplemental5")
        @BindValue(ValueType.ENUM, Ean8Supplemental5Val::class)
        EAN8_SUPPLEMENTAL_5(zebra = null, totinfo = byteArrayOf(0xF2.toByte(), 0x38.toByte())),

        @BindField("upcEan13Supplemental5")
        @BindValue(ValueType.ENUM, Ean13Supplemental5Val::class)
        EAN13_SUPPLEMENTAL_5(zebra = null, totinfo = byteArrayOf(0xF2.toByte(), 0x3B.toByte()));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class ReportEan8CheckDigitVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00)),
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class ReportEan13CheckDigitVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00)),
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01))
    }

    @EnumNameMatch(external = UpcEanType.SupplementalModeType::class)
    enum class SupplementalModeVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        IGNORE_SUPPLEMENTALS(zebra = byteArrayOf(0x00)),
        DECODE_WITH_SUPPLEMENTALS(zebra = byteArrayOf(0x01)),
        AUTODISCRIMINATE_SUPPLEMENTALS(zebra = byteArrayOf(0x02)),
        SMART_SUPPLEMENTAL_MODE(zebra = byteArrayOf(0x03)),
        ENABLE_378_379(zebra = byteArrayOf(0x04)),
        ENABLE_978_979(zebra = byteArrayOf(0x05)),
        ENABLE_414_419_434_439(zebra = byteArrayOf(0x06)),
        ENABLE_977(zebra = byteArrayOf(0x07)),
        ENABLE_491(zebra = byteArrayOf(0x08)),
        USER_PROGRAMMABLE_TYPE1(zebra = byteArrayOf(0x09)),
        USER_PROGRAMMABLE_TYPE1_2(zebra = byteArrayOf(0x0A)),
        SMART_PLUS_USER_PROGRAMMABLE1(zebra = byteArrayOf(0x0B)),
        SMART_PLUS_USER_PROGRAMMABLE1_2(zebra = byteArrayOf(0x0C))
    }

    @EnumNameMatch(external = UpcEanType.SupplementalAimIdFormatType::class)
    enum class SupplementalAimIdFormatVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        SEPARATE(zebra = byteArrayOf(0x00)),
        COMBINED(zebra = byteArrayOf(0x01)),
        SEPARATE_TRANSMISSION(zebra = byteArrayOf(0x02))
    }

    @EnableDisableEnum
    enum class ReducedQuietZoneVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00)),
        ENABLE(zebra = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class BooklandEnableVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00)),
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01))
    }

    @EnumNameMatch(external = UpcEanType.BooklandFormatType::class)
    enum class BooklandFormatVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ISBN10(zebra = byteArrayOf(0x00)),
        ISBN13(zebra = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class UccCouponExtendVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00)),
        ENABLE(zebra = byteArrayOf(0x01))
    }

    @EnumNameMatch(external = UpcEanType.CouponReportType::class)
    enum class CouponReportVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        OLD_FORMAT(zebra = byteArrayOf(0x00)),
        NEW_FORMAT(zebra = byteArrayOf(0x01)),
        AUTODISCRIMINATE(zebra = byteArrayOf(0x02))
    }

    @EnableDisableEnum
    enum class IssnEanVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00)),
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class Supplemental2Val(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00)),
        ENABLE(zebra = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class Supplemental5Val(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00)),
        ENABLE(zebra = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class Ean8ReadSupplementsVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = null, totinfo = byteArrayOf(0x00)),
        ENABLE(zebra = null, totinfo = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class Ean13ReadSupplementsVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(zebra = null, totinfo = byteArrayOf(0x00)),
        ENABLE(zebra = null, totinfo = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class Ean8Supplemental2Val(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(totinfo = byteArrayOf(0x00)),
        ENABLE(totinfo = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class Ean13Supplemental2Val(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(totinfo = byteArrayOf(0x00)),
        ENABLE(totinfo = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class Ean8Supplemental5Val(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(totinfo = byteArrayOf(0x00)),
        ENABLE(totinfo = byteArrayOf(0x01))
    }

    @EnableDisableEnum
    enum class Ean13Supplemental5Val(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        DISABLE(totinfo = byteArrayOf(0x00)),
        ENABLE(totinfo = byteArrayOf(0x01))
    }
}
