package com.m3.ring.scanemul.sdk.internal.device.mapping

internal fun Enum<*>?.toBoolExternal(
    trueName: String = "ENABLE",
    falseName: String = "DISABLE"
): Boolean? = when (this?.name) {
    trueName -> true
    falseName -> false
    else -> null
}

inline fun <reified T : Enum<T>> Boolean?.toBoolInternal(
    trueName: String = "ENABLE",
    falseName: String = "DISABLE"
): T? =
    this?.let { if (it) enumValueOf<T>(trueName) else enumValueOf<T>(falseName) }

inline fun <reified T : Enum<T>> Enum<*>?.toEnumExternal(): T? =
    this?.let { enumValueOf<T>(it.name) }

inline fun <reified T : Enum<T>> Enum<*>?.toEnumInternal(): T? =
    this?.let { enumValueOf<T>(it.name) }
