package com.m3.ring.scanemul.sdk.internal.protocol.scanner

import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting

internal interface ScannerIds {
    val zebra: ByteArray?
    val totinfo: ByteArray?

    /**
     *  Enum 멤버를 ByteArray로 변환합니다.
     *
     *  @param scannerType 스캐너 타입 (ZEBRA 또는 TOTINFO)
     *  @return 해당 스캐너 타입에 맞는 ByteArray를 반환합니다.
     *          만약 해당 스캐너 타입에 맞는 ByteArray가 없다면 null을 반환합니다.
     */
    fun toByteArray(vendorType: FwSetting.Vendor): ByteArray? = when (vendorType) {
        FwSetting.Vendor.ZEBRA -> zebra
        FwSetting.Vendor.TOTINFO -> totinfo
    }

    /**
     * Enum 멤버에 일치하는 ScannerSettingInfo를 업데이트하는 함수로 변환합니다.
     *
     * @param vendorType 스캐너 제조사 (ZEBRA 또는 TOTINFO)
     * @return ScannerSettingInfo를 업데이트하는 함수
     *         첫 번째 인자는 변경할 value, 두 번째 인자는 기존 ScannerSettingInfo입니다.
     *         반환된 ScannerSettingInfo는 업데이트된 값을 포함합니다.
     */
    fun updateScannerSettingInfo(
        vendorType: FwSetting.Vendor,
        bytes: ByteArray,
        info: ScannerSettingInfo
    ): ScannerSettingInfo
}
