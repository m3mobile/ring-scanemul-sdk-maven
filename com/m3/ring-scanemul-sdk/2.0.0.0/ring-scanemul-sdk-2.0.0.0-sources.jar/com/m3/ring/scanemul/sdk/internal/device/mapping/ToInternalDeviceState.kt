package com.m3.ring.scanemul.sdk.internal.device.mapping

import com.m3.ring.scanemul.sdk.api.model.DeviceState
import com.m3.ring.scanemul.sdk.internal.device.state.FwSettingInfo
import com.m3.ring.scanemul.sdk.internal.device.state.InternalDeviceState
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.common.values.IntValue
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.BasicFormatSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.GeneralSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.ReaderSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.AustralianPostalSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.AztecSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Chinese2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.CodabarSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code11Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code128Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code39Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Code93Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.CompositeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.DataMatrixSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Discrete2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.DotCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Ean13Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Ean8Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1128Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DataBar14Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DataBarLimitedSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Gs1DatabarExpandedSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.HanXinSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Interleaved2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Isbt128Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.JapanesePostalSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Korean3Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Matrix2Of5Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MaxiCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MicroPdf417Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MicroQrCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.MsiSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.NetherlandsKixSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.Pdf417Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.QrCodeSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UKPostalSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCASymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCE1Symbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCESymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UPCEanSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.USPlanetSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.USPostnetSymbology
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies.UpuFicsPostalSymbology

internal fun DeviceState.toInternalDeviceState(): InternalDeviceState {
    return InternalDeviceState(
        name = this.deviceInfo.name.orEmpty(),
        macAddress = this.deviceInfo.macAddress.orEmpty(),
        fwSettingInfo = FwSettingInfo(
            model = this.deviceInfo.model,
            serialNumber = this.deviceInfo.serialNumber,
            fwVersion = this.deviceInfo.fwVersion,
            configVersion = this.deviceInfo.configVersion,
            releaseDate = this.deviceInfo.releaseDate,
            battery = this.deviceInfo.batteryPercent,
            scannerId = this.deviceInfo.scannerId.toEnumInternal<FwSetting.ScannerId>(),
            mode = this.deviceInfo.btMode.toEnumInternal<FwSetting.BtModeSetting>(),
            sound = this.general.sound.toEnumInternal<FwSetting.SoundSetting>(),
            vendor = this.deviceInfo.vendor.toEnumInternal<FwSetting.Vendor>(),
            vibrate = this.general.vibrateEnabled.toBoolInternal<FwSetting.VibrateSetting>(),
            led = this.general.ledEnabled.toBoolInternal<FwSetting.LedSetting>(),
            endChar = this.basicFormat.endChar.toEnumInternal<FwSetting.EndCharSetting>(),
            substring = this.basicFormat.substringFormation,
            removeFNC = this.basicFormat.removeFnc.toBoolInternal<FwSetting.RemoveFnc>(),
            translateData = this.basicFormat.translateData,
            prePostHex = this.basicFormat.prefixPostfixAsAsciiHex.toBoolInternal<FwSetting.PrePostHex>(),
            prefix = this.basicFormat.prefix,
            postfix = this.basicFormat.postfix,
            upcaToEan13 = this.symbologies.upcEanVals.translateUpcAToEan13.toBoolInternal<FwSetting.UPCAToEAN13>(),
            readMode = this.readerSettings.readMode.toEnumInternal<FwSetting.ReadMode>(),
            laserOnTime = this.readerSettings.laserOnTime
                ?.takeIf(FwSetting.LaserOnTime::isValid)
                ?: FwSetting.LaserOnTime.DEFAULT_SECONDS,
            batteryCallback = this.advancedSettings.batteryCallback.toBoolInternal<FwSetting.BatteryCallback>(),
            autoHidReconnect = this.advancedSettings.autoHidReconnect.toBoolInternal<FwSetting.AutoHidReconnect>(),
            sleepMode = this.general.sleepModeEnabled.toBoolInternal<FwSetting.SleepMode>()
        ),
        scannerSettingInfo = ScannerSettingInfo(
            aim = this.general.aimEnabled.toBoolInternal<GeneralSetting.AimVal>(),
            illumination = this.general.illuminationEnabled.toBoolInternal<GeneralSetting.IlluminationVal>(),

            transmitCodeId = this.basicFormat.transmitCodeId.toEnumInternal<BasicFormatSetting.TransmitCodeIdVal>(),

            readerInverse1D = this.readerSettings.inverse1D.toEnumInternal<ReaderSetting.Inverse1DVal>(),
            readerQuietZoneLevelFor1D = this.readerSettings.quietZoneLevelFor1D
                .toEnumInternal<ReaderSetting.QuietZoneLevelFor1DVal>(),
            readerPoorQualityDecodeEffort = this.readerSettings.poorQualityDecodeEffort
                .toEnumInternal<ReaderSetting.PoorQualityDecodeEffortVal>(),

            australianPostalEnable = this.symbologies.australianPostalVals.enabled
                .toBoolInternal<AustralianPostalSymbology.EnableVal>(),
            aztecEnable = this.symbologies.aztecVals.enabled.toBoolInternal<AztecSymbology.EnableVal>(),
            chinese2Of5Enable = this.symbologies.chinese2Of5Vals.enabled
                .toBoolInternal<Chinese2Of5Symbology.EnableVal>(),

            codabarEnable = this.symbologies.codabarVals.enabled.toBoolInternal<CodabarSymbology.EnableVal>(),
            codabarLength1 = this.symbologies.codabarVals.length1?.let(::IntValue),
            codabarLength2 = this.symbologies.codabarVals.length2?.let(::IntValue),
            codabarCLSIEditing = this.symbologies.codabarVals.clsiEditing
                .toBoolInternal<CodabarSymbology.ClsiEditingVal>(),
            codabarNOTISEditing = this.symbologies.codabarVals.notisEditing
                .toBoolInternal<CodabarSymbology.NotisEditingVal>(),
            codabarSecurityLevel = this.symbologies.codabarVals.securityLevel
                .toEnumInternal<CodabarSymbology.SecurityLevelVal>(),

            code11Enable = this.symbologies.code11Vals.enabled.toBoolInternal<Code11Symbology.EnableVal>(),
            code11Length1 = this.symbologies.code11Vals.length1?.let(::IntValue),
            code11Length2 = this.symbologies.code11Vals.length2?.let(::IntValue),
            code11ReportCheckDigit = this.symbologies.code11Vals.reportCheckDigit
                .toBoolInternal<Code11Symbology.ReportCheckDigitVal>(),
            code11VerifyCheckDigit = this.symbologies.code11Vals.verifyCheckDigit
                .toEnumInternal<Code11Symbology.VerifyCheckDigitVal>(),

            code39Enable = this.symbologies.code39Vals.enabled.toBoolInternal<Code39Symbology.EnableVal>(),
            code39TriopticCode39 = this.symbologies.code39Vals.triopticCode39
                .toBoolInternal<Code39Symbology.TriopticCode39Val>(),
            code39Length1 = this.symbologies.code39Vals.length1?.let(::IntValue),
            code39Length2 = this.symbologies.code39Vals.length2?.let(::IntValue),
            code39ReducedQuietZone = this.symbologies.code39Vals.reducedQuietZone
                .toBoolInternal<Code39Symbology.ReducedQuietZoneVal>(),
            code39ConvertToCode32 = this.symbologies.code39Vals.convertToCode32
                .toBoolInternal<Code39Symbology.ConvertToCode32Val>(),
            code39FullAscii = this.symbologies.code39Vals.fullAscii
                .toBoolInternal<Code39Symbology.FullAsciiVal>(),
            code39ReportCheckDigit = this.symbologies.code39Vals.reportCheckDigit
                .toBoolInternal<Code39Symbology.ReportCheckDigitVal>(),
            code39ReportCode32Prefix = this.symbologies.code39Vals.reportCode32Prefix
                .toBoolInternal<Code39Symbology.ReportCode32PrefixVal>(),
            code39SecurityLevel = this.symbologies.code39Vals.securityLevel
                .toEnumInternal<Code39Symbology.SecurityLevelVal>(),
            code39VerifyCheckDigit = this.symbologies.code39Vals.verifyCheckDigit
                .toBoolInternal<Code39Symbology.VerifyCheckDigitVal>(),

            code93Enable = this.symbologies.code93Vals.enabled.toBoolInternal<Code93Symbology.EnableVal>(),
            code93Length1 = this.symbologies.code93Vals.length1?.let(::IntValue),
            code93Length2 = this.symbologies.code93Vals.length2?.let(::IntValue),

            code128Enable = this.symbologies.code128Vals.enabled.toBoolInternal<Code128Symbology.EnableVal>(),
            code128Length1 = this.symbologies.code128Vals.length1?.let(::IntValue),
            code128Length2 = this.symbologies.code128Vals.length2?.let(::IntValue),
            code128ReducedQuietZone = this.symbologies.code128Vals.reducedQuietZone
                .toBoolInternal<Code128Symbology.ReducedQuietZoneVal>(),
            code128IgnoreFNC4 = this.symbologies.code128Vals.ignoreFnc4
                .toBoolInternal<Code128Symbology.IgnoreFNC4Val>(),
            code128CheckISBTTable = this.symbologies.code128Vals.checkIsbtTable
                .toBoolInternal<Code128Symbology.CheckISBTTableVal>(),
            code128ISBT128ConcatMode = this.symbologies.code128Vals.isbt128ConcatMode
                .toEnumInternal<Code128Symbology.ISBT128ConcatModeVal>(),
            code128SecurityLevel = this.symbologies.code128Vals.securityLevel
                .toEnumInternal<Code128Symbology.SecurityLevelVal>(),
            code128EmulationMode = this.symbologies.code128Vals.emulationMode
                .toBoolInternal<Code128Symbology.EmulationModeVal>(),

            compositeEnable = this.symbologies.compositeVals.enabled
                .toBoolInternal<CompositeSymbology.EnableVal>(),
            compositeAbEnable = this.symbologies.compositeVals.compositeABEnabled
                .toBoolInternal<CompositeSymbology.AbEnableVal>(),
            compositeCEnable = this.symbologies.compositeVals.compositeCEnabled
                .toBoolInternal<CompositeSymbology.CEnableVal>(),
            compositeTLC39Enable = this.symbologies.compositeVals.tlc39Enable
                .toBoolInternal<CompositeSymbology.Tlc39EnableVal>(),
            compositeUPCCompositeMode = this.symbologies.compositeVals.upcCompositeMode
                .toEnumInternal<CompositeSymbology.UpcCompositeModeVal>(),

            dataMatrixEnable = this.symbologies.dataMatrixVals.enabled
                .toBoolInternal<DataMatrixSymbology.EnableVal>(),
            dataMatrixInverse = this.symbologies.dataMatrixVals.inverse
                .toEnumInternal<DataMatrixSymbology.InverseVal>(),
            dataMatrixDecodeMirrorImages = this.symbologies.dataMatrixVals.decodeMirrorImages
                .toEnumInternal<DataMatrixSymbology.DecodeMirrorImagesVal>(),
            dataMatrixGS1DataMatrix = this.symbologies.dataMatrixVals.gs1DataMatrix
                .toBoolInternal<DataMatrixSymbology.Gs1DataMatrixVal>(),

            discrete2Of5Enable = this.symbologies.discrete2Of5Vals.enabled
                .toBoolInternal<Discrete2Of5Symbology.EnableVal>(),
            discrete2Of5Length1 = this.symbologies.discrete2Of5Vals.length1?.let(::IntValue),
            discrete2Of5Length2 = this.symbologies.discrete2Of5Vals.length2?.let(::IntValue),

            dotCodeEnable = this.symbologies.dotCodeVals.enabled.toBoolInternal<DotCodeSymbology.EnableVal>(),
            dotCodeInverse = this.symbologies.dotCodeVals.inverse.toEnumInternal<DotCodeSymbology.InverseVal>(),
            dotCodeMirror = this.symbologies.dotCodeVals.mirror.toEnumInternal<DotCodeSymbology.MirrorVal>(),
            dotCodePrioritize = this.symbologies.dotCodeVals.prioritize
                .toBoolInternal<DotCodeSymbology.PrioritizeVal>(),

            ean8Enable = this.symbologies.ean8Vals.enabled.toBoolInternal<Ean8Symbology.EnableVal>(),
            ean13Enable = this.symbologies.ean13Vals.enabled.toBoolInternal<Ean13Symbology.EnableVal>(),

            gs1Databar14Enable = this.symbologies.gs1DataBar14Vals.enabled
                .toBoolInternal<Gs1DataBar14Symbology.EnableVal>(),
            gs1DatabarExpandedEnable = this.symbologies.gs1DataBarExpandedVals.enabled
                .toBoolInternal<Gs1DatabarExpandedSymbology.EnableVal>(),

            gs1DataBarLimitedEnable = this.symbologies.gs1DataBarLimitedVals.enabled
                .toBoolInternal<Gs1DataBarLimitedSymbology.EnableVal>(),
            gs1DataBarLimitedSecurityLevel = this.symbologies.gs1DataBarLimitedVals.securityLevel
                .toEnumInternal<Gs1DataBarLimitedSymbology.LimitedSecurityLevelVal>(),

            gs1128Enable = this.symbologies.gs1128Vals.enabled.toBoolInternal<Gs1128Symbology.EnableVal>(),

            hanXinEnable = this.symbologies.hanXinVals.enabled.toBoolInternal<HanXinSymbology.EnableVal>(),
            hanXinInverse = this.symbologies.hanXinVals.inverse.toEnumInternal<HanXinSymbology.InverseVal>(),

            interleaved2Of5Enable = this.symbologies.interleaved2Of5Vals.enabled
                .toBoolInternal<Interleaved2Of5Symbology.EnableVal>(),
            interleaved2Of5Length1 = this.symbologies.interleaved2Of5Vals.length1?.let(::IntValue),
            interleaved2Of5Length2 = this.symbologies.interleaved2Of5Vals.length2?.let(::IntValue),
            interleaved2Of5CheckDigit = this.symbologies.interleaved2Of5Vals.checkDigit
                .toEnumInternal<Interleaved2Of5Symbology.CheckDigitVal>(),
            interleaved2Of5ReportCheckDigit = this.symbologies.interleaved2Of5Vals.reportCheckDigit
                .toBoolInternal<Interleaved2Of5Symbology.ReportCheckDigitVal>(),
            interleaved2Of5SecurityLevel = this.symbologies.interleaved2Of5Vals.securityLevel
                .toEnumInternal<Interleaved2Of5Symbology.SecurityLevelVal>(),
            interleaved2Of5ConvertITF14ToEAN13 = this.symbologies.interleaved2Of5Vals.convertItf14ToEan13
                .toBoolInternal<Interleaved2Of5Symbology.ConvertITF14ToEAN13Val>(),
            interleaved2Of5ReducedQuietZone = this.symbologies.interleaved2Of5Vals.reducedQuietZone
                .toBoolInternal<Interleaved2Of5Symbology.ReducedQuietZoneVal>(),

            isbt128Enable = this.symbologies.isbt128Vals.enabled.toBoolInternal<Isbt128Symbology.EnableVal>(),

            japanesePostalEnable = this.symbologies.japanesePostalVals.enabled
                .toBoolInternal<JapanesePostalSymbology.EnableVal>(),
            korean3Of5Enable = this.symbologies.korean3Of5Vals.enabled
                .toBoolInternal<Korean3Of5Symbology.EnableVal>(),

            matrix2Of5Enable = this.symbologies.matrix2Of5Vals.enabled
                .toBoolInternal<Matrix2Of5Symbology.EnableVal>(),
            matrix2Of5Length1 = this.symbologies.matrix2Of5Vals.length1?.let(::IntValue),
            matrix2Of5Length2 = this.symbologies.matrix2Of5Vals.length2?.let(::IntValue),
            matrix2Of5Redundancy = this.symbologies.matrix2Of5Vals.redundancy
                .toBoolInternal<Matrix2Of5Symbology.RedundancyVal>(),
            matrix2Of5ReportCheckDigit = this.symbologies.matrix2Of5Vals.reportCheckDigit
                .toBoolInternal<Matrix2Of5Symbology.ReportCheckDigitVal>(),
            matrix2Of5VerifyCheckDigit = this.symbologies.matrix2Of5Vals.verifyCheckDigit
                .toBoolInternal<Matrix2Of5Symbology.VerifyCheckDigitVal>(),

            maxicodeEnable = this.symbologies.maxiCodeVals.enabled.toBoolInternal<MaxiCodeSymbology.EnableVal>(),

            microPdf417Enable = this.symbologies.microPdf417Vals.enabled
                .toBoolInternal<MicroPdf417Symbology.EnableVal>(),
            microQrCodeEnable = this.symbologies.microQrCodeVals.enabled
                .toBoolInternal<MicroQrCodeSymbology.EnableVal>(),

            msiEnable = this.symbologies.msiVals.enabled.toBoolInternal<MsiSymbology.EnableVal>(),
            msiLength1 = this.symbologies.msiVals.length1?.let(::IntValue),
            msiLength2 = this.symbologies.msiVals.length2?.let(::IntValue),
            msiCheckDigit = this.symbologies.msiVals.checkDigit.toEnumInternal<MsiSymbology.CheckDigitVal>(),
            msiCheckDigitScheme = this.symbologies.msiVals.checkDigitScheme
                .toEnumInternal<MsiSymbology.CheckDigitSchemeVal>(),
            msiReportCheckDigit = this.symbologies.msiVals.reportCheckDigit
                .toBoolInternal<MsiSymbology.ReportCheckDigitVal>(),

            netherlandsKixEnable = this.symbologies.netherlandsKixVals.enabled
                .toBoolInternal<NetherlandsKixSymbology.EnableVal>(),

            pdf417Enable = this.symbologies.pdf417Vals.enabled.toBoolInternal<Pdf417Symbology.EnableVal>(),
            qrCodeEnable = this.symbologies.qrCodeVals.enabled.toBoolInternal<QrCodeSymbology.EnableVal>(),

            ukPostalEnable = this.symbologies.ukPostalVals.enabled.toBoolInternal<UKPostalSymbology.EnableVal>(),
            ukPostalReportCheckDigit = this.symbologies.ukPostalVals.reportCheckDigit
                .toBoolInternal<UKPostalSymbology.ReportCheckDigitVal>(),

            upcaEnable = this.symbologies.upcAVals.enabled.toBoolInternal<UPCASymbology.EnableVal>(),
            upcaReportCheckDigit = this.symbologies.upcAVals.reportCheckDigit
                .toBoolInternal<UPCASymbology.ReportCheckDigitVal>(),
            upcaPreamble = this.symbologies.upcAVals.preamble.toEnumInternal<UPCASymbology.PreambleVal>(),
            upca2BitsSupplementals = this.symbologies.upcAVals.upcA2BitsSupplementals
                .toBoolInternal<UPCASymbology.Upca2BitsSupplementalsVal>(),
            upca5BitsSupplementals = this.symbologies.upcAVals.upcA5BitsSupplementals
                .toBoolInternal<UPCASymbology.Upca5BitsSupplementalsVal>(),

            upcE1Enable = this.symbologies.upcE1Vals.enabled.toBoolInternal<UPCE1Symbology.EnableVal>(),
            upcE1ConvertToUpcA = this.symbologies.upcE1Vals.convertToUpcA
                .toBoolInternal<UPCE1Symbology.ConvertToUpcAVal>(),
            upcE1Preamble = this.symbologies.upcE1Vals.preamble.toEnumInternal<UPCE1Symbology.PreambleVal>(),
            upcE1ReportCheckDigit = this.symbologies.upcE1Vals.reportCheckDigit
                .toBoolInternal<UPCE1Symbology.ReportCheckDigitVal>(),

            upcEanReportEan8CheckDigit = this.symbologies.upcEanVals.reportEan8CheckDigit
                .toBoolInternal<UPCEanSymbology.ReportEan8CheckDigitVal>(),
            upcEanReportEan13CheckDigit = this.symbologies.upcEanVals.reportEan13CheckDigit
                .toBoolInternal<UPCEanSymbology.ReportEan13CheckDigitVal>(),
            upcEanSupplementalMode = this.symbologies.upcEanVals.supplementalMode
                .toEnumInternal<UPCEanSymbology.SupplementalModeVal>(),
            upcEanSupplementalAimIdFormat = this.symbologies.upcEanVals.supplementalAimIdFormat
                .toEnumInternal<UPCEanSymbology.SupplementalAimIdFormatVal>(),
            upcEanReducedQuietZone = this.symbologies.upcEanVals.reducedQuietZone
                .toBoolInternal<UPCEanSymbology.ReducedQuietZoneVal>(),
            upcEanBooklandEnable = this.symbologies.upcEanVals.booklandEnable
                .toBoolInternal<UPCEanSymbology.BooklandEnableVal>(),
            upcEanBooklandFormat = this.symbologies.upcEanVals.booklandFormat
                .toEnumInternal<UPCEanSymbology.BooklandFormatVal>(),
            upcEanUccCouponExtend = this.symbologies.upcEanVals.uccCouponExtend
                .toBoolInternal<UPCEanSymbology.UccCouponExtendVal>(),
            upcEanCouponReport = this.symbologies.upcEanVals.couponReport
                .toEnumInternal<UPCEanSymbology.CouponReportVal>(),
            upcEanIssnEan = this.symbologies.upcEanVals.issnEan
                .toBoolInternal<UPCEanSymbology.IssnEanVal>(),
            upcEanSupplementalRedundancy = this.symbologies.upcEanVals.supplementalRedundancy?.let(::IntValue),
            upcEanSupplemental2 = this.symbologies.upcEanVals.supplemental2
                .toBoolInternal<UPCEanSymbology.Supplemental2Val>(),
            upcEanSupplemental5 = this.symbologies.upcEanVals.supplemental5
                .toBoolInternal<UPCEanSymbology.Supplemental5Val>(),
            upcEan8ReadSupplements = this.symbologies.upcEanVals.ean8ReadSupplements
                .toBoolInternal<UPCEanSymbology.Ean8ReadSupplementsVal>(),
            upcEan13ReadSupplements = this.symbologies.upcEanVals.ean13ReadSupplements
                .toBoolInternal<UPCEanSymbology.Ean13ReadSupplementsVal>(),
            upcEan8Supplemental2 = this.symbologies.upcEanVals.ean8Supplemental2
                .toBoolInternal<UPCEanSymbology.Ean8Supplemental2Val>(),
            upcEan13Supplemental2 = this.symbologies.upcEanVals.ean13Supplemental2
                .toBoolInternal<UPCEanSymbology.Ean13Supplemental2Val>(),
            upcEan8Supplemental5 = this.symbologies.upcEanVals.ean8Supplemental5
                .toBoolInternal<UPCEanSymbology.Ean8Supplemental5Val>(),
            upcEan13Supplemental5 = this.symbologies.upcEanVals.ean13Supplemental5
                .toBoolInternal<UPCEanSymbology.Ean13Supplemental5Val>(),

            upceEnable = this.symbologies.upcEVals.enabled.toBoolInternal<UPCESymbology.EnableVal>(),
            upceConvertToUpcA = this.symbologies.upcEVals.convertToUpcA
                .toBoolInternal<UPCESymbology.ConvertToUpcAVal>(),
            upcePreamble = this.symbologies.upcEVals.preamble.toEnumInternal<UPCESymbology.PreambleVal>(),
            upceReportCheckDigit = this.symbologies.upcEVals.reportCheckDigit
                .toBoolInternal<UPCESymbology.ReportCheckDigitVal>(),
            upce2BitsSupplementals = this.symbologies.upcEVals.upcE2BitsSupplementals
                .toBoolInternal<UPCESymbology.Upce2BitsSupplementalsVal>(),
            upce5BitsSupplementals = this.symbologies.upcEVals.upcE5BitsSupplementals
                .toBoolInternal<UPCESymbology.Upce5BitsSupplementalsVal>(),

            upuFicsPostalEnable = this.symbologies.upuFicsPostalVals.enabled
                .toBoolInternal<UpuFicsPostalSymbology.EnableVal>(),

            usPlanetEnable = this.symbologies.usPlanetVals.enabled.toBoolInternal<USPlanetSymbology.EnableVal>(),
            usPlanetReportCheckDigit = this.symbologies.usPlanetVals.reportCheckDigit
                .toBoolInternal<USPlanetSymbology.ReportCheckDigitVal>(),

            usPostnetEnable = this.symbologies.usPostnetVals.enabled.toBoolInternal<USPostnetSymbology.EnableVal>(),

            )
    )
}
