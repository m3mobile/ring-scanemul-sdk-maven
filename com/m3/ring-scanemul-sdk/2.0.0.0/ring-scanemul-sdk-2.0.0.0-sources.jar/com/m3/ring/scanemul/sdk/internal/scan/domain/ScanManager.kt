package com.m3.ring.scanemul.sdk.internal.scan.domain

import android.bluetooth.BluetoothDevice
import android.bluetooth.le.ScanFilter

internal interface ScanManager {
    fun startScan(
        onDeviceFound: (BluetoothDevice) -> Unit,
        onScanFailed: (errorCode: Int, errorMsg: String) -> Unit,
        myUuidFilter: List<ScanFilter>? = null
    )

    fun stopScan()
}
