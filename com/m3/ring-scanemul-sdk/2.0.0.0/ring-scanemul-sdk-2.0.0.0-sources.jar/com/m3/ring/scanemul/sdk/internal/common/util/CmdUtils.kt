package com.m3.ring.scanemul.sdk.internal.common.util

import com.m3.ring.scanemul.sdk.internal.device.profile.VendorProfileRegistry
import com.m3.ring.scanemul.sdk.internal.device.state.InternalDeviceState
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.AccessorCommandType
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.CommandSourceType
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSettingSerialize.toSerializeFwSettingPayload
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerParser
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.toSerializePayload

/**
 * 명령어 유틸리티 클래스
 */
//TODO 추후 인덱스나 상수값들을 별도의 파일로 분리 고려(pdf를 파일로 옮겨둔 것처럼)
internal object CmdUtils {
    private const val BINARY_CMD_HEADER: Byte = 0xF1.toByte() // 바이너리 명령의 헤더 바이트
    private const val SET_RESPONSE_ACCESSOR_TYPE = 0xD0.toByte() // Set 응답의 액세서 타입

    private const val HEADER_BYTE_INDEX = 0 // 헤더 바이트의 인덱스
    private const val LENGTH_BYTE_INDEX = 1 // 길이 바이트의 인덱스
    const val CHECKSUM_LENGTH = 2 // 체크섬의 길이 (2바이트)
    const val SOURCE_TYPE_INDEX = 3 // 소스 타입(Fw or Scanner) 바이트의 인덱스
    const val SUB_COMMAND_INDEX = 4 // 서브 명령 바이트의 인덱스
    const val SETTING_VALUE_INDEX = 5 // 설정 값이 시작되는 인덱스
    private const val SCANNER_RESPONSE_PAYLOAD_START_INDEX = 4
    private const val FW_PACKET_PREFIX_BYTE_LENGTH = 2 //Header(1byte) + Length(1byte)


    /**
     * 주어진 바이트 배열이 바이너리 명령인지 확인합니다.
     * 헤더가 F1인 경우 바이너리 명령으로 간주합니다.
     *
     * @param data 검사할 바이트 배열
     * @return 바이너리 명령이면 true, 그렇지 않으면 false
     */
    fun isBinaryCommand(data: ByteArray): Boolean {
        return data.isNotEmpty() && data[HEADER_BYTE_INDEX] == BINARY_CMD_HEADER
    }


    /**
     * 펌웨어 패킷 용 (스캐너 Payload 용 아님)
     *
     * 주어진 바이트 배열의 체크섬을 검사합니다.
     * 체크섬은 바이트 배열의 모든 바이트의 합을 계산한 후,
     * 0xFFFF에서 그 합의 하위 16비트를 뺀 값으로 계산됩니다.
     *
     * @param packet 체크섬을 검사할 바이트 배열
     * @return 체크섬이 유효하면 true, 그렇지 않으면 false
     */
    fun isChecksumValid(packet: ByteArray): Boolean {
        if (packet.size < 3) return false // 최소 길이 검사

        val dataWithoutChecksum = packet.copyOfRange(0, packet.size - 2)

        var sum = 0
        for (byte in dataWithoutChecksum) {
            sum += byte.toUByte().toInt()
        }

        val checkUm = 0xFFFF - (sum and 0xFFFF)

        val receivedHigh = packet[packet.size - 2].toUByte().toInt()
        val receivedLow = packet[packet.size - 1].toUByte().toInt()
        val receivedChecksum = (receivedHigh shl 8) or receivedLow

        return receivedChecksum == checkUm
    }

    /**
     * 주어진 패킷이 ACK 패킷인지 확인합니다.
     * ACK 패킷은 3번째 바이트가 0xD0인 경우로 정의됩니다.
     *
     * @param packet 검사할 바이트 배열
     * @return ACK 패킷이면 true, 그렇지 않으면 false
     */
    fun isAckPacket(packet: ByteArray): Boolean =
        packet.isNotEmpty() && packet[2] == SET_RESPONSE_ACCESSOR_TYPE


    fun splitPayloadByScannerType(
        payload: ByteArray,
        maxSize: Int,
        vendorType: FwSetting.Vendor
    ): List<ByteArray> {
        if (payload.isEmpty() || maxSize <= 0) return emptyList()
        val registry = VendorProfileRegistry.registry[vendorType]
            ?: throw IllegalArgumentException("Unknown scanner type: $vendorType")

        val result = mutableListOf<ByteArray>()
        var start = 0
        var current = 0

        while (current < payload.size) {
            val idFirstByte = payload[current]
            val idLen = registry.getIdLength(idFirstByte)

            if ((current - start + idLen) > maxSize) {
                result.add(payload.copyOfRange(start, current))
                start = current
            }

            current += idLen
        }

        if (start < payload.size) {
            result.add(payload.copyOfRange(start, payload.size))
        }

        return result
    }


    /**
     * 펌웨어 패킷 구조에 맞게 패킷을 생성합니다.
     * 패킷 구조는 다음과 같습니다:
     * - Header (1 byte)
     * - Length (1 byte, 데이터 길이)
     * - Data (가변 길이)
     * - Checksum (2 bytes)
     *
     * @param data 패킷에 포함할 데이터
     * @return 생성된 전체 패킷 바이트 배열
     */
    private fun createPacket(data: ByteArray): ByteArray {
        val fixedPrefixLength = FW_PACKET_PREFIX_BYTE_LENGTH
        val length = fixedPrefixLength + data.size // HEADER + LENGTH + DATA
        val totalLength = length + CHECKSUM_LENGTH   // + Checksum(2 bytes)

        val packet = ByteArray(totalLength)
        packet[HEADER_BYTE_INDEX] = BINARY_CMD_HEADER
        packet[LENGTH_BYTE_INDEX] = length.toByte() // checksum 제외한 전체 길이

        // 데이터 복사
        System.arraycopy(data, 0, packet, fixedPrefixLength, data.size)

        // checksum 계산: 0 ~ (length - 1)까지의 합계
        val checksum = calculateChecksum(packet)
        System.arraycopy(checksum, 0, packet, length, checksum.size)

        return packet
    }


    /**
     * QR 코드 생성을 위한 패킷을 생성합니다.
     * 이 패킷은 펌웨어 설정 정보와 스캐너 설정 정보를 포함합니다.
     *
     * 펌웨어에서 ScannerPayload가 너무 긴 경우 반으로 나눌 수 있도록,
     * 스캐너 설정을 안전하게 나뉜 2개의 size를 패킷에 담습니다.
     *
     * @param internalDeviceState 디바이스 정보 상태
     * @param scannerType 스캐너 모델 타입
     * @return 생성된 QR 코드 패킷 바이트 배열
     */
    fun createPacketForQR(
        internalDeviceState: InternalDeviceState,
        vendorType: FwSetting.Vendor
    ): ByteArray {
        val firmwarePayload = internalDeviceState.fwSettingInfo.toSerializeFwSettingPayload()
        val scannerPayload = internalDeviceState.scannerSettingInfo.toSerializePayload(vendorType)

        val firstScannerPayloadSize = getSplitIndexForIdValuePairs(scannerPayload, vendorType)
        val secondScannerPayloadSize = scannerPayload.size - firstScannerPayloadSize

        val totalSize = 5 + firmwarePayload.size + scannerPayload.size
        val packet = ByteArray(totalSize)

        packet[0] = AccessorCommandType.SET.value
        packet[1] = vendorType.value[0]
        packet[2] = firmwarePayload.size.toByte()
        packet[3] = firstScannerPayloadSize.toByte()
        packet[4] = secondScannerPayloadSize.toByte()

        var index = 5
        firmwarePayload.copyInto(packet, index)
        index += firmwarePayload.size

        scannerPayload.copyInto(packet, index)

        return createPacket(packet).apply {
            /*
             * 최종 패킷의 두 번째 바이트(전체 크기)를 0xFF로 고정하기로 Olga대리님과 합의하였습니다.
             * Size가 F3이 되어버리면 펌웨어에서 인식하지 못하는 문제가 있고, QR코드의 길이가 길어지면 FF가 넘어가는 경우가 발생하기 때문입니다.
             * 또한, 펌웨어에서 해당 바이트를 사용하고 있지 않기 때문입니다. 2025-12-22
             */
            this[1] = 0xFF.toByte()
        }
    }

    /**
     * QR 코드 패킷 생성을 위한 id+value 쌍을 최대 크기로 나누는 인덱스를 반환합니다.
     * 이 함수는 스캐너 타입에 따라 적절한 프로파일을 사용하여
     * id+value 쌍의 크기를 계산합니다.
     *
     * @param payload 스캐너 설정 정보의 바이트 배열
     * @param scannerType 스캐너 모델 타입
     * @return id+value 쌍을 포함할 수 있는 최대 크기의 인덱스
     */
    private fun getSplitIndexForIdValuePairs(
        payload: ByteArray,
        vendorType: FwSetting.Vendor
    ): Int {
        val registry = VendorProfileRegistry.registry[vendorType]
            ?: throw IllegalArgumentException("Unknown scanner type: $vendorType")

        if (payload.isEmpty()) return 0

        val maxSize = payload.size / 2
        if (maxSize < 2) return 0 // 최소 id+value 쌍 하나 넣을 수 있어야 함

        var current = 0
        var totalSize = 0

        while (current < payload.size) {
            val idFirstByte = payload[current]
            val idLen: Int = registry.getIdLength(idFirstByte)

            val valueLen = 1
            val segmentSize = idLen + valueLen

            if (totalSize + segmentSize > maxSize) {
                break
            }

            totalSize += segmentSize
            current += segmentSize
        }

        return current
    }

    /**
     * 스캐너 set 용 명령어 패킷을 생성합니다.
     *
     * @param accessorType 액세서 타입 (예: AccessorCommandType.SET.value)
     * @param sourceType 소스 타입 (예: CommandSourceType.SCANNER.value)
     * @param prefix Set, Get에 따라 고정된 프리픽스 바이트 배열
     * @param payloadCreator 스캐너 설정 ID와 값을 결합하여 페이로드를 생성하는 함수
     * @param ssiIds 스캐너 설정 ID의 바이트 배열
     * @return 생성된 스캐너 설정 명령어 패킷 바이트 배열
     */
    fun createScannerSetCommand(
        accessorType: Byte,
        sourceType: Byte,
        prefix: ByteArray,
        payloadCreator: (ByteArray) -> ByteArray,
        ssiIds: ByteArray
    ): ByteArray {
        return createPacket(
            byteArrayOf(accessorType, sourceType) +
                    payloadCreator(prefix + ssiIds)
        )
    }

    /**
     * 스캐너 Get 용 명령어 패킷을 생성합니다.
     *
     * @param accessorType 액세서 타입 (예: AccessorCommandType.GET.value)
     * @param sourceType 소스 타입 (예: CommandSourceType.SCANNER.value)
     * @param prefix Get에 따라 고정된 프리픽스 바이트 배열
     * @param payloadCreator 스캐너 설정 ID와 값을 결합하여 페이로드를 생성하는 함수
     * @param data 스캐너 설정 ID의 바이트 배열
     * @return 생성된 스캐너 설정 명령어 패킷 바이트 배열
     */
    fun createScannerGetCommand(
        accessorType: Byte,
        sourceType: Byte,
        prefix: ByteArray,
        payloadCreator: (ByteArray) -> ByteArray,
        data: ByteArray
    ): ByteArray {
        return createPacket(
            byteArrayOf(accessorType, sourceType) +
                    payloadCreator(prefix + data)
        )
    }

    /**
     * 펌웨어 Set 명령어 패킷을 생성합니다.
     *
     * @param payload 펌웨어 설정 정보가 포함된 바이트 배열
     * @return 생성된 펌웨어 설정 명령어 패킷 바이트 배열
     */
    fun createFirmwareSetCommand(payload: ByteArray): ByteArray {
        return createPacket(
            byteArrayOf(
                AccessorCommandType.SET.value,
                CommandSourceType.FIRMWARE.value
            ) + payload
        )
    }

    /**
     * 펌웨어 Get 명령어 패킷을 생성합니다.
     *
     * @param payload 펌웨어 설정 정보가 포함된 바이트 배열
     * @return 생성된 펌웨어 설정 명령어 패킷 바이트 배열
     */
    fun createFirmwareGetCommand(payload: Byte): ByteArray {
        return createPacket(
            byteArrayOf(
                AccessorCommandType.GET.value,
                CommandSourceType.FIRMWARE.value,
                payload
            )
        )
    }


    /**
     * 스캐너 설정 정보를 파싱합니다.
     * 주어진 바이트 배열에서 스캐너 설정 정보를 추출하여
     * ScannerSettingInfo 객체로 반환합니다.
     *
     * @param data 스캐너 설정 정보가 포함된 바이트 배열
     * @param internalDeviceState 현재 디바이스 정보 상태
     * @param scannerType 스캐너 모델 타입
     * @return 업데이트된 ScannerSettingInfo 객체
     */
    fun parseScannerSettings(
        data: ByteArray,
        internalDeviceState: InternalDeviceState,
        vendorType: FwSetting.Vendor
    ): ScannerSettingInfo {
        val profile = VendorProfileRegistry.registry[vendorType]
            ?: throw IllegalArgumentException("Unknown scanner type: $vendorType")

        var builder = internalDeviceState.scannerSettingInfo
        val responseEnd = data.size - CHECKSUM_LENGTH
        var index = SCANNER_RESPONSE_PAYLOAD_START_INDEX

        while (index < responseEnd) {
            val idLen = profile.getIdLength(data[index])
            val valueIndex = index + idLen
            if (valueIndex >= responseEnd) break

            val idBytes = data.copyOfRange(index, valueIndex)
            val valueByte = data.copyOfRange(valueIndex, valueIndex + 1)
            builder = ScannerParser.parseForScannerSetting(idBytes, valueByte, vendorType, builder)

            index = valueIndex + 1
        }

        return builder
    }

    /**
     * Zebra SSI Command Payload를 생성합니다.
     *
     * payload structure : (Length) (opcode) (Message Source) (Parameter Type) (data) (Checksum [2bytes])
     * ex)
     *
     * @param data payload에 포함할 데이터 바이트 배열
     * @return 생성된 SSI Command Payload 바이트 배열
     */
    fun zCreateSSIPayloadData(data: ByteArray): ByteArray {
        val length = data.size + 1 // + Length byte itself (1 byte)
        val totalLength = length + CHECKSUM_LENGTH
        val dataWithLengthByte = byteArrayOf(length.toByte()) + data // combine Length byte + Data

        val scannerCmdDataByte = ByteArray(totalLength)

        System.arraycopy(dataWithLengthByte, 0, scannerCmdDataByte, 0, dataWithLengthByte.size)
        val checksum = calculateSSIChecksum(dataWithLengthByte) // Checksum 계산
        System.arraycopy(checksum, 0, scannerCmdDataByte, length, checksum.size) // Checksum을 마지막에 추가
        return scannerCmdDataByte
    }

    /**
     * Totinfo SSI Command Payload를 생성합니다.
     *
     * payload structure : (Length) (opcode) (Message Source) (Parameter Type) (Checksum [2bytes])
     * ex)
     *
     * @param data payload에 포함할 데이터 바이트 배열
     * @return 생성된 SSI Command Payload 바이트 배열
     */
    fun tCreateSSIPayloadData(data: ByteArray): ByteArray {
        val length = data.size + 1 // + Length byte itself (1 byte)
        val totalLength = length + CHECKSUM_LENGTH
        val newByteArrayWithLength = byteArrayOf(length.toByte()) + data

        val scannerCmdDataByte = ByteArray(totalLength)

        System.arraycopy(newByteArrayWithLength, 0, scannerCmdDataByte, 0, newByteArrayWithLength.size)
        val checksum = calculateSSIChecksum(newByteArrayWithLength)
        System.arraycopy(checksum, 0, scannerCmdDataByte, length, checksum.size) // Checksum을 마지막에 추가
        return scannerCmdDataByte
    }

    /**
     * 펌웨어 명렁어 용
     *
     * 주어진 패킷의 체크섬을 계산합니다.
     * 체크섬은 패킷의 모든 바이트의 합을 계산한 후,
     * 0xFFFF에서 그 합의 하위 16비트를 뺀 값으로 계산됩니다.
     *
     * @param packet 체크섬을 계산할 바이트 배열
     * @return 계산된 체크섬 바이트 배열 (2바이트)
     */
    private fun calculateChecksum(packet: ByteArray): ByteArray {
        var sum = 0
        for (element in packet) {
            sum += element.toInt() and 0xFF
        }

        val checksum = 0xFFFF - (sum and 0xFFFF)

        val highByte = ((checksum shr 8) and 0xFF).toByte() // 상위 바이트
        val lowByte = (checksum and 0xFF).toByte()     // 하위 바이트

        return byteArrayOf(highByte, lowByte)
    }

    /**
     * 스캐너 명렁어 용
     *
     * SSI 체크섬을 계산합니다.
     * 체크섬은 바이트 배열의 모든 바이트의 합을 계산한 후,
     * 0xFFFF에서 그 합의 하위 16비트를 뺀 값으로 계산됩니다.
     *
     * @param bytes 체크섬을 계산할 바이트 배열
     * @return 계산된 체크섬 바이트 배열 (2바이트)
     */
    private fun calculateSSIChecksum(bytes: ByteArray): ByteArray {
        // 합계 계산 (Unsigned 16bit로 누적)
        val sum = bytes.fold(0) { acc, byte -> (acc + byte.toUByte().toInt()) and 0xFFFF }

        // 2's complement (0x10000 - sum) & 0xFFFF
        val checksum = (0x10000 - sum) and 0xFFFF

        val highByte = ((checksum shr 8) and 0xFF).toByte()
        val lowByte = (checksum and 0xFF).toByte()

        return byteArrayOf(highByte, lowByte)
    }
}
