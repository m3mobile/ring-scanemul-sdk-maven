package com.m3.ring.scanemul.sdk.internal.protocol.common.commands

import com.m3.ring.scanemul.sdk.internal.protocol.common.values.SettingValue
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting.FwIds
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwValue
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds

/**
 * SDK내부에서 설정 명령을 담는 클래스
 */
internal sealed class InternalSettingCommand {
    sealed class Valid : InternalSettingCommand() {
        data class Scanner(
            val id: ScannerIds,
            val value: SettingValue?,
        ) : Valid()

        data class Firmware(
            val id: FwIds,
            val value: FwValue?,
        ) : Valid()
    }

    data class Error(val message: String) : InternalSettingCommand()
}
