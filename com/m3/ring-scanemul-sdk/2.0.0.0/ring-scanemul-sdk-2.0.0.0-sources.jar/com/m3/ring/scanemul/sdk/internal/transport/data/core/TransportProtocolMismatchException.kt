package com.m3.ring.scanemul.sdk.internal.transport.data.core

internal class TransportProtocolMismatchException : IllegalStateException(
    "The device response is not compatible with the expected transport protocol."
)
