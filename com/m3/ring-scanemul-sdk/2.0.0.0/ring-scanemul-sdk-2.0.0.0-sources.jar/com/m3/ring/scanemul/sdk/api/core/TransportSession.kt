package com.m3.ring.scanemul.sdk.api.core

import android.graphics.Bitmap
import com.m3.ring.scanemul.sdk.api.listener.DecodingDataListener
import com.m3.ring.scanemul.sdk.api.listener.DeviceStateListener
import com.m3.ring.scanemul.sdk.api.listener.DisconnectListener
import com.m3.ring.scanemul.sdk.api.listener.DisconnectResultListener
import com.m3.ring.scanemul.sdk.api.listener.SetDefaultResultSettings
import com.m3.ring.scanemul.sdk.api.listener.SetSettingResultListener
import com.m3.ring.scanemul.sdk.api.model.DecodedBarcode
import com.m3.ring.scanemul.sdk.api.model.DeviceState
import com.m3.ring.scanemul.sdk.api.model.device.BtModeType
import com.m3.ring.scanemul.sdk.api.settings.SettingCommand
import kotlinx.coroutines.flow.Flow

interface TransportSession {
    /**
     * Transmit setting command to the device.
     *
     * @param setting Setting command
     * @param onSuccess Success callback
     * @param onFailure Failure callback (with error message)
     */
    fun setSetting(setting: SettingCommand, onSuccess: () -> Unit, onFailure: (errorCode: Int, errorMsg: String) -> Unit)

    /**
     * Transmit setting command to the device. (For Java usage)
     *
     * @param setting Setting command
     * @param listener Result listener
     */
    fun setSetting(setting: SettingCommand, listener: SetSettingResultListener)

    /**
     * Transmit setting command to the device (suspend version).
     *
     * @param setting Setting command
     */
    suspend fun setSetting(setting: SettingCommand)

    /**
     * reset to factory settings
     *
     * @param onSuccess Success callback
     * @param onFailure Failure callback (with error message)
     */
    fun setDefaultSettings(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit)

    /**
     * reset to factory settings
     *
     * @param listener Result listener
     */
    fun setDefaultSettings(listener: SetDefaultResultSettings)

    /**
     * reset to factory settings (suspend version).
     */
    suspend fun setDefaultSettings()

    /**
     * Translate data to the device.
     */
    fun requestWrite(data: ByteArray)

    /**
     * Disconnects from the device.
     *
     * @param onSuccess Success callback
     * @param onFailure Failure callback (with error message)
     */
    fun disconnect(onSuccess: () -> Unit, onFailure: (errorMsg: String) -> Unit)

    /**
     * Disconnects from the device.
     *
     * @param listener Result listener
     */
    fun disconnect(listener: DisconnectResultListener)

    /**
     * Disconnects from the device (suspend version).
     */
    suspend fun disconnect()

    /**
     * Add a listener to receive barcode data.
     *
     * @param barCodeDataListener Listener to receive barcode data
     */
    fun addDecodingDataListener(barCodeDataListener: DecodingDataListener)

    /**
     * Remove a listener for barcode data.
     *
     * @param barCodeDataListener Listener to be removed
     */
    fun removeDecodingDataListener(barCodeDataListener: DecodingDataListener)

    /**
     * Add a listener to receive disconnect events.
     *
     * @param disconnectListener Listener to receive disconnect events
     */
    fun addDisconnectListener(disconnectListener: DisconnectListener)

    /**
     * Remove a listener for disconnect events.
     *
     * @param disconnectListener Listener to be removed
     */
    fun removeDisconnectListener(disconnectListener: DisconnectListener)

    /**
     * Add a listener to receive device state changes.
     *
     * @param listener Listener to receive device state changes
     */
    fun addDeviceStateListener(listener: DeviceStateListener)

    /**
     * Remove a listener for device state changes.
     *
     * @param listener Listener to be removed
     */
    fun removeDeviceStateListener(listener: DeviceStateListener)

    /**
     * Generate a QR code bitmap for the current settings.
     *
     * @param btMode Bluetooth mode type
     * @return QR code bitmap or null if generation fails
     */
    fun getQrCodeForSetterCommand(btMode: BtModeType): Bitmap?

    /**
     * Flow to observe decoding data.
     */
    fun decodingDataFlow(): Flow<DecodedBarcode>

    /**
     * Flow to observe disconnect events.
     */
    fun disconnectFlow(): Flow<Unit>

    /**
     * Flow to observe device state changes.
     */
    fun deviceStateFlow(): Flow<DeviceState>
}
