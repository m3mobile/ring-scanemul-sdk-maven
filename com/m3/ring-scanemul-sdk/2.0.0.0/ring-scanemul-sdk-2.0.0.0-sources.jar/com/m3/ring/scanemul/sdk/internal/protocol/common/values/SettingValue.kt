package com.m3.ring.scanemul.sdk.internal.protocol.common.values

import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting

internal interface SettingValue {
    fun toByteArray(vendorType: FwSetting.Vendor): ByteArray?
}
