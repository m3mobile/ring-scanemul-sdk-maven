package com.m3.ring.scanemul.sdk.internal.transport.service

import android.Manifest
import android.app.Service
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.core.ConnectionType
import com.m3.ring.scanemul.sdk.api.core.TransportSession
import com.m3.ring.scanemul.sdk.api.error.catalog.ConnectErrorCatalog
import com.m3.ring.scanemul.sdk.api.listener.DiscoveryScanResultListener
import com.m3.ring.scanemul.sdk.api.model.FetchAllSettingsResult
import com.m3.ring.scanemul.sdk.api.model.FetchAllSettingsStatus
import com.m3.ring.scanemul.sdk.internal.common.storage.PrefManager
import com.m3.ring.scanemul.sdk.internal.connection.domain.DeviceConnectionCoordinator
import com.m3.ring.scanemul.sdk.internal.device.state.DeviceStateStore
import com.m3.ring.scanemul.sdk.internal.scan.data.ble.BLEScanManager
import com.m3.ring.scanemul.sdk.internal.scan.data.ble.BLEScanRepo
import com.m3.ring.scanemul.sdk.internal.scan.data.spp.SPPScanManager
import com.m3.ring.scanemul.sdk.internal.scan.data.spp.SPPScanRepo
import java.util.concurrent.atomic.AtomicBoolean

/**
 * BindingService로 구현된 TransportService.
 *
 * 링 스캐너와의 연결을 관리합니다.
 * 앱이 백그라운드로 전환되었을 때도 연결을 오래 유지하기 위해 Service로 구현되었습니다.
 */
internal class TransportService : Service(), TransportServiceApi {
    private lateinit var deviceStateStore: DeviceStateStore

    private val prefs by lazy {
        PrefManager(applicationContext.getSharedPreferences(PrefManager.PREF_NAME, MODE_PRIVATE))
    }

    private lateinit var connectionCoordinator: DeviceConnectionCoordinator
    private val bleScanRepo by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        BLEScanRepo(BLEScanManager(applicationContext, prefs))
    }

    private val sppScanRepo by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        SPPScanRepo(SPPScanManager(applicationContext))
    }

    // 연결 시도 상태 플래그
    private var isConnecting = AtomicBoolean(false)

    inner class LocalBinder : Binder() {
        fun setDependencies(coordinator: DeviceConnectionCoordinator, stateStore: DeviceStateStore) {
            connectionCoordinator = coordinator
            deviceStateStore = stateStore
        }

        fun serviceApi(): TransportServiceApi = this@TransportService
    }

    private val binder = LocalBinder()

    override fun onBind(p0: Intent?): IBinder = binder

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    override fun onUnbind(intent: Intent?): Boolean {
        runCatching { stopS2PScan() }
        runCatching { stopDiscoveryScan() }
        isConnecting.set(false)
        return true
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    override fun connectToDevice(
        connectionType: ConnectionType,
        device: BluetoothDevice,
        onSuccess: (TransportSession) -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        // 중복 연결 방지
        if (!isConnecting.compareAndSet(false, true)) {
            val catalog = ConnectErrorCatalog.ALREADY_CONNECTING
            onFailure(catalog.code, catalog.msg)
            return
        }

        if (!::connectionCoordinator.isInitialized || !::deviceStateStore.isInitialized) {
            isConnecting.set(false)
            val catalog = ConnectErrorCatalog.CONNECTION_FAILED
            onFailure(catalog.code, "Connection dependencies are not initialized")
            return
        }

        val coordinator = connectionCoordinator

        coordinator.connect(
            device,
            onSuccess = { session ->
                isConnecting.set(false)
                onSuccess(session)
            },
            onFailure = { errorCode, errorMsg ->
                isConnecting.set(false)
                onFailure(errorCode, errorMsg)
            }
        )
    }

    override fun fetchAllSettings(onResult: (FetchAllSettingsResult) -> Unit) {
        if (!::connectionCoordinator.isInitialized) {
            onResult(
                FetchAllSettingsResult(
                    status = FetchAllSettingsStatus.FAILED,
                    errorCode = ConnectErrorCatalog.CONNECTION_FAILED.code,
                    errorMsg = "Connection dependencies are not initialized"
                )
            )
            return
        }

        connectionCoordinator.fetchAllSettings(onResult)
    }

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    override fun startS2PScan(onDeviceFound: (BluetoothDevice) -> Unit, onScanFailed: (errorCode: Int, errorMsg: String) -> Unit) {
        bleScanRepo.scanBLEDevice(null, onDeviceFound, onScanFailed)
    }

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    override fun startReconnectScan(
        onDeviceFound: (BluetoothDevice) -> Unit,
        onScanFailed: (errorCode: Int, errorMsg: String) -> Unit
    ) {
        val macAddress = prefs.getString(PrefManager.LAST_CONNECTED_MAC_ADDRESS)
            .takeIf { it.isNotBlank() }
        bleScanRepo.scanBLEDevice(macAddress, onDeviceFound, onScanFailed)
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    override fun stopS2PScan() {
        bleScanRepo.stopScan()
    }

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    override fun startDiscoveryScan(listener: DiscoveryScanResultListener) {
        sppScanRepo.startDiscoveryScan(listener)
    }

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    override fun stopDiscoveryScan() {
        sppScanRepo.stopDiscoveryScan()
    }
}
