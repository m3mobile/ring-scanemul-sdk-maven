package com.m3.ring.scanemul.sdk.internal.protocol.scanner

import com.m3.ring.scanemul.sdk.internal.protocol.common.values.SettingValue
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting

internal interface ScannerValue : SettingValue {
    val zebra: ByteArray?
    val totinfo: ByteArray?

    /**
     * Enum 멤버에 맞는 바이트 배열을 반환합니다.
     *
     * @param scannerType 스캐너 타입 (ZEBRA 또는 TOTINFO)
     * @return 해당 스캐너 타입에 맞는 바이트 배열, 없으면 null
     */
    override fun toByteArray(vendorType: FwSetting.Vendor): ByteArray? {
        return when (vendorType) {
            FwSetting.Vendor.ZEBRA -> zebra
            FwSetting.Vendor.TOTINFO -> totinfo
        }
    }
}
