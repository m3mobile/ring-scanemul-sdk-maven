package com.m3.ring.scanemul.sdk.api.model.settings.advanced

data class AdvancedSettings(
    val batteryCallback: Boolean? = null,
    val autoHidReconnect: Boolean? = null
)
