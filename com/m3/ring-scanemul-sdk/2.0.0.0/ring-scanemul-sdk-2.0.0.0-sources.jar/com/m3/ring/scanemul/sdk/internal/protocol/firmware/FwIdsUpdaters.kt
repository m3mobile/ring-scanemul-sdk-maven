package com.m3.ring.scanemul.sdk.internal.protocol.firmware

import com.m3.ring.scanemul.sdk.internal.device.state.FwSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting.FwIds

internal fun FwIds.updateFromBytes(info: FwSettingInfo, bytes: ByteArray?): FwSettingInfo =
    updater(info, bytes)
