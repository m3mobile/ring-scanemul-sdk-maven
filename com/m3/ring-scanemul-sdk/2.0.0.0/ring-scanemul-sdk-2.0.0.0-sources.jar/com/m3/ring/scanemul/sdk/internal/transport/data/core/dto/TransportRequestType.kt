package com.m3.ring.scanemul.sdk.internal.transport.data.core.dto

/**
 * Transport write 요청의 목적을 구분하기 위한 내부 타입입니다.
 * 추후 요청별 응답 포맷 분기나 예외 처리의 기준으로 사용합니다.
 */
internal enum class TransportRequestType {
    SCANNER_GET_ALL,
    FIRMWARE_GET_ALL,
    SET_SETTING,
}
