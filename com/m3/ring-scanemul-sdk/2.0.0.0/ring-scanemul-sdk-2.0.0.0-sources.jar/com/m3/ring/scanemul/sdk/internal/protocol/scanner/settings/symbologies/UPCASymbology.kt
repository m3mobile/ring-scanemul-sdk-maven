package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.upca.UpcAType
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
internal object UPCASymbology {
    /* Ids */
    enum class UPCAIds(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("upcaEnable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),

        @BindField("upcaReportCheckDigit")
        @BindValue(ValueType.ENUM, ReportCheckDigitVal::class)
        REPORT_CHECK_DIGIT(zebra = byteArrayOf(0x28), totinfo = byteArrayOf(0x28)),

        @BindField("upcaPreamble")
        @BindValue(ValueType.ENUM, PreambleVal::class)
        PREAMBLE(zebra = byteArrayOf(0x22), totinfo = byteArrayOf(0x22)),

        @BindField("upca2BitsSupplementals")
        @BindValue(ValueType.ENUM, Upca2BitsSupplementalsVal::class)
        UPCA_2BITS_SUPPLEMENTALS(zebra = null, totinfo = byteArrayOf(0xF2.toByte(), 0x40.toByte())),

        @BindField("upca5BitsSupplementals")
        @BindValue(ValueType.ENUM, Upca5BitsSupplementalsVal::class)
        UPCA_5BITS_SUPPLEMENTALS(zebra = null, totinfo = byteArrayOf(0xF2.toByte(), 0x41.toByte()));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class ReportCheckDigitVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnumNameMatch(external = UpcAType.PreambleType::class)
    enum class PreambleVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        NONE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00)),
        SYS_CHAR(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        COUNTRY_SYS_CHAR(zebra = byteArrayOf(0x02), totinfo = byteArrayOf(0x02))
    }

    @EnableDisableEnum
    enum class Upca2BitsSupplementalsVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = null, totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = null, totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class Upca5BitsSupplementalsVal(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerValue {
        ENABLE(zebra = null, totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = null, totinfo = byteArrayOf(0x00))
    }
}
