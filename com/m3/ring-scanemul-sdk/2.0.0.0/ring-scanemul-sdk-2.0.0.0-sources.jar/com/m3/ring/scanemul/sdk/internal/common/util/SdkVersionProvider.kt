package com.m3.ring.scanemul.sdk.internal.common.util

import com.m3.ring.scanemul.sdk.BuildConfig

internal object SdkVersionProvider {
    val rawVersion: String
        get() = BuildConfig.SDK_VERSION

    val compatibilityVersion: String
        get() = rawVersion.substringBefore("-")
}
