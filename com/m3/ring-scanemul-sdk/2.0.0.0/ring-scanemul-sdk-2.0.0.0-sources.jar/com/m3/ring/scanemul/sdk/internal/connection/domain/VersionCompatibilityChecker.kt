package com.m3.ring.scanemul.sdk.internal.connection.domain

import com.m3.ring.scanemul.sdk.api.model.FetchAllSettingsStatus
import com.m3.ring.scanemul.sdk.internal.common.util.CompatVersion
import com.m3.ring.scanemul.sdk.internal.common.util.CompatVersionParseResult

internal object VersionCompatibilityChecker {
    fun check(sdkVersion: String, fwVersion: String?): FetchAllSettingsStatus {
        val sdk = when (val result = CompatVersion.parseResult(sdkVersion)) {
            is CompatVersionParseResult.Valid -> result.version
            CompatVersionParseResult.Missing,
            CompatVersionParseResult.Invalid -> return FetchAllSettingsStatus.FAILED
        }

        val fw = when (val result = CompatVersion.parseResult(fwVersion)) {
            is CompatVersionParseResult.Valid -> result.version
            CompatVersionParseResult.Missing -> return FetchAllSettingsStatus.REQUIRED_DEVICE_INFO_MISSING
            CompatVersionParseResult.Invalid -> return FetchAllSettingsStatus.FW_SHOULD_UPDATE
        }

        return when {
            sdk.major < fw.major -> FetchAllSettingsStatus.APP_SHOULD_UPDATE
            sdk.major > fw.major -> FetchAllSettingsStatus.FW_SHOULD_UPDATE
            sdk.minor < fw.minor -> FetchAllSettingsStatus.APP_UPDATE_RECOMMENDED
            sdk.minor > fw.minor -> FetchAllSettingsStatus.FW_UPDATE_RECOMMENDED
            else -> FetchAllSettingsStatus.SUCCESS
        }
    }
}
