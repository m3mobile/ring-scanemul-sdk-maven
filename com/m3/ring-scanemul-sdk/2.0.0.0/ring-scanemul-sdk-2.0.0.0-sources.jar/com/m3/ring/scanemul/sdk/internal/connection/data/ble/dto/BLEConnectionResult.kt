package com.m3.ring.scanemul.sdk.internal.connection.data.ble.dto

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import com.m3.ring.scanemul.sdk.internal.connection.domain.dto.ConnectionResult

internal data class BLEConnectionResult(
    override val isSuccess: Boolean,
    override val errorMsg: String? = null,
    override val device: BluetoothDevice,
    val gatt: BluetoothGatt? = null
) : ConnectionResult
