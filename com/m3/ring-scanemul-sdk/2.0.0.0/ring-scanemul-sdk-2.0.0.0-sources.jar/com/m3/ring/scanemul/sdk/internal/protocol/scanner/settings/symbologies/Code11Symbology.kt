package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.code11.Code11Type
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
internal object Code11Symbology {
    /* Ids */
    enum class Code11Ids(
        override val zebra: ByteArray? = null,
        override val totinfo: ByteArray? = null
    ) : ScannerIds {
        @BindField("code11Enable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0x0A), totinfo = byteArrayOf(0x0A)),

        @BindField("code11Length1")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH1(zebra = byteArrayOf(0x1C), totinfo = byteArrayOf(0x1C)),

        @BindField("code11Length2")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH2(zebra = byteArrayOf(0x1D), totinfo = byteArrayOf(0x1D)),

        @BindField("code11ReportCheckDigit")
        @BindValue(ValueType.ENUM, ReportCheckDigitVal::class)
        REPORT_CHECK_DIGIT(zebra = byteArrayOf(0x2F), totinfo = byteArrayOf(0x2F)),

        @BindField("code11VerifyCheckDigit")
        @BindValue(ValueType.ENUM, VerifyCheckDigitVal::class)
        VERIFY_CHECK_DIGIT(zebra = byteArrayOf(0x34), totinfo = byteArrayOf(0x34));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class ReportCheckDigitVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnumNameMatch(external = Code11Type.VerifyCheckDigitType::class)
    enum class VerifyCheckDigitVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00)),
        ONE_CHECK_DIGIT(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        TWO_CHECK_DIGITS(zebra = byteArrayOf(0x02), totinfo = byteArrayOf(0x02))
    }
}
