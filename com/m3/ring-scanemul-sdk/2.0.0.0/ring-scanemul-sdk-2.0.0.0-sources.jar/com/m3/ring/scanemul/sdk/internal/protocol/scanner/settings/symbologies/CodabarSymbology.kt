package com.m3.ring.scanemul.sdk.internal.protocol.scanner.settings.symbologies

import com.m3.ring.scanemul.sdk.api.model.symbologies.codabar.CodabarType
import com.m3.ring.scanemul.sdk.internal.device.state.ScannerSettingInfo
import com.m3.ring.scanemul.sdk.internal.protocol.firmware.FwSetting
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerIds
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerSettingInfoUpdaterGenerated
import com.m3.ring.scanemul.sdk.internal.protocol.scanner.ScannerValue
import com.m3.ring.scanemul.sdk.ksp.annotations.BindField
import com.m3.ring.scanemul.sdk.ksp.annotations.BindScannerSettingInfo
import com.m3.ring.scanemul.sdk.ksp.annotations.BindValue
import com.m3.ring.scanemul.sdk.ksp.annotations.EnableDisableEnum
import com.m3.ring.scanemul.sdk.ksp.annotations.EnumNameMatch
import com.m3.ring.scanemul.sdk.ksp.annotations.ValueType

@BindScannerSettingInfo(ScannerSettingInfo::class)
internal object CodabarSymbology {
    /* Ids */
    enum class CodabarIds(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerIds {
        @BindField("codabarEnable")
        @BindValue(ValueType.ENUM, EnableVal::class)
        ENABLE(zebra = byteArrayOf(0x07), totinfo = byteArrayOf(0x07)),

        @BindField("codabarLength1")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH1(zebra = byteArrayOf(0x18), totinfo = byteArrayOf(0x18)),

        @BindField("codabarLength2")
        @BindValue(ValueType.INT_1BYTE)
        LENGTH2(zebra = byteArrayOf(0x19), totinfo = byteArrayOf(0x19)),

        @BindField("codabarCLSIEditing")
        @BindValue(ValueType.ENUM, ClsiEditingVal::class)
        CLSI_EDITING(zebra = byteArrayOf(0x36)),

        @BindField("codabarNOTISEditing")
        @BindValue(ValueType.ENUM, NotisEditingVal::class)
        NOTIS_EDITING(zebra = byteArrayOf(0x37), totinfo = byteArrayOf(0x37)),

        @BindField("codabarSecurityLevel")
        @BindValue(ValueType.ENUM, SecurityLevelVal::class)
        SECURITY_LEVEL(zebra = byteArrayOf(0xF8.toByte(), 0x06.toByte(), 0xF0.toByte()));

        override fun updateScannerSettingInfo(
            vendorType: FwSetting.Vendor,
            bytes: ByteArray,
            info: ScannerSettingInfo
        ): ScannerSettingInfo =
            ScannerSettingInfoUpdaterGenerated.update(this, vendorType, bytes, info)
    }

    /* Values */
    @EnableDisableEnum
    enum class EnableVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class ClsiEditingVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnableDisableEnum
    enum class NotisEditingVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        ENABLE(zebra = byteArrayOf(0x01), totinfo = byteArrayOf(0x01)),
        DISABLE(zebra = byteArrayOf(0x00), totinfo = byteArrayOf(0x00))
    }

    @EnumNameMatch(external = CodabarType.SecurityType::class)
    enum class SecurityLevelVal(override val zebra: ByteArray? = null, override val totinfo: ByteArray? = null) : ScannerValue {
        LEVEL_0(zebra = byteArrayOf(0x00)),
        LEVEL_1(zebra = byteArrayOf(0x01)),
        LEVEL_2(zebra = byteArrayOf(0x02)),
        LEVEL_3(zebra = byteArrayOf(0x03))
    }
}
