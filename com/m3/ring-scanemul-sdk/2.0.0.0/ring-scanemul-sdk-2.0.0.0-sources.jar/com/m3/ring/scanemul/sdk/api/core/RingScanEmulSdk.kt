package com.m3.ring.scanemul.sdk.api.core

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.graphics.Bitmap
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.listener.ConnectResultListener
import com.m3.ring.scanemul.sdk.api.listener.DiscoveryScanResultListener
import com.m3.ring.scanemul.sdk.api.listener.FetchAllSettingsResultListener
import com.m3.ring.scanemul.sdk.api.listener.S2PScanResultListener
import com.m3.ring.scanemul.sdk.api.model.FetchAllSettingsResult
import com.m3.ring.scanemul.sdk.api.model.scan.DiscoveryScanEvent
import kotlinx.coroutines.flow.Flow

interface RingScanEmulSdk {
    fun initialize(context: Context, config: RingScanEmulSdkConfig)

    fun getCmdForS2P(): String
    fun getBarcodeBitmapForS2P(width: Int = 260, height: Int = 50): Bitmap?

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun startS2PScan(onDeviceFound: (BluetoothDevice) -> Unit, onScanFailed: (errorCode: Int, errorMsg: String) -> Unit)

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun startS2PScan(listener: S2PScanResultListener)

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    suspend fun startS2PScan(): BluetoothDevice

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun startReconnectScan(
        onDeviceFound: (BluetoothDevice) -> Unit,
        onScanFailed: (errorCode: Int, errorMsg: String) -> Unit
    )

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun startReconnectScan(listener: S2PScanResultListener)

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    suspend fun startReconnectScan(): BluetoothDevice

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    fun connectToDevice(
        device: BluetoothDevice,
        onSuccess: () -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    )

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    fun connectToDevice(device: BluetoothDevice, listener: ConnectResultListener)

    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    suspend fun connectToDevice(device: BluetoothDevice)

    fun fetchAllSettings(onResult: (FetchAllSettingsResult) -> Unit)

    fun fetchAllSettings(listener: FetchAllSettingsResultListener)

    suspend fun fetchAllSettings(): FetchAllSettingsResult

    fun getTransportSession(): TransportSession
    fun hasActiveTransportSession(): Boolean

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun startDiscoveryScan(listener: DiscoveryScanResultListener)

    @RequiresPermission(allOf = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT])
    fun discoveryScanFlow(): Flow<DiscoveryScanEvent>

    fun stopDiscoveryScan()

    @RequiresPermission(Manifest.permission.BLUETOOTH_SCAN)
    fun stopS2PScan()
}
