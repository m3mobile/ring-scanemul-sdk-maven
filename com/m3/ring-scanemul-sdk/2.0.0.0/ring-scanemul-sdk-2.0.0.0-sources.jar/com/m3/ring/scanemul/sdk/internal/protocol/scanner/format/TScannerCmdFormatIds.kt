package com.m3.ring.scanemul.sdk.internal.protocol.scanner.format

/* Scanner Command Setting parameters */
internal object TScannerCmdFormatIds {
    private const val T_PREFIX_BYTE = 0xff.toByte() // 확장 SSI ID의 시작을 나타내는 prefix 바이트

    internal enum class OpCode(val value: Byte) {
        SET(0xc6.toByte()),
        GET(0xc7.toByte());

        companion object {
            fun fromByte(byte: Byte): OpCode? =
                OpCode.entries.find { it.value == byte }
        }
    }

    internal enum class MessageSource(val value: Byte) {
        SCANNER(0x00.toByte()),
        HOST(0x04.toByte());

        companion object {
            fun fromByte(byte: Byte): MessageSource? =
                MessageSource.entries.find { it.value == byte }
        }
    }

    internal enum class Status(val value: Byte) {
        FIRST_TRANSMISSION(0x00.toByte()), // 0 = First transmission,
        SUBSEQUENT_TRANSMISSION(0x01.toByte()); //1 = Subsequent transmission

        companion object {
            fun fromByte(byte: Byte): Status? =
                Status.entries.find { it.value == byte }
        }
    }

    internal enum class ParameterType(val value: Byte) {
        SYMBOLOGY(0x08.toByte());

        companion object {
            fun fromByte(byte: Byte): ParameterType? =
                ParameterType.entries.find { it.value == byte }
        }
    }

    /** Scanner Set Command Prefix Structure : (Opcode) (Message Source) (Parameter Type) (Prefix)**/
    internal val T_FIXED_SET_COMMAND_PREFIX = byteArrayOf(
        OpCode.SET.value,
        MessageSource.HOST.value,
        ParameterType.SYMBOLOGY.value,
        T_PREFIX_BYTE
    )

    /** Scanner Get Command Presets Structure: (Opcode) (Message Source) (Status)  **/
    internal val T_FIXED_GET_COMMAND_PREFIX = byteArrayOf(
        OpCode.GET.value,
        MessageSource.HOST.value,
        Status.FIRST_TRANSMISSION.value,
    )

    val totinfoIdLengthMap = mapOf(
        0xF0.toByte() to 2, 0xF2.toByte() to 2, 0xF5.toByte() to 2
    )
}
