package com.m3.ring.scanemul.sdk.api.error.catalog

enum class ConnectErrorCatalog(val code: Int, val msg: String) {
    ALREADY_CONNECTING(2001, "Already connecting to a device."),
    CONNECTION_FAILED(2004, "Connection failed."),
    DEVICE_SETTINGS_LOAD_FAILED(2005, "Failed to load Device Settings"),
    SDK_FW_VERSION_MISMATCH(2006, "SDK/Firmware version mismatch. Please update the SDK or device firmware to compatible versions."),
    REQUIRED_DEVICE_INFO_MISSING(2007, "Required device information is missing. Please check SDK/Firmware compatibility."),
    UNKNOWN(2100, "Unknown connection error"),
}
