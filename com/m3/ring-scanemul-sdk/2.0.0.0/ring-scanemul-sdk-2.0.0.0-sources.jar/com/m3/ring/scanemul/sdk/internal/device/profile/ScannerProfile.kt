package com.m3.ring.scanemul.sdk.internal.device.profile

internal data class ScannerProfile(
    val getIdLength: (Byte) -> Int,
    val createSetCommand: (ByteArray) -> ByteArray,
    val createGetCommand: (ByteArray) -> ByteArray,
)
