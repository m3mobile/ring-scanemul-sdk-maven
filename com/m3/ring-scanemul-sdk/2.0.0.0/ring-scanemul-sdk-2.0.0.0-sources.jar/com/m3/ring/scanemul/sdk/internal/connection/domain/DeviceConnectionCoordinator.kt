package com.m3.ring.scanemul.sdk.internal.connection.domain

import android.Manifest
import android.bluetooth.BluetoothDevice
import androidx.annotation.RequiresPermission
import com.m3.ring.scanemul.sdk.api.core.TransportSession
import com.m3.ring.scanemul.sdk.api.model.FetchAllSettingsResult

internal interface DeviceConnectionCoordinator {
    @RequiresPermission(Manifest.permission.BLUETOOTH_CONNECT)
    fun connect(
        device: BluetoothDevice,
        onSuccess: (session: TransportSession) -> Unit,
        onFailure: (errorCode: Int, errorMsg: String) -> Unit
    )

    fun fetchAllSettings(onResult: (FetchAllSettingsResult) -> Unit)

    fun scopeCancel()
}
