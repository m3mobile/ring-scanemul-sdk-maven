package com.m3.ring.scanemul.sdk.internal.transport.data.core.dto

import kotlinx.coroutines.CompletableDeferred

internal data class WriteRequest(
    val data: ByteArray,
    val deferred: CompletableDeferred<TransportRequestResult>? = null,
    val requestType: TransportRequestType? = null
)
