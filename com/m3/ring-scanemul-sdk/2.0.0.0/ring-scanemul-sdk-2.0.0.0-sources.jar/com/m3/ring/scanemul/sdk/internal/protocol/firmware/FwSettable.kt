package com.m3.ring.scanemul.sdk.internal.protocol.firmware

internal interface FwSettable {
    fun canSet(vendorType: FwSetting.Vendor): Boolean = true
}
